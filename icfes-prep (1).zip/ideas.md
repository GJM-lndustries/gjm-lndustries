# Ideas de Diseño - ProICFES

## Opción 1: "Camino al Éxito" - Estilo Educativo Colombiano Cálido
<response>
<text>
**Movimiento de Diseño:** Flat Design con toques de Material Design colombiano
**Principios Core:** Calidez, accesibilidad, motivación constante, claridad visual
**Filosofía de Color:** Amarillo dorado (esperanza y logro), azul profundo (conocimiento), rojo suave (energía). Inspirado en la bandera colombiana pero en tonos más suaves y modernos.
**Paradigma de Layout:** Dashboard lateral con progreso visible, tarjetas de contenido amplias
**Elementos Signature:** Barras de progreso animadas, badges de logro, íconos ilustrativos
**Filosofía de Interacción:** Gamificación suave, retroalimentación inmediata, celebración de logros
**Animación:** Transiciones suaves tipo slide, confetti al completar lecciones
**Tipografía:** Nunito (títulos amigables) + Open Sans (cuerpo legible)
</text>
<probability>0.07</probability>
</response>

## Opción 2: "Rumbo al 500" - Estilo Moderno Vibrante
<response>
<text>
**Movimiento de Diseño:** Neobrutalism suavizado con energía juvenil colombiana
**Principios Core:** Energía, dinamismo, claridad extrema, motivación visual
**Filosofía de Color:** Verde esmeralda (crecimiento), naranja vibrante (energía y acción), fondo crema cálido (legibilidad). Colores que transmiten "puedo lograrlo".
**Paradigma de Layout:** Asimétrico con bloques de contenido grandes, navegación lateral en desktop y bottom nav en móvil
**Elementos Signature:** Bordes gruesos en tarjetas de lección, tipografía bold para conceptos clave, ilustraciones simples tipo doodle
**Filosofía de Interacción:** Micro-animaciones en cada acción, sistema de puntos visible, streaks de estudio
**Animación:** Bouncy y enérgico, progress bars que se llenan con satisfacción
**Tipografía:** Space Grotesk (display bold) + DM Sans (body clean)
</text>
<probability>0.08</probability>
</response>

## Opción 3: "Saber es Poder" - Estilo Académico Moderno Accesible ← ELEGIDA
<response>
<text>
**Movimiento de Diseño:** Modern Academic con influencia de apps educativas exitosas (Duolingo meets Khan Academy)
**Principios Core:** Claridad máxima, progresión visible, lenguaje cotidiano, celebración constante
**Filosofía de Color:** Azul índigo profundo (#1e3a5f - confianza y saber), verde lima (#4ade80 - logro y vida), amarillo cálido (#fbbf24 - energía colombiana), fondo blanco-grisáceo (#f8fafc - limpieza). El azul transmite "esto es serio y confiable", el verde dice "¡lo lograste!", el amarillo dice "¡tú puedes!".
**Paradigma de Layout:** Sidebar fija en desktop con navegación por áreas, contenido central amplio con tarjetas. En móvil: bottom navigation con 5 tabs. Progreso siempre visible en la parte superior.
**Elementos Signature:** 
  1. "Medidor de Puntaje" animado que muestra el puntaje estimado actual del usuario
  2. Tarjetas de lección con color de dificultad (verde=fácil, amarillo=medio, rojo=difícil)
  3. Glosario emergente: palabras técnicas subrayadas que al tocarlas muestran definición en lenguaje cotidiano
**Filosofía de Interacción:** Cada pregunta da retroalimentación inmediata con explicación en lenguaje simple. Sistema de "vidas" para simulacros. Racha de días de estudio.
**Animación:** Framer Motion para transiciones de página (slide lateral), progress bars fluidas, confetti al completar módulo, shake suave en respuesta incorrecta
**Tipografía:** Lexend (diseñada para legibilidad y dislexia) para títulos + Inter para cuerpo. Lexend es perfecta para estudiantes colombianos de todos los niveles.
</text>
<probability>0.09</probability>
</response>

## Decisión Final: Opción 3 - "Saber es Poder"

Se eligió esta opción porque:
- Lexend es una fuente diseñada específicamente para mejorar la legibilidad, ideal para estudiantes con diferentes niveles de lectura
- El sistema de colores transmite confianza y logro sin ser intimidante
- La combinación sidebar/bottom-nav es el estándar de apps educativas exitosas
- El glosario emergente resuelve directamente el problema de palabras técnicas
- El medidor de puntaje es la motivación principal del usuario
