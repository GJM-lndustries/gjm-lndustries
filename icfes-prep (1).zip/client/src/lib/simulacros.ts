import type { QuizQuestion } from './appData';

export const simulacro2: QuizQuestion[] = [
  // Simulacro 2 - Preguntas alternativas
  {
    id: 'sim2-1',
    question: 'Un restaurante vende 45 almuerzos a $12.000 cada uno. ¿Cuál es el ingreso total?',
    options: [
      { id: 'a', text: '$480.000' },
      { id: 'b', text: '$540.000' },
      { id: 'c', text: '$600.000' },
      { id: 'd', text: '$660.000' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: '45 × $12.000 = $540.000'
  },
  {
    id: 'sim2-2',
    question: 'Si el promedio de 4 números es 20, ¿cuál es la suma de esos números?',
    options: [
      { id: 'a', text: '40' },
      { id: 'b', text: '60' },
      { id: 'c', text: '80' },
      { id: 'd', text: '100' }
    ],
    correctId: 'c',
    difficulty: 'facil',
    explanation: 'Si promedio = suma / cantidad, entonces suma = promedio × cantidad = 20 × 4 = 80'
  },
  {
    id: 'sim2-3',
    question: 'En un grupo de 50 estudiantes, el 60% aprobó el examen. ¿Cuántos estudiantes aprobaron?',
    options: [
      { id: 'a', text: '20' },
      { id: 'b', text: '25' },
      { id: 'c', text: '30' },
      { id: 'd', text: '35' }
    ],
    correctId: 'c',
    difficulty: 'facil',
    explanation: '60% de 50 = 0.60 × 50 = 30 estudiantes'
  },
  {
    id: 'sim2-4',
    question: 'El texto afirma que "la educación es la base del desarrollo". ¿Cuál es la intención del autor?',
    options: [
      { id: 'a', text: 'Informar sobre educación' },
      { id: 'b', text: 'Persuadir sobre la importancia de la educación' },
      { id: 'c', text: 'Criticar el sistema educativo' },
      { id: 'd', text: 'Contar una historia' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'El autor busca convencer al lector de que la educación es fundamental.'
  },
  {
    id: 'sim2-5',
    question: 'Según el párrafo, ¿cuál es la idea principal?',
    options: [
      { id: 'a', text: 'Los libros son importantes' },
      { id: 'b', text: 'La lectura desarrolla habilidades de pensamiento crítico' },
      { id: 'c', text: 'Todos deben leer más' },
      { id: 'D', text: 'La educación es cara' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'El párrafo enfatiza cómo la lectura mejora la capacidad de análisis y pensamiento crítico.'
  },
  {
    id: 'sim2-6',
    question: '¿Cuál es la fotosíntesis?',
    options: [
      { id: 'a', text: 'El proceso de respiración de las plantas' },
      { id: 'b', text: 'El proceso de convertir luz solar en energía química' },
      { id: 'c', text: 'El proceso de absorción de agua' },
      { id: 'd', text: 'El proceso de reproducción de plantas' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'La fotosíntesis es el proceso por el cual las plantas convierten la luz solar en glucosa.'
  },
  {
    id: 'sim2-7',
    question: '¿Cuál es la velocidad del sonido en el aire?',
    options: [
      { id: 'a', text: '100 m/s' },
      { id: 'b', text: '200 m/s' },
      { id: 'c', text: '340 m/s' },
      { id: 'd', text: '500 m/s' }
    ],
    correctId: 'c',
    difficulty: 'facil',
    explanation: 'La velocidad del sonido en el aire es aproximadamente 340 m/s a temperatura ambiente.'
  },
  {
    id: 'sim2-8',
    question: '¿Cuál fue el evento que marcó el inicio de la independencia de Colombia?',
    options: [
      { id: 'a', text: 'La Batalla de Boyacá' },
      { id: 'b', text: 'El Grito de Independencia de 1810' },
      { id: 'c', text: 'La Revolución de 1948' },
      { id: 'd', text: 'El Frente Nacional' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'El Grito de Independencia ocurrió el 20 de julio de 1810, marcando el inicio de la independencia.'
  },
  {
    id: 'sim2-9',
    question: 'What is the past tense of "to eat"?',
    options: [
      { id: 'a', text: 'eats' },
      { id: 'b', text: 'eating' },
      { id: 'c', text: 'ate' },
      { id: 'd', text: 'eaten' }
    ],
    correctId: 'c',
    difficulty: 'facil',
    explanation: 'El pasado del verbo "to eat" es "ate".'
  },
  {
    id: 'sim2-10',
    question: 'Complete: "If I had time, I __ study more."',
    options: [
      { id: 'a', text: 'would' },
      { id: 'b', text: 'will' },
      { id: 'c', text: 'am' },
      { id: 'd', text: 'was' }
    ],
    correctId: 'a',
    difficulty: 'facil',
    explanation: 'En una oración condicional, se usa "would": "If I had time, I would study more."'
  }
];

export const simulacro3: QuizQuestion[] = [
  // Simulacro 3 - Preguntas nivel intermedio
  {
    id: 'sim3-1',
    question: 'Un triángulo tiene lados de 3, 4 y 5 cm. ¿Cuál es su perímetro?',
    options: [
      { id: 'a', text: '10 cm' },
      { id: 'b', text: '12 cm' },
      { id: 'c', text: '15 cm' },
      { id: 'd', text: '20 cm' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'Perímetro = 3 + 4 + 5 = 12 cm'
  },
  {
    id: 'sim3-2',
    question: 'Si x² = 36, ¿cuál es el valor de x?',
    options: [
      { id: 'a', text: '4' },
      { id: 'b', text: '6' },
      { id: 'c', text: '8' },
      { id: 'd', text: '12' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'x² = 36, entonces x = √36 = 6 (considerando el valor positivo)'
  },
  {
    id: 'sim3-3',
    question: '¿Cuál es la mediana del conjunto: 2, 5, 8, 11, 14?',
    options: [
      { id: 'a', text: '5' },
      { id: 'b', text: '8' },
      { id: 'c', text: '11' },
      { id: 'd', text: '14' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'La mediana es el valor del medio cuando los datos están ordenados: 2, 5, 8, 11, 14. La mediana es 8.'
  },
  {
    id: 'sim3-4',
    question: 'El texto sugiere que "la tecnología ha cambiado la forma en que nos comunicamos". ¿Cuál es la suposición principal?',
    options: [
      { id: 'a', text: 'La tecnología es mala' },
      { id: 'b', text: 'La comunicación es importante' },
      { id: 'c', text: 'Todos usan tecnología' },
      { id: 'd', text: 'La tecnología es buena' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'El texto asume que la comunicación es algo importante que ha sido transformado por la tecnología.'
  },
  {
    id: 'sim3-5',
    question: '¿Cuál es la conclusión que se puede inferir del texto?',
    options: [
      { id: 'a', text: 'La tecnología es el futuro' },
      { id: 'b', text: 'Debemos adaptarnos a los cambios tecnológicos' },
      { id: 'c', text: 'La tecnología es complicada' },
      { id: 'd', text: 'No hay cambios en la comunicación' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'El texto implica que es necesario adaptarse a los cambios que trae la tecnología.'
  },
  {
    id: 'sim3-6',
    question: '¿Cuál es la ecuación de la respiración celular?',
    options: [
      { id: 'a', text: 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ATP' },
      { id: 'b', text: '6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂' },
      { id: 'c', text: 'C₆H₁₂O₆ → 6CO₂ + 6H₂O' },
      { id: 'd', text: '6O₂ + ATP → C₆H₁₂O₆ + 6CO₂' }
    ],
    correctId: 'a',
    difficulty: 'facil',
    explanation: 'La ecuación de la respiración celular es: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energía (ATP)'
  },
  {
    id: 'sim3-7',
    question: '¿Cuál es la ley de la conservación de la energía?',
    options: [
      { id: 'a', text: 'La energía se crea de la nada' },
      { id: 'b', text: 'La energía se destruye' },
      { id: 'c', text: 'La energía no se crea ni se destruye, solo se transforma' },
      { id: 'd', text: 'La energía aumenta con el tiempo' }
    ],
    correctId: 'c',
    difficulty: 'facil',
    explanation: 'La ley de la conservación de la energía establece que la energía no se crea ni se destruye, solo se transforma.'
  },
  {
    id: 'sim3-8',
    question: '¿Cuáles son las bases nitrogenadas del ADN?',
    options: [
      { id: 'a', text: 'Adenina, Timina, Guanina, Citosina' },
      { id: 'b', text: 'Adenina, Uracilo, Guanina, Citosina' },
      { id: 'c', text: 'Adenina, Timina, Guanina, Uracilo' },
      { id: 'd', text: 'Adenina, Timina, Guanina, Adenina' }
    ],
    correctId: 'a',
    difficulty: 'facil',
    explanation: 'Las bases nitrogenadas del ADN son: Adenina (A), Timina (T), Guanina (G) y Citosina (C).'
  },
  {
    id: 'sim3-9',
    question: '¿Cuál es el período presidencial en Colombia?',
    options: [
      { id: 'a', text: '2 años' },
      { id: 'b', text: '4 años' },
      { id: 'c', text: '6 años' },
      { id: 'd', text: '8 años' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'El período presidencial en Colombia es de 4 años.'
  },
  {
    id: 'sim3-10',
    question: 'What is a cognate?',
    options: [
      { id: 'a', text: 'Una palabra que significa lo opuesto' },
      { id: 'b', text: 'Una palabra que se parece en dos idiomas y tiene significado similar' },
      { id: 'c', text: 'Una palabra que es muy difícil' },
      { id: 'd', text: 'Una palabra que no existe' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'Un cognado es una palabra que se parece en dos idiomas y tiene un significado similar.'
  }
];

export const simulacro4: QuizQuestion[] = [
  // Simulacro 4 - Preguntas nivel avanzado
  {
    id: 'sim4-1',
    question: 'Si una función es f(x) = 2x + 3, ¿cuál es f(5)?',
    options: [
      { id: 'a', text: '10' },
      { id: 'b', text: '13' },
      { id: 'c', text: '15' },
      { id: 'd', text: '18' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'f(5) = 2(5) + 3 = 10 + 3 = 13'
  },
  {
    id: 'sim4-2',
    question: '¿Cuál es la desviación estándar del conjunto: 2, 4, 6, 8?',
    options: [
      { id: 'a', text: '√5' },
      { id: 'b', text: '√10' },
      { id: 'c', text: '√15' },
      { id: 'd', text: '√20' }
    ],
    correctId: 'a',
    difficulty: 'facil',
    explanation: 'Media = 5. Desviación estándar = √((9+1+1+9)/4) = √5'
  },
  {
    id: 'sim4-3',
    question: '¿Cuál es la pendiente de la línea que pasa por (0,0) y (3,6)?',
    options: [
      { id: 'a', text: '1' },
      { id: 'b', text: '2' },
      { id: 'c', text: '3' },
      { id: 'd', text: '4' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'Pendiente = (6 - 0)/(3 - 0) = 6/3 = 2'
  },
  {
    id: 'sim4-4',
    question: '¿Cuál es la diferencia entre lo que el autor dice explícitamente y lo que implica?',
    options: [
      { id: 'a', text: 'No hay diferencia' },
      { id: 'b', text: 'Lo explícito es más importante' },
      { id: 'c', text: 'Lo implícito requiere inferencia del lector' },
      { id: 'd', text: 'Lo implícito es menos verdadero' }
    ],
    correctId: 'c',
    difficulty: 'facil',
    explanation: 'Lo implícito es lo que se entiende sin ser dicho directamente; requiere que el lector haga inferencias.'
  },
  {
    id: 'sim4-5',
    question: '¿Cuál es la falacia lógica en el siguiente argumento: "Todos los políticos son corruptos"?',
    options: [
      { id: 'a', text: 'Ad hominem' },
      { id: 'b', text: 'Generalización apresurada' },
      { id: 'c', text: 'Falsa dicotomía' },
      { id: 'd', text: 'No hay falacia' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'Es una generalización apresurada porque asume que todos los políticos son corruptos sin evidencia suficiente.'
  },
  {
    id: 'sim4-6',
    question: '¿Cuál es la ley de la gravitación universal?',
    options: [
      { id: 'a', text: 'F = k × q₁ × q₂ / r²' },
      { id: 'b', text: 'F = m × a' },
      { id: 'c', text: 'F = G × m₁ × m₂ / r²' },
      { id: 'd', text: 'F = q × v × B' }
    ],
    correctId: 'c',
    difficulty: 'facil',
    explanation: 'La ley de la gravitación universal es F = G × m₁ × m₂ / r².'
  },
  {
    id: 'sim4-7',
    question: '¿Cuál fue la Gran Colombia?',
    options: [
      { id: 'a', text: 'Una república que incluía Colombia, Venezuela y Ecuador' },
      { id: 'b', text: 'Una república que incluía Colombia, Perú y Bolivia' },
      { id: 'c', text: 'Una república que incluía toda América del Sur' },
      { id: 'd', text: 'Una república que incluía Colombia y Panamá' }
    ],
    correctId: 'a',
    difficulty: 'facil',
    explanation: 'La Gran Colombia (1819-1831) incluía los territorios de la actual Colombia, Venezuela y Ecuador.'
  },
  {
    id: 'sim4-8',
    question: '¿Cuál fue el Frente Nacional en Colombia?',
    options: [
      { id: 'a', text: 'Un acuerdo de paz' },
      { id: 'b', text: 'Un pacto político entre Conservadores y Liberales' },
      { id: 'c', text: 'Una guerra civil' },
      { id: 'd', text: 'Una revolución' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'El Frente Nacional (1958-1974) fue un pacto político entre los partidos Conservador y Liberal.'
  },
  {
    id: 'sim4-9',
    question: 'What is the passive voice of "I eat an apple"?',
    options: [
      { id: 'a', text: 'An apple is eaten by me' },
      { id: 'b', text: 'An apple eats me' },
      { id: 'c', text: 'I am eaten by an apple' },
      { id: 'd', text: 'An apple was eaten' }
    ],
    correctId: 'a',
    difficulty: 'facil',
    explanation: 'La voz pasiva de "I eat an apple" es "An apple is eaten by me".'
  },
  {
    id: 'sim4-10',
    question: 'Complete: "If I were rich, I __ travel around the world."',
    options: [
      { id: 'a', text: 'will' },
      { id: 'b', text: 'would' },
      { id: 'c', text: 'am' },
      { id: 'd', text: 'was' }
    ],
    correctId: 'b',
    difficulty: 'facil',
    explanation: 'En una oración condicional, se usa "would": "If I were rich, I would travel around the world."'
  }
];
