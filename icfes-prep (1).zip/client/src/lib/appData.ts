// ProICFES - App Data Store
// Toda la información de cursos, lecciones, preguntas y progreso del usuario

export type Difficulty = 'facil' | 'medio' | 'dificil';
export type Level = 'basico' | 'intermedio' | 'avanzado' | 'experto';

export interface GlossaryTerm {
  term: string;
  simple: string; // Explicación en lenguaje cotidiano
  technical: string; // Definición técnica
}

export interface QuizOption {
  id: string;
  text: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  context?: string; // Texto de contexto (como en el ICFES real)
  options: QuizOption[];
  correctId: string;
  explanation: string; // Explicación en lenguaje simple
  tip?: string; // Truco o consejo para recordar
  difficulty: Difficulty;
}

export interface Lesson {
  id: string;
  title: string;
  subtitle: string;
  level: Level;
  difficulty: Difficulty;
  duration: number; // minutos
  xp: number;
  content: LessonContent[];
  quiz: QuizQuestion[];
  glossary: GlossaryTerm[];
}

export interface LessonContent {
  type: 'intro' | 'explanation' | 'example' | 'tip' | 'warning';
  title?: string;
  text: string;
  highlight?: string; // Texto destacado
}

export interface Module {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  color: string;
  bgColor: string;
  icon: string;
  image: string;
  lessons: Lesson[];
  totalXp: number;
}

// ============================================================
// DATOS DE LECCIONES - MATEMÁTICAS
// ============================================================

const mathLessons: Lesson[] = [
  {
    id: 'math-1',
    title: 'Números y Operaciones Básicas',
    subtitle: 'Suma, resta, multiplicación y división',
    level: 'basico',
    difficulty: 'facil',
    duration: 15,
    xp: 50,
    glossary: [
      {
        term: 'Operación aritmética',
        simple: 'Es hacer cuentas: sumar, restar, multiplicar o dividir números.',
        technical: 'Proceso matemático que combina dos o más números para obtener un resultado.'
      },
      {
        term: 'Cociente',
        simple: 'El resultado de dividir un número entre otro. Si divides 10 entre 2, el cociente es 5.',
        technical: 'Resultado de una operación de división.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Para qué sirve esto en el ICFES?',
        text: 'En el ICFES siempre hay preguntas donde tienes que hacer cuentas básicas. Pero no te preocupes: no te piden memorizar fórmulas raras, sino entender cómo usar los números en situaciones de la vida real, como calcular precios, promedios o comparar cantidades.'
      },
      {
        type: 'explanation',
        title: 'Las 4 operaciones que debes dominar',
        text: 'Suma (+): juntar cantidades. Resta (-): quitar o comparar. Multiplicación (×): sumar varias veces lo mismo. División (÷): repartir en partes iguales.',
        highlight: 'Truco: Cuando el ICFES te dé un problema, primero identifica qué operación necesitas. ¿Están juntando? Suma. ¿Están quitando? Resta. ¿Repitiendo? Multiplica. ¿Repartiendo? Divide.'
      },
      {
        type: 'example',
        title: 'Ejemplo real del ICFES',
        text: 'En una heladería, cada vaso de helado cuesta $3.000. A cada vaso se le puede agregar acompañamientos por $1.000 cada uno. Si quieres saber el precio total, necesitas: precio base + (precio del acompañamiento × número de acompañamientos). Eso se escribe como: 3.000 + (1.000 × n), donde n es el número de acompañamientos.'
      },
      {
        type: 'tip',
        title: '💡 Consejo para el examen',
        text: 'Cuando veas una expresión como "3.000 + (1.000 × n)", léela como una receta: primero el precio fijo (3.000), luego lo que cambia según cuántos acompañamientos pidas. El ICFES siempre pone problemas de la vida cotidiana, así que piensa en situaciones reales.'
      }
    ],
    quiz: [
      {
        id: 'math-1-q1',
        question: 'En una heladería, cada vaso de helado cuesta $3.000. A cada vaso se le puede agregar acompañamientos por $1.000 cada uno. ¿Cuál expresión permite calcular el precio total de un vaso con varios acompañamientos?',
        options: [
          { id: 'a', text: '1.000 + (1.000 × número de acompañamientos)' },
          { id: 'b', text: '3.000 + (1.000 × número de acompañamientos)' },
          { id: 'c', text: '1.000 + (3.000 × número de acompañamientos)' },
          { id: 'd', text: '3.000 + (3.000 × número de acompañamientos)' }
        ],
        correctId: 'b',
        explanation: '¡Correcto! El precio base del helado es $3.000 (ese siempre va). Luego sumas $1.000 por cada acompañamiento que agregues. Por eso la fórmula es: 3.000 + (1.000 × número de acompañamientos).',
        tip: 'Identifica el valor fijo (3.000) y el valor que cambia (1.000 × n). El fijo siempre está, el variable depende de cuántos pidas.',
        difficulty: 'facil'
      },
      {
        id: 'math-1-q2',
        question: 'Si un estudiante tiene $15.000 y quiere comprar el mayor número posible de cuadernos que cuestan $2.500 cada uno, ¿cuántos cuadernos puede comprar?',
        options: [
          { id: 'a', text: '5 cuadernos' },
          { id: 'b', text: '6 cuadernos' },
          { id: 'c', text: '7 cuadernos' },
          { id: 'd', text: '4 cuadernos' }
        ],
        correctId: 'b',
        explanation: '15.000 ÷ 2.500 = 6. Con $15.000 exactos puedes comprar 6 cuadernos (6 × 2.500 = 15.000). No sobra nada.',
        tip: 'Cuando preguntan "cuántos puede comprar", divide el dinero disponible entre el precio de cada cosa.',
        difficulty: 'facil'
      }
    ]
  },
  {
    id: 'math-2',
    title: 'Promedio, Moda y Mediana',
    subtitle: 'Las tres medidas más importantes del ICFES',
    level: 'basico',
    difficulty: 'facil',
    duration: 20,
    xp: 60,
    glossary: [
      {
        term: 'Promedio (Media)',
        simple: 'Es el valor "del medio" cuando sumas todos los datos y los divides entre cuántos son. Como cuando calculas tu promedio de notas.',
        technical: 'Medida de tendencia central que se calcula sumando todos los valores y dividiendo entre el número total de datos.'
      },
      {
        term: 'Moda',
        simple: 'Es el dato que más se repite. Como la talla de zapatos que más se vende en una tienda.',
        technical: 'Valor que aparece con mayor frecuencia en un conjunto de datos.'
      },
      {
        term: 'Mediana',
        simple: 'Es el valor del medio cuando ordenas todos los datos de menor a mayor. La mitad está por encima y la mitad por debajo.',
        technical: 'Valor que divide un conjunto de datos ordenados en dos partes iguales.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Por qué el ICFES pregunta tanto esto?',
        text: 'El ICFES ama las estadísticas porque son útiles en la vida real. Cuando ves noticias sobre salarios, temperaturas o resultados de elecciones, siempre usan promedio, moda o mediana. El examen te da una tabla o gráfica y te pregunta cuál de estas tres usar.'
      },
      {
        type: 'explanation',
        title: 'Cómo calcular el Promedio',
        text: 'Suma todos los valores y divide entre cuántos hay. Ejemplo: Las notas de Juan son 3, 4, 5, 4, 4. Suma: 3+4+5+4+4 = 20. Divide: 20 ÷ 5 = 4. El promedio de Juan es 4.',
        highlight: 'El promedio es sensible a valores extremos. Un dato muy alto o muy bajo puede "jalar" el promedio.'
      },
      {
        type: 'explanation',
        title: 'Cómo encontrar la Moda',
        text: 'Mira cuál número se repite más veces. En las notas de Juan: 3 aparece 1 vez, 4 aparece 3 veces, 5 aparece 1 vez. La moda es 4 porque es la que más se repite.',
        highlight: 'Puede haber más de una moda si dos valores se repiten la misma cantidad de veces.'
      },
      {
        type: 'explanation',
        title: 'Cómo encontrar la Mediana',
        text: 'Ordena los datos de menor a mayor: 3, 4, 4, 4, 5. El dato del medio (posición 3 de 5) es 4. La mediana es 4. Si hay un número par de datos, promedia los dos del medio.',
        highlight: 'La mediana no se afecta por valores extremos, por eso se usa para salarios o precios de casas.'
      },
      {
        type: 'tip',
        title: '💡 Truco para el ICFES',
        text: 'Cuando el ICFES pregunte sobre "el valor que más se repite" → Moda. "El valor central" → Mediana. "El valor típico calculado" → Promedio. Lee bien la pregunta, estas palabras clave son tu guía.'
      }
    ],
    quiz: [
      {
        id: 'math-2-q1',
        question: 'Un atleta registró los kilómetros recorridos cada día durante 5 días: 8, 12, 8, 15, 8. Si el atleta quiere saber cuál fue la distancia que más repitió, ¿qué dato debe calcular?',
        options: [
          { id: 'a', text: 'El promedio de kilómetros' },
          { id: 'b', text: 'La mediana de los kilómetros' },
          { id: 'c', text: 'La moda de los kilómetros' },
          { id: 'd', text: 'El total de kilómetros' }
        ],
        correctId: 'c',
        explanation: 'La moda es el valor que más se repite. En los datos 8, 12, 8, 15, 8 → el número 8 aparece 3 veces. La moda es 8 km.',
        tip: '"El que más se repite" = Moda. Esta es una pregunta clásica del ICFES.',
        difficulty: 'facil'
      },
      {
        id: 'math-2-q2',
        question: 'Los salarios mensuales de 5 empleados son: $800.000, $900.000, $850.000, $5.000.000, $750.000. ¿Cuál medida representa mejor el salario "típico" de estos empleados?',
        options: [
          { id: 'a', text: 'El promedio, porque usa todos los datos' },
          { id: 'b', text: 'La moda, porque es el más frecuente' },
          { id: 'c', text: 'La mediana, porque no se afecta por el salario muy alto' },
          { id: 'd', text: 'El mayor salario, porque es el más representativo' }
        ],
        correctId: 'c',
        explanation: 'El promedio sería (800+900+850+5000+750)/5 = 1.660.000, que no representa bien a nadie. La mediana (ordenando: 750, 800, 850, 900, 5000) es 850.000, que sí refleja mejor lo que gana la mayoría.',
        tip: 'Cuando hay un dato muy diferente a los demás (como ese salario de 5 millones), la mediana es más justa que el promedio.',
        difficulty: 'medio'
      }
    ]
  },
  {
    id: 'math-3',
    title: 'Interpretación de Gráficas y Tablas',
    subtitle: 'Leer datos sin confundirte',
    level: 'basico',
    difficulty: 'facil',
    duration: 20,
    xp: 60,
    glossary: [
      {
        term: 'Gráfica de barras',
        simple: 'Una imagen con barras (como columnas) donde la altura de cada barra muestra cuánto es algo.',
        technical: 'Representación visual de datos categóricos mediante rectángulos proporcionales a los valores.'
      },
      {
        term: 'Gráfica circular (torta)',
        simple: 'Un círculo dividido en pedazos, como una pizza. Cada pedazo muestra qué parte del total representa algo.',
        technical: 'Diagrama que muestra proporciones de un todo mediante sectores circulares.'
      },
      {
        term: 'Rango',
        simple: 'La diferencia entre el valor más grande y el más pequeño de un conjunto de datos.',
        technical: 'Medida de dispersión calculada como la diferencia entre el valor máximo y mínimo.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Por qué el ICFES usa tantas gráficas?',
        text: 'El ICFES quiere saber si puedes leer información presentada de forma visual, como la que ves en periódicos, noticias o informes del trabajo. No tienes que hacer cálculos complicados, solo leer bien la gráfica y responder lo que te preguntan.'
      },
      {
        type: 'explanation',
        title: 'Cómo leer una gráfica de barras',
        text: 'Paso 1: Lee el título (¿de qué trata?). Paso 2: Lee los ejes (¿qué mide el eje vertical? ¿qué categorías hay en el horizontal?). Paso 3: Identifica la barra más alta, la más baja, y compara. Paso 4: Responde lo que preguntan.',
        highlight: 'El error más común es confundir los ejes. Siempre lee las etiquetas antes de responder.'
      },
      {
        type: 'example',
        title: 'Ejemplo del ICFES real',
        text: 'Una gráfica muestra medios de transporte usados por 900 personas: Bicicleta=225, Automóvil=300, Tren=100, Metro=275. Si preguntan "¿cuáles tienen más usuarios que la mediana?", primero ordenas: 100, 225, 275, 300. La mediana de 4 datos es el promedio de los dos del medio: (225+275)/2 = 250. Entonces los que tienen más de 250 son: Automóvil (300) y Metro (275).'
      },
      {
        type: 'tip',
        title: '💡 Consejo clave',
        text: 'En gráficas circulares, recuerda que el total es 100%. Si un sector ocupa más de la mitad del círculo, representa más del 50%. Si el ICFES te da porcentajes, verifica que sumen 100%.'
      }
    ],
    quiz: [
      {
        id: 'math-3-q1',
        question: 'Una gráfica de barras muestra el número de usuarios de 4 medios de transporte: Bicicleta=225, Automóvil=300, Tren=100, Metro=275. ¿Cuáles medios de transporte tienen un número de usuarios superior a la mediana de los 4 valores?',
        options: [
          { id: 'a', text: 'Bicicleta, Automóvil, Tren y Metro' },
          { id: 'b', text: 'Bicicleta, Automóvil y Metro' },
          { id: 'c', text: 'Automóvil y Metro' },
          { id: 'd', text: 'Solo Automóvil' }
        ],
        correctId: 'c',
        explanation: 'Ordenamos: 100, 225, 275, 300. La mediana de 4 datos es el promedio de los dos del medio: (225+275)/2 = 250. Los que superan 250 son: Automóvil (300) y Metro (275).',
        tip: 'Para la mediana de un número par de datos, promedia los dos del centro.',
        difficulty: 'medio'
      }
    ]
  },
  {
    id: 'math-4',
    title: 'Álgebra Básica: Variables y Expresiones',
    subtitle: 'Las letras en matemáticas no dan miedo',
    level: 'intermedio',
    difficulty: 'medio',
    duration: 25,
    xp: 80,
    glossary: [
      {
        term: 'Variable',
        simple: 'Una letra (como x o n) que representa un número que no conocemos todavía. Es como decir "cierto número" sin saber cuál es.',
        technical: 'Símbolo que representa un valor desconocido o que puede cambiar en una expresión matemática.'
      },
      {
        term: 'Expresión algebraica',
        simple: 'Una combinación de números y letras con operaciones. Por ejemplo: 2x + 5 significa "el doble de un número más 5".',
        technical: 'Combinación de variables, constantes y operaciones matemáticas sin signo de igualdad.'
      },
      {
        term: 'Ecuación',
        simple: 'Una expresión con signo igual (=) que dice que dos cosas son iguales. Como una balanza: lo que hay a la izquierda pesa igual que lo de la derecha.',
        technical: 'Igualdad matemática que contiene una o más variables y se resuelve encontrando el valor de dichas variables.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Para qué sirven las letras en matemáticas?',
        text: 'Las letras en matemáticas son como "comodines": representan un número que no sabemos todavía. Esto nos permite escribir reglas generales. Por ejemplo, en vez de decir "si compras 3 cosas de $2.000 pagas $6.000, si compras 4 pagas $8.000...", simplemente decimos: precio = 2.000 × n (donde n es la cantidad que compras).'
      },
      {
        type: 'explanation',
        title: 'Cómo leer una expresión algebraica',
        text: '3x + 5 se lee: "tres veces un número más cinco". Si x = 2, entonces 3(2) + 5 = 6 + 5 = 11. Si x = 4, entonces 3(4) + 5 = 12 + 5 = 17. La letra cambia, el resultado cambia.',
        highlight: 'En el ICFES, las expresiones algebraicas siempre vienen de situaciones reales. Traduce el problema a palabras primero.'
      },
      {
        type: 'example',
        title: 'Ejemplo del ICFES',
        text: 'Helado: $3.000 fijo + $1.000 por cada acompañamiento. Si llamas "n" al número de acompañamientos, el precio es: 3.000 + 1.000n. Si n=2: 3.000 + 1.000(2) = 5.000. Si n=3: 3.000 + 1.000(3) = 6.000.'
      },
      {
        type: 'tip',
        title: '💡 Estrategia para el ICFES',
        text: 'Cuando veas opciones con expresiones algebraicas, reemplaza un número sencillo (como n=1 o n=2) en cada opción y verifica cuál da el resultado correcto según el problema. Esto te ahorra tiempo y evita errores.'
      }
    ],
    quiz: [
      {
        id: 'math-4-q1',
        question: 'Un taxi cobra $3.500 por la "bajada de bandera" (al subir) más $800 por cada kilómetro recorrido. ¿Cuál expresión representa el costo total de un viaje de k kilómetros?',
        options: [
          { id: 'a', text: '800 + 3.500k' },
          { id: 'b', text: '3.500 + 800k' },
          { id: 'c', text: '(3.500 + 800) × k' },
          { id: 'd', text: '3.500 × 800k' }
        ],
        correctId: 'b',
        explanation: 'El costo fijo (siempre se paga) es $3.500. El costo variable es $800 por cada kilómetro (800 × k). Total: 3.500 + 800k.',
        tip: 'Identifica: ¿qué es fijo? (siempre se paga) y ¿qué cambia? (depende de algo). El fijo va solo, el variable va multiplicado por la variable.',
        difficulty: 'medio'
      }
    ]
  },
  {
    id: 'math-5',
    title: 'Probabilidad y Combinatoria',
    subtitle: 'Contar posibilidades y calcular chances',
    level: 'avanzado',
    difficulty: 'dificil',
    duration: 30,
    xp: 100,
    glossary: [
      {
        term: 'Probabilidad',
        simple: 'La posibilidad de que algo pase. Se expresa como fracción: casos favorables dividido entre casos totales posibles.',
        technical: 'Medida numérica entre 0 y 1 que indica la posibilidad de ocurrencia de un evento.'
      },
      {
        term: 'Permutación',
        simple: 'Ordenar cosas donde el orden importa. Si tienes 3 personas para 3 puestos, el orden en que los ubicas importa.',
        technical: 'Arreglo ordenado de elementos donde el orden de selección es relevante. P(n,r) = n!/(n-r)!'
      },
      {
        term: 'Combinación',
        simple: 'Elegir cosas donde el orden NO importa. Si eliges 3 personas de un grupo de 10 para un equipo, no importa en qué orden las eliges.',
        technical: 'Selección de elementos sin considerar el orden. C(n,r) = n!/(r!(n-r)!)'
      }
    ],
    content: [
      {
        type: 'intro',
        title: 'Probabilidad en la vida real',
        text: 'La probabilidad está en todas partes: en el pronóstico del tiempo, en los juegos de azar, en los seguros, en la medicina. El ICFES te pregunta sobre esto porque quiere saber si puedes razonar sobre posibilidades.'
      },
      {
        type: 'explanation',
        title: 'Cómo calcular una probabilidad',
        text: 'Probabilidad = (Casos favorables) ÷ (Casos totales). Ejemplo: En una bolsa hay 3 bolas rojas y 7 azules. La probabilidad de sacar una roja es 3/10 = 0.3 = 30%.',
        highlight: 'La probabilidad siempre está entre 0 (imposible) y 1 (seguro). Si da más de 1, algo está mal en tu cálculo.'
      },
      {
        type: 'explanation',
        title: 'Permutaciones vs Combinaciones',
        text: 'Permutación (orden importa): ¿De cuántas formas puedo ordenar 3 libros en un estante? 3 × 2 × 1 = 6 formas. Combinación (orden no importa): ¿De cuántas formas puedo elegir 2 libros de 5? 5!/(2!×3!) = 10 formas.',
        highlight: 'La clave: ¿importa el orden? Si sí → permutación. Si no → combinación.'
      },
      {
        type: 'example',
        title: 'Ejemplo del ICFES real',
        text: 'Una biblioteca identifica libros con placas de 3 dígitos usando los dígitos 1, 2, 3, 4 sin repetir. El asistente 1 dice que hay 4 posibilidades. El asistente 2 dice que hay 4×3×2=24. El asistente 2 tiene razón: es una permutación porque el orden importa (123 ≠ 321 son libros diferentes).'
      }
    ],
    quiz: [
      {
        id: 'math-5-q1',
        question: 'Una biblioteca identifica libros con placas de 3 dígitos usando los dígitos 1, 2, 3, 4 sin repetir ninguno. ¿Cuántas placas diferentes se pueden formar?',
        options: [
          { id: 'a', text: '4 placas (solo se elige cuántos dígitos usar)' },
          { id: 'b', text: '12 placas' },
          { id: 'c', text: '24 placas (4 × 3 × 2)' },
          { id: 'd', text: '64 placas' }
        ],
        correctId: 'c',
        explanation: 'Es una permutación porque el orden importa (123 y 321 son placas diferentes). Para el primer dígito hay 4 opciones, para el segundo 3 (ya usamos uno), para el tercero 2. Total: 4 × 3 × 2 = 24 placas.',
        tip: 'Cuando el orden importa (como en contraseñas, placas, códigos), multiplica las opciones disponibles en cada posición.',
        difficulty: 'dificil'
      }
    ]
  }
];

// ============================================================
// DATOS DE LECCIONES - LECTURA CRÍTICA
// ============================================================

const readingLessons: Lesson[] = [
  {
    id: 'read-1',
    title: '¿Qué dice el texto? Comprensión Literal',
    subtitle: 'Encontrar la información que está escrita directamente',
    level: 'basico',
    difficulty: 'facil',
    duration: 15,
    xp: 50,
    glossary: [
      {
        term: 'Comprensión literal',
        simple: 'Entender exactamente lo que dice el texto, sin interpretar ni adivinar. Es como responder: "¿qué dice aquí?"',
        technical: 'Nivel básico de comprensión lectora que implica identificar información explícita en el texto.'
      },
      {
        term: 'Idea principal',
        simple: 'El tema más importante del texto. Si tuvieras que resumir el texto en una sola oración, esa sería la idea principal.',
        technical: 'Proposición central que organiza y da sentido a las demás ideas del texto.'
      },
      {
        term: 'Idea secundaria',
        simple: 'Información adicional que apoya o explica la idea principal, pero no es lo más importante.',
        technical: 'Proposición que complementa, ejemplifica o desarrolla la idea principal.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Por qué el ICFES pone textos tan largos?',
        text: 'El ICFES quiere saber si puedes leer y entender textos de diferentes tipos: noticias, ensayos, cuentos, artículos científicos. No tienes que saber todo sobre el tema del texto, solo leerlo bien y responder con base en lo que dice.'
      },
      {
        type: 'explanation',
        title: 'Estrategia para leer textos del ICFES',
        text: 'Paso 1: Lee las preguntas ANTES de leer el texto (así sabes qué buscar). Paso 2: Lee el texto completo una vez rápido para entender de qué trata. Paso 3: Vuelve al texto para buscar la respuesta específica. Paso 4: Verifica que tu respuesta esté basada en el texto, no en lo que tú crees.',
        highlight: 'El error más común: responder con lo que tú piensas o sabes, no con lo que dice el texto. ¡Siempre basa tu respuesta en el texto!'
      },
      {
        type: 'tip',
        title: '💡 Truco para preguntas literales',
        text: 'Las preguntas literales usan frases como: "Según el texto...", "De acuerdo con el texto...", "El autor afirma que...". La respuesta siempre está escrita directamente en el texto. Busca las palabras clave de la pregunta en el texto.'
      }
    ],
    quiz: [
      {
        id: 'read-1-q1',
        context: 'Lee el siguiente fragmento: "La aporofobia, como señala Cortina, es lo que alimenta el rechazo a inmigrantes y refugiados. No se les rechaza por extranjeros, sino por pobres. Nadie pone reparos a que un jeque árabe se instale en un país europeo, ni a facilitar la residencia a un futbolista famoso."',
        question: '¿Por qué, según el texto, se rechaza a los inmigrantes y refugiados?',
        options: [
          { id: 'a', text: 'Por ser extranjeros de otros países' },
          { id: 'b', text: 'Por ser pobres' },
          { id: 'c', text: 'Por no hablar el idioma local' },
          { id: 'd', text: 'Por ser demasiados en número' }
        ],
        correctId: 'b',
        explanation: 'El texto dice claramente: "No se les rechaza por extranjeros, sino por pobres." La respuesta está escrita directamente en el texto.',
        tip: 'En preguntas literales, la respuesta siempre está en el texto. Busca las palabras clave de la pregunta.',
        difficulty: 'facil'
      }
    ]
  },
  {
    id: 'read-2',
    title: '¿Qué quiere decir el texto? Comprensión Inferencial',
    subtitle: 'Entender lo que el texto dice entre líneas',
    level: 'intermedio',
    difficulty: 'medio',
    duration: 25,
    xp: 80,
    glossary: [
      {
        term: 'Inferencia',
        simple: 'Sacar conclusiones que el texto no dice directamente pero que se pueden deducir de lo que sí dice. Como cuando ves nubes oscuras y concluyes que va a llover.',
        technical: 'Proceso cognitivo de derivar información implícita a partir de información explícita en el texto.'
      },
      {
        term: 'Implicación',
        simple: 'Lo que se desprende o se sigue de una afirmación. Si el texto dice "todos los estudiantes aprobaron", se implica que ninguno reprobó.',
        technical: 'Consecuencia lógica que se deriva de una proposición o conjunto de proposiciones.'
      },
      {
        term: 'Contraejemplo',
        simple: 'Un ejemplo que demuestra que algo NO es verdad. Si alguien dice "todos los pájaros vuelan" y yo digo "el pingüino no vuela", el pingüino es un contraejemplo.',
        technical: 'Caso específico que refuta o contradice una afirmación general.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Qué es leer entre líneas?',
        text: 'A veces los textos no dicen todo directamente. El autor da pistas y tú tienes que usar tu razonamiento para llegar a conclusiones que el texto no dice explícitamente. Esto es inferir. El ICFES tiene muchas preguntas de este tipo porque es la habilidad más importante para la universidad y el trabajo.'
      },
      {
        type: 'explanation',
        title: 'Tipos de preguntas inferenciales en el ICFES',
        text: '1. "¿Qué se puede concluir del texto?" → Busca qué se desprende lógicamente de lo que dice. 2. "¿Cuál sería una continuación adecuada?" → El texto debe seguir la misma línea de argumentación. 3. "¿Qué relación hay entre estos fragmentos?" → Identifica si uno apoya, contradice o ejemplifica al otro.',
        highlight: 'La respuesta correcta siempre se puede justificar con algo del texto. Si no puedes justificarla con el texto, probablemente está mal.'
      },
      {
        type: 'example',
        title: 'Ejemplo del ICFES',
        text: 'Fragmento 1: "La aporofobia alimenta el rechazo a inmigrantes por ser pobres." Fragmento 2: "Los yates atracan sin problemas en el Mediterráneo mientras las embarcaciones pequeñas se hunden." Pregunta: ¿Qué relación hay? El fragmento 2 es un EJEMPLO de lo que dice el 1: los ricos (yates) son bienvenidos, los pobres (embarcaciones pequeñas) no.'
      },
      {
        type: 'tip',
        title: '💡 Estrategia para preguntas inferenciales',
        text: 'Elimina las opciones que: (1) contradigan el texto, (2) no tengan relación con el texto, (3) sean demasiado extremas o absolutas. La respuesta correcta siempre es moderada y se puede justificar.'
      }
    ],
    quiz: [
      {
        id: 'read-2-q1',
        context: 'Fragmento 1: "La aporofobia es lo que alimenta el rechazo a inmigrantes y refugiados. No se les rechaza por extranjeros, sino por pobres." Fragmento 2: "Los yates atracan sin problemas en la costa rica del Mediterráneo mientras las embarcaciones pequeñas se hunden tratando de alcanzarlas."',
        question: '¿Qué relación existe entre los dos fragmentos?',
        options: [
          { id: 'a', text: 'El fragmento 2 es un contraejemplo de lo que se afirma en el 1' },
          { id: 'b', text: 'El fragmento 1 es un contraejemplo de lo que se afirma en el 2' },
          { id: 'c', text: 'El fragmento 2 es un ejemplo a favor de lo que se afirma en el 1' },
          { id: 'd', text: 'El fragmento 1 es un ejemplo a favor de lo que se afirma en el 2' }
        ],
        correctId: 'c',
        explanation: 'El fragmento 1 dice que se rechaza a los pobres, no a los extranjeros. El fragmento 2 ilustra esto: los ricos (yates) son bienvenidos, los pobres (embarcaciones pequeñas) no. Por eso el 2 es un EJEMPLO que apoya lo del 1.',
        tip: 'Para identificar la relación: ¿el segundo fragmento muestra algo que confirma lo del primero? → ejemplo a favor. ¿Lo contradice? → contraejemplo.',
        difficulty: 'medio'
      }
    ]
  },
  {
    id: 'read-3',
    title: 'Propósito del Autor y Estrategias Argumentativas',
    subtitle: '¿Por qué escribió esto y cómo lo defiende?',
    level: 'avanzado',
    difficulty: 'dificil',
    duration: 30,
    xp: 100,
    glossary: [
      {
        term: 'Tesis',
        simple: 'La idea principal que el autor quiere defender o demostrar. Es como la "posición" del autor sobre un tema.',
        technical: 'Proposición central que el autor sostiene y que busca defender mediante argumentos.'
      },
      {
        term: 'Argumento',
        simple: 'Una razón que el autor da para apoyar su tesis. Los argumentos son las "pruebas" que usa para convencerte.',
        technical: 'Razonamiento o evidencia que el autor emplea para sustentar su tesis.'
      },
      {
        term: 'Propósito comunicativo',
        simple: '¿Para qué escribió el autor este texto? ¿Para informar, convencer, entretener, criticar?',
        technical: 'Intención o finalidad que el autor persigue al producir el texto.'
      },
      {
        term: 'Estrategia argumentativa',
        simple: 'La forma en que el autor organiza sus ideas para convencerte. Puede usar ejemplos, estadísticas, citas de expertos, comparaciones, etc.',
        technical: 'Recurso retórico o discursivo empleado para persuadir al lector de la validez de la tesis.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Por qué el ICFES pregunta sobre el propósito del autor?',
        text: 'Saber por qué alguien escribió algo es fundamental para entender el texto completo. Un periodista escribe para informar, un publicista para vender, un político para convencer. Cuando entiendes el propósito, entiendes mejor cada parte del texto.'
      },
      {
        type: 'explanation',
        title: 'Cómo identificar el propósito del autor',
        text: 'Pregúntate: ¿El autor está dando información neutral? → Informar. ¿Está defendiendo una posición? → Argumentar/Convencer. ¿Está contando una historia? → Narrar. ¿Está describiendo algo? → Describir. La mayoría de textos del ICFES son argumentativos: el autor defiende una idea.',
        highlight: 'En textos argumentativos, busca la tesis (qué defiende) y los argumentos (cómo lo defiende).'
      },
      {
        type: 'explanation',
        title: 'Estrategias argumentativas más comunes en el ICFES',
        text: '1. Citar expertos: "Según el filósofo X..." 2. Dar ejemplos concretos 3. Usar estadísticas o datos 4. Comparar situaciones 5. Contar una anécdota personal 6. Presentar y refutar el argumento contrario.',
        highlight: 'El ICFES pregunta: "¿Qué estrategia usa el autor para..." → Identifica cuál de estas está usando.'
      }
    ],
    quiz: [
      {
        id: 'read-3-q1',
        context: 'Un texto sobre aporofobia comienza describiendo la experiencia de una filósofa que nombró un fenómeno social, luego explica el concepto con ejemplos de inmigrantes ricos vs pobres, y concluye con estadísticas sobre crímenes de odio.',
        question: '¿Cuál es la estrategia argumentativa principal del autor del texto?',
        options: [
          { id: 'a', text: 'Presentar una tesis controversial y luego contradecirla con datos' },
          { id: 'b', text: 'Citar a autores y explicar por qué está de acuerdo solo con algunos' },
          { id: 'c', text: 'Presentar su tesis y defenderla con ejemplos, citas y estadísticas' },
          { id: 'd', text: 'Narrar una historia personal para llegar a una conclusión filosófica' }
        ],
        correctId: 'c',
        explanation: 'El autor presenta una tesis (la aporofobia existe y es un problema), luego la defiende usando: el trabajo de una experta (Cortina), ejemplos concretos (yates vs embarcaciones), y estadísticas (47% de personas en calle víctimas de odio). Esta es la estrategia de "tesis + argumentos".',
        tip: 'Para identificar la estrategia: ¿Qué hace el autor? ¿Defiende una idea? ¿La contradice? ¿Solo informa? Luego mira con qué recursos la defiende.',
        difficulty: 'dificil'
      }
    ]
  }
];

// ============================================================
// DATOS DE LECCIONES - CIENCIAS NATURALES
// ============================================================

const scienceLessons: Lesson[] = [
  {
    id: 'sci-1',
    title: 'La Célula: La Unidad de la Vida',
    subtitle: 'El "ladrillo" con el que está hecho todo ser vivo',
    level: 'basico',
    difficulty: 'facil',
    duration: 20,
    xp: 60,
    glossary: [
      {
        term: 'Célula',
        simple: 'La parte más pequeña de un ser vivo que puede vivir por sí sola. Es como el "ladrillo" con el que están hechos todos los seres vivos.',
        technical: 'Unidad estructural y funcional básica de todos los organismos vivos.'
      },
      {
        term: 'Membrana celular',
        simple: 'La "piel" de la célula. Controla qué entra y qué sale, como un portero de discoteca.',
        technical: 'Bicapa lipídica que delimita la célula y regula el transporte de sustancias.'
      },
      {
        term: 'Núcleo',
        simple: 'El "cerebro" de la célula. Contiene el ADN con toda la información para que la célula funcione.',
        technical: 'Orgánulo que contiene el material genético (ADN) y controla las actividades celulares.'
      },
      {
        term: 'ADN',
        simple: 'Las "instrucciones" de la célula. Es como el manual de usuario de un ser vivo, escrito en un código químico.',
        technical: 'Ácido desoxirribonucleico: molécula que contiene la información genética de los organismos.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Qué pregunta el ICFES sobre células?',
        text: 'El ICFES no te pide memorizar cada parte de la célula. Te da un experimento o situación y te pregunta si puedes razonar sobre cómo funciona. Por ejemplo: "Si se daña la membrana celular, ¿qué pasaría?" o "¿Qué célula tiene más mitocondrias y por qué?"'
      },
      {
        type: 'explanation',
        title: 'Las partes principales que debes conocer',
        text: 'Membrana celular: la "piel", controla entradas y salidas. Núcleo: el "cerebro", tiene el ADN. Mitocondria: la "fábrica de energía", produce energía para la célula. Ribosoma: la "fábrica de proteínas". Vacuola: el "almacén" de la célula.',
        highlight: 'Truco para recordar: Piensa en la célula como una fábrica. La membrana es la cerca, el núcleo es la oficina del jefe, las mitocondrias son los generadores de energía.'
      },
      {
        type: 'explanation',
        title: 'Células animales vs vegetales',
        text: 'Las células vegetales tienen algo extra: pared celular (una capa rígida exterior, como una caja de madera), cloroplastos (para hacer fotosíntesis, capturan la luz solar) y vacuola grande central. Las animales no tienen estos.',
        highlight: 'Pregunta frecuente del ICFES: ¿Por qué las plantas pueden hacer su propio alimento y los animales no? Por los cloroplastos.'
      }
    ],
    quiz: [
      {
        id: 'sci-1-q1',
        question: 'Un científico observa que una célula tiene cloroplastos, pared celular y una vacuola grande. ¿De qué tipo de organismo proviene esta célula?',
        options: [
          { id: 'a', text: 'De un animal, porque tiene vacuola' },
          { id: 'b', text: 'De una planta, porque tiene cloroplastos y pared celular' },
          { id: 'c', text: 'De un hongo, porque tiene pared celular' },
          { id: 'd', text: 'De una bacteria, porque es muy simple' }
        ],
        correctId: 'b',
        explanation: 'Los cloroplastos (para fotosíntesis) y la pared celular son características exclusivas de las células vegetales. Los animales no tienen ninguna de estas dos estructuras.',
        tip: 'Cloroplastos = solo plantas. Pared celular = plantas (y hongos, pero los hongos no tienen cloroplastos).',
        difficulty: 'facil'
      }
    ]
  },
  {
    id: 'sci-2',
    title: 'Leyes del Movimiento de Newton',
    subtitle: 'Por qué las cosas se mueven o se quedan quietas',
    level: 'intermedio',
    difficulty: 'medio',
    duration: 25,
    xp: 80,
    glossary: [
      {
        term: 'Fuerza',
        simple: 'Un empujón o jalón que puede cambiar el movimiento de un objeto. Se mide en Newtons (N).',
        technical: 'Interacción que puede cambiar el estado de movimiento o la forma de un cuerpo. F = ma'
      },
      {
        term: 'Inercia',
        simple: 'La "pereza" de los objetos: los que están quietos quieren seguir quietos, y los que se mueven quieren seguir moviéndose.',
        technical: 'Propiedad de los cuerpos de resistir cambios en su estado de movimiento.'
      },
      {
        term: 'Aceleración',
        simple: 'El cambio en la velocidad. Si un carro va más rápido, está acelerando. Si frena, también está acelerando (pero negativo).',
        technical: 'Variación de la velocidad por unidad de tiempo. a = Δv/Δt'
      }
    ],
    content: [
      {
        type: 'intro',
        title: 'Las 3 leyes que explican el movimiento',
        text: 'Isaac Newton describió tres leyes que explican por qué los objetos se mueven como lo hacen. Estas leyes funcionan para todo: desde una pelota de fútbol hasta los planetas. El ICFES te da situaciones cotidianas y te pregunta cuál ley aplica.'
      },
      {
        type: 'explanation',
        title: '1ª Ley: La Ley de la Inercia',
        text: 'Un objeto quieto sigue quieto, y uno en movimiento sigue moviéndose, a menos que una fuerza lo cambie. Ejemplo: Cuando el bus frena de golpe, tú sigues hacia adelante (tu cuerpo quería seguir moviéndose). Por eso existen los cinturones de seguridad.',
        highlight: 'Clave: Si no hay fuerza neta, el movimiento no cambia.'
      },
      {
        type: 'explanation',
        title: '2ª Ley: F = ma',
        text: 'La fuerza necesaria para mover algo depende de su masa y de cuánto quieres que acelere. F = masa × aceleración. Ejemplo: Es más difícil empujar un bus que una bicicleta (más masa = necesitas más fuerza para la misma aceleración).',
        highlight: 'F = ma es la fórmula más importante de física en el ICFES.'
      },
      {
        type: 'explanation',
        title: '3ª Ley: Acción y Reacción',
        text: 'Por cada fuerza que ejerces, hay una fuerza igual pero en dirección contraria. Ejemplo: Cuando saltas, empujas el suelo hacia abajo y el suelo te empuja hacia arriba. Los cohetes funcionan así: expulsan gas hacia abajo y el cohete sube.',
        highlight: 'Las fuerzas de acción y reacción actúan sobre objetos DIFERENTES, no sobre el mismo.'
      }
    ],
    quiz: [
      {
        id: 'sci-2-q1',
        question: 'Un pasajero va en un bus que frena bruscamente. El pasajero siente que su cuerpo se lanza hacia adelante. ¿Cuál ley de Newton explica mejor este fenómeno?',
        options: [
          { id: 'a', text: 'La tercera ley: el bus ejerce una fuerza sobre el pasajero' },
          { id: 'b', text: 'La segunda ley: la aceleración del pasajero es proporcional a la fuerza' },
          { id: 'c', text: 'La primera ley: el cuerpo del pasajero tiende a seguir en movimiento' },
          { id: 'd', text: 'La ley de gravitación: la gravedad jala al pasajero hacia adelante' }
        ],
        correctId: 'c',
        explanation: 'La primera ley (inercia): el cuerpo del pasajero estaba en movimiento y tiende a seguir moviéndose hacia adelante aunque el bus haya frenado. Por eso los cinturones de seguridad son obligatorios.',
        tip: 'Inercia = resistencia al cambio de movimiento. Si algo sigue moviéndose cuando debería parar (o viceversa) → primera ley.',
        difficulty: 'medio'
      }
    ]
  }
];

// ============================================================
// DATOS DE LECCIONES - SOCIALES Y CIUDADANAS
// ============================================================

const socialLessons: Lesson[] = [
  {
    id: 'soc-1',
    title: 'La Constitución de 1991: Tus Derechos',
    subtitle: 'Lo que la ley dice que tienes derecho a tener',
    level: 'basico',
    difficulty: 'facil',
    duration: 20,
    xp: 60,
    glossary: [
      {
        term: 'Constitución',
        simple: 'El libro de reglas más importante del país. Dice cómo funciona el gobierno y cuáles son los derechos de todos los colombianos.',
        technical: 'Norma jurídica suprema que establece los principios fundamentales del Estado y los derechos de los ciudadanos.'
      },
      {
        term: 'Derechos fundamentales',
        simple: 'Los derechos más básicos que tiene toda persona por el simple hecho de ser humano. Nadie te los puede quitar.',
        technical: 'Derechos consagrados en el Título II de la Constitución de 1991, de aplicación inmediata y protegidos por tutela.'
      },
      {
        term: 'Acción de tutela',
        simple: 'Un mecanismo legal para proteger tus derechos fundamentales cuando alguien los viola. Es como una "queja urgente" ante un juez.',
        technical: 'Mecanismo constitucional de protección inmediata de derechos fundamentales. Art. 86 C.P.'
      },
      {
        term: 'Estado Social de Derecho',
        simple: 'La forma de gobierno de Colombia donde el Estado tiene que garantizar no solo las leyes sino también el bienestar de los ciudadanos.',
        technical: 'Modelo estatal que combina el Estado de Derecho con obligaciones de garantía de derechos sociales, económicos y culturales.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: 'La Constitución del 91: Un antes y un después',
        text: 'En 1991, Colombia cambió su Constitución. Antes había una del 1886 que era muy vieja y no protegía bien a los ciudadanos. La nueva Constitución fue escrita con participación de muchos grupos, incluyendo indígenas y exguerrilleros. Es considerada una de las más avanzadas del mundo en derechos humanos.'
      },
      {
        type: 'explanation',
        title: 'Los derechos fundamentales más importantes',
        text: 'Artículo 11: Derecho a la vida. Artículo 13: Igualdad (todos somos iguales ante la ley). Artículo 16: Libre desarrollo de la personalidad. Artículo 18: Libertad de conciencia. Artículo 20: Libertad de expresión. Artículo 44: Derechos de los niños (prevalecen sobre los demás).',
        highlight: 'El ICFES pregunta: ¿Cuál derecho aplica en esta situación? Aprende los más importantes y en qué situaciones aplican.'
      },
      {
        type: 'explanation',
        title: 'La Tutela: Tu herramienta más poderosa',
        text: 'Si alguien viola tus derechos fundamentales, puedes poner una tutela. El juez tiene 10 días para responder. Ejemplo: Si una EPS te niega un medicamento urgente, puedes poner tutela. Si un colegio te expulsa sin proceso, puedes poner tutela.',
        highlight: 'La tutela solo protege derechos FUNDAMENTALES (los del Título II). Para otros derechos hay otras acciones.'
      }
    ],
    quiz: [
      {
        id: 'soc-1-q1',
        question: 'Una estudiante es expulsada de su colegio sin que le hayan dado la oportunidad de defenderse ni explicar su versión de los hechos. ¿Cuál mecanismo constitucional puede usar para proteger sus derechos?',
        options: [
          { id: 'a', text: 'Una demanda civil por daños y perjuicios' },
          { id: 'b', text: 'Una acción de tutela por violación al debido proceso' },
          { id: 'c', text: 'Una queja ante la Defensoría del Pueblo' },
          { id: 'd', text: 'Un recurso de apelación ante el Ministerio de Educación' }
        ],
        correctId: 'b',
        explanation: 'El debido proceso (Art. 29 C.P.) es un derecho fundamental. Cuando se viola, la tutela es el mecanismo adecuado porque protege derechos fundamentales de forma inmediata (el juez tiene 10 días para responder).',
        tip: 'Tutela = violación de derechos FUNDAMENTALES + necesidad de respuesta URGENTE. Si el derecho no es fundamental o no es urgente, hay otros mecanismos.',
        difficulty: 'facil'
      }
    ]
  },
  {
    id: 'soc-2',
    title: 'Historia de Colombia: Los Momentos Clave',
    subtitle: 'Lo que pasó y por qué importa hoy',
    level: 'intermedio',
    difficulty: 'medio',
    duration: 25,
    xp: 80,
    glossary: [
      {
        term: 'El Bogotazo',
        simple: 'El 9 de abril de 1948, asesinaron al político Jorge Eliécer Gaitán en Bogotá. Esto desató una ola de violencia enorme en todo el país que cambió la historia de Colombia.',
        technical: 'Período de violencia urbana desencadenado el 9 de abril de 1948 tras el asesinato de Jorge Eliécer Gaitán, líder del Partido Liberal.'
      },
      {
        term: 'La Violencia',
        simple: 'Un período entre 1948 y 1958 donde liberales y conservadores se mataban entre sí en Colombia. Murieron más de 200.000 personas.',
        technical: 'Conflicto bipartidista colombiano (1948-1958) caracterizado por enfrentamientos armados entre liberales y conservadores.'
      },
      {
        term: 'Frente Nacional',
        simple: 'Un acuerdo entre liberales y conservadores (1958-1974) para turnarse el poder y acabar con La Violencia. Funcionó para parar la guerra, pero excluyó a otros partidos.',
        technical: 'Acuerdo político colombiano por el cual liberales y conservadores se alternaron la presidencia durante 16 años.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Por qué estudiar historia para el ICFES?',
        text: 'El ICFES no te pide memorizar fechas. Te da un texto histórico y te pregunta si lo entiendes: causas, consecuencias, contexto. La historia de Colombia es especialmente importante porque explica muchos problemas actuales del país.'
      },
      {
        type: 'explanation',
        title: 'La línea del tiempo que debes conocer',
        text: '1810: Independencia de España. 1886: Primera Constitución moderna. 1948: El Bogotazo y inicio de La Violencia. 1958: Frente Nacional (acuerdo de paz bipartidista). 1991: Nueva Constitución. 2016: Acuerdo de paz con las FARC.',
        highlight: 'El ICFES conecta eventos históricos con problemas actuales. Pregunta: ¿Por qué Colombia tiene conflicto armado? La respuesta está en la historia.'
      },
      {
        type: 'example',
        title: 'Ejemplo del ICFES real',
        text: 'El examen puede darte una crónica sobre El Bogotazo y preguntarte: "¿Cuál es el tema general del texto?" La respuesta no es "la muerte de Gaitán" (eso es demasiado específico) sino "las consecuencias violentas inmediatas al asesinato de Gaitán" (más amplio y preciso).'
      }
    ],
    quiz: [
      {
        id: 'soc-2-q1',
        question: 'El 9 de abril de 1948 fue asesinado Jorge Eliécer Gaitán en Bogotá. Esto desencadenó una ola de violencia que se extendió por todo el país. ¿Cómo se conoce históricamente este período de violencia que siguió al asesinato?',
        options: [
          { id: 'a', text: 'La Regeneración' },
          { id: 'b', text: 'El Bogotazo y el inicio de La Violencia' },
          { id: 'c', text: 'La Guerra de los Mil Días' },
          { id: 'd', text: 'El Frente Nacional' }
        ],
        correctId: 'b',
        explanation: 'El asesinato de Gaitán el 9 de abril de 1948 desencadenó El Bogotazo (los disturbios inmediatos en Bogotá) y marcó el inicio del período conocido como "La Violencia" (1948-1958), un conflicto bipartidista que dejó más de 200.000 muertos.',
        tip: 'El Bogotazo = los disturbios del 9 de abril en Bogotá. La Violencia = el período de conflicto que siguió (1948-1958).',
        difficulty: 'medio'
      }
    ]
  }
];

// ============================================================
// DATOS DE LECCIONES - INGLÉS
// ============================================================

const englishLessons: Lesson[] = [
  {
    id: 'eng-1',
    title: 'Vocabulario Básico: Las Palabras Más Comunes',
    subtitle: 'Las 200 palabras en inglés que más aparecen en el ICFES',
    level: 'basico',
    difficulty: 'facil',
    duration: 20,
    xp: 50,
    glossary: [
      {
        term: 'Cognados',
        simple: 'Palabras en inglés que se parecen al español y significan lo mismo. Como "information" (información), "important" (importante), "national" (nacional). ¡Son tus aliados!',
        technical: 'Palabras de dos idiomas que tienen origen etimológico común y significado similar.'
      },
      {
        term: 'Falsos cognados',
        simple: 'Palabras en inglés que parecen español pero significan algo diferente. "Actually" no significa "actualmente" sino "en realidad". ¡Cuidado con estos!',
        technical: 'Palabras de apariencia similar en dos idiomas pero con significados diferentes.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: '¿Cómo es el inglés del ICFES?',
        text: 'El ICFES evalúa inglés en 3 niveles: A1 (básico), A2 (elemental) y B1 (intermedio). La mayoría de preguntas son de A1 y A2. No necesitas hablar inglés perfecto, solo leer y entender textos sencillos. ¡Tú puedes!'
      },
      {
        type: 'explanation',
        title: 'Tu superpoder: Los cognados',
        text: 'Muchas palabras en inglés se parecen al español: information=información, important=importante, national=nacional, president=presidente, education=educación, technology=tecnología, communication=comunicación. Si ves una palabra larga en inglés que termina en -tion, -sion, -ity, probablemente tiene un equivalente en español.',
        highlight: 'Regla de oro: Palabras que terminan en -tion en inglés → -ción en español. Nation → Nación. Action → Acción.'
      },
      {
        type: 'explanation',
        title: 'Palabras básicas que debes memorizar',
        text: 'Verbos: is/are (es/son), have/has (tiene), can (puede), go (ir), come (venir), make (hacer), take (tomar), give (dar), know (saber), think (pensar). Conectores: and (y), but (pero), because (porque), however (sin embargo), therefore (por lo tanto).',
        highlight: 'Los conectores son clave para entender la relación entre ideas en un texto en inglés.'
      },
      {
        type: 'tip',
        title: '💡 Estrategia para el inglés del ICFES',
        text: 'Si no entiendes una palabra, usa el contexto. Lee la oración completa y las de alrededor. El significado muchas veces se puede deducir. Además, las preguntas del ICFES en inglés siempre tienen las opciones en español, así que solo necesitas entender el texto en inglés.'
      }
    ],
    quiz: [
      {
        id: 'eng-1-q1',
        context: 'Read the text: "The education system in Colombia has improved significantly in recent years. More students now have access to technology and quality teachers. However, there are still important challenges in rural areas."',
        question: '¿De qué trata principalmente el texto?',
        options: [
          { id: 'a', text: 'De los problemas de tecnología en Colombia' },
          { id: 'b', text: 'De las mejoras y desafíos del sistema educativo colombiano' },
          { id: 'c', text: 'De la calidad de los profesores rurales' },
          { id: 'd', text: 'Del acceso a internet en las ciudades' }
        ],
        correctId: 'b',
        explanation: 'El texto habla de mejoras en educación ("has improved", "more students have access") pero también de desafíos ("challenges in rural areas"). La opción B captura ambas ideas. Palabras clave: education system, improved, challenges.',
        tip: 'En inglés, "however" (sin embargo) introduce una idea contraria. Antes del "however" hay algo positivo, después algo negativo.',
        difficulty: 'facil'
      }
    ]
  },
  {
    id: 'eng-2',
    title: 'Gramática Básica: Tiempos Verbales',
    subtitle: 'Presente, pasado y futuro en inglés',
    level: 'intermedio',
    difficulty: 'medio',
    duration: 25,
    xp: 80,
    glossary: [
      {
        term: 'Simple Present',
        simple: 'El tiempo presente en inglés. Se usa para hábitos, hechos y verdades generales. "She works every day" = Ella trabaja todos los días.',
        technical: 'Tiempo verbal que expresa acciones habituales, verdades generales o estados permanentes.'
      },
      {
        term: 'Simple Past',
        simple: 'El tiempo pasado en inglés. Se usa para acciones que ya terminaron. "He worked yesterday" = Él trabajó ayer.',
        technical: 'Tiempo verbal que expresa acciones completadas en un momento específico del pasado.'
      },
      {
        term: 'Present Perfect',
        simple: 'Un tiempo que conecta el pasado con el presente. "She has lived here for 5 years" = Ella ha vivido aquí por 5 años (y todavía vive aquí).',
        technical: 'Tiempo verbal que expresa acciones pasadas con relevancia en el presente, formado con have/has + participio pasado.'
      }
    ],
    content: [
      {
        type: 'intro',
        title: 'Los tiempos verbales en el ICFES',
        text: 'El ICFES te puede preguntar qué tiempo verbal se usa en una oración, o pedirte completar un texto con el tiempo correcto. No necesitas memorizar reglas complicadas, solo entender cuándo se usa cada uno.'
      },
      {
        type: 'explanation',
        title: 'Simple Present: El presente de siempre',
        text: 'Uso: hábitos ("I eat breakfast every day"), hechos ("Water boils at 100°C"), horarios ("The bus leaves at 8am"). Forma: sujeto + verbo (+ s para he/she/it). "She works, He plays, It rains."',
        highlight: 'Palabras clave del Simple Present: always, usually, often, sometimes, never, every day/week/month.'
      },
      {
        type: 'explanation',
        title: 'Simple Past: Lo que ya pasó',
        text: 'Uso: acciones terminadas en el pasado. Forma: sujeto + verbo-ed (regulares) o forma especial (irregulares). "worked, played, went, came, made". Palabras clave: yesterday, last week, in 1990, ago.',
        highlight: 'Los verbos irregulares más comunes: go→went, come→came, make→made, take→took, have→had, be→was/were.'
      }
    ],
    quiz: [
      {
        id: 'eng-2-q1',
        context: 'Complete the sentence: "Yesterday, the students _____ (study) for the ICFES exam for three hours."',
        question: '¿Cuál es la forma correcta del verbo "study" para completar la oración?',
        options: [
          { id: 'a', text: 'study' },
          { id: 'b', text: 'studies' },
          { id: 'c', text: 'studied' },
          { id: 'd', text: 'have studied' }
        ],
        correctId: 'c',
        explanation: 'La palabra "Yesterday" indica que la acción ocurrió en el pasado y ya terminó. Por eso se usa Simple Past: "studied" (study + ed). Recuerda: palabras como yesterday, last week, ago → Simple Past.',
        tip: 'Si ves "yesterday", "last...", "...ago" en la oración → Simple Past (verbo + ed o forma irregular).',
        difficulty: 'medio'
      }
    ]
  }
];

// ============================================================
// MÓDULOS COMPLETOS
// ============================================================

export const modules: Module[] = [
  {
    id: 'matematicas',
    title: 'Matemáticas',
    subtitle: 'Números, álgebra y estadística',
    description: 'Aprende desde las operaciones básicas hasta estadística y probabilidad. El ICFES siempre pone problemas de la vida real, ¡y tú los vas a resolver!',
    color: 'text-blue-700',
    bgColor: 'bg-blue-50',
    icon: '📐',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663562250835/kzEb9Pvj5jP4ub7j2gQyi7/math-module-bjDgSG69LVS2cbjNnNVvpj.webp',
    lessons: mathLessons,
    totalXp: mathLessons.reduce((sum, l) => sum + l.xp, 0)
  },
  {
    id: 'lectura',
    title: 'Lectura Crítica',
    subtitle: 'Comprensión y análisis de textos',
    description: 'Aprende a leer textos de todo tipo y a responder preguntas sobre lo que dicen, lo que implican y el propósito del autor.',
    color: 'text-amber-700',
    bgColor: 'bg-amber-50',
    icon: '📖',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663562250835/kzEb9Pvj5jP4ub7j2gQyi7/reading-module-g24uDu993mm6bVxamARe6N.webp',
    lessons: readingLessons,
    totalXp: readingLessons.reduce((sum, l) => sum + l.xp, 0)
  },
  {
    id: 'ciencias',
    title: 'Ciencias Naturales',
    subtitle: 'Biología, química y física',
    description: 'Desde la célula hasta las leyes del movimiento. Aprende ciencias con ejemplos de la vida cotidiana colombiana.',
    color: 'text-teal-700',
    bgColor: 'bg-teal-50',
    icon: '🔬',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663562250835/kzEb9Pvj5jP4ub7j2gQyi7/science-module-8DYyJwxWyQk8zBZXcfZkeF.webp',
    lessons: scienceLessons,
    totalXp: scienceLessons.reduce((sum, l) => sum + l.xp, 0)
  },
  {
    id: 'sociales',
    title: 'Sociales y Ciudadanas',
    subtitle: 'Historia, geografía y constitución',
    description: 'Conoce la historia de Colombia, tus derechos como ciudadano y cómo funciona el país. ¡Es tu historia!',
    color: 'text-orange-700',
    bgColor: 'bg-orange-50',
    icon: '🗺️',
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663562250835/kzEb9Pvj5jP4ub7j2gQyi7/social-module-BARbQQUSpGZJ6LRwtrCUHr.webp',
    lessons: socialLessons,
    totalXp: socialLessons.reduce((sum, l) => sum + l.xp, 0)
  },
  {
    id: 'ingles',
    title: 'Inglés',
    subtitle: 'Vocabulario, gramática y comprensión',
    description: 'Aprende el inglés que necesitas para el ICFES. Empezamos desde cero con vocabulario básico hasta leer textos completos.',
    color: 'text-purple-700',
    bgColor: 'bg-purple-50',
    icon: '🌎',
    image: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=400&q=80',
    lessons: englishLessons,
    totalXp: englishLessons.reduce((sum, l) => sum + l.xp, 0)
  }
];

// ============================================================
// SIMULACRO COMPLETO
// ============================================================

export const simulacroQuestions: QuizQuestion[] = [
  // Matemáticas
  {
    id: 'sim-1',
    question: 'En una tienda, cada camiseta cuesta $25.000. Si compras 3 o más camisetas, obtienes un descuento de $5.000 por camiseta. ¿Cuánto pagas si compras exactamente 3 camisetas con descuento?',
    options: [
      { id: 'a', text: '$75.000' },
      { id: 'b', text: '$60.000' },
      { id: 'c', text: '$70.000' },
      { id: 'd', text: '$65.000' }
    ],
    correctId: 'b',
    explanation: 'Con descuento, cada camiseta cuesta $25.000 - $5.000 = $20.000. Por 3 camisetas: 3 × $20.000 = $60.000.',
    difficulty: 'facil'
  },
  {
    id: 'sim-2',
    question: 'Las temperaturas registradas en una ciudad durante 5 días fueron: 18°C, 22°C, 18°C, 25°C, 18°C. ¿Cuál es la moda de estas temperaturas?',
    options: [
      { id: 'a', text: '22°C' },
      { id: 'b', text: '25°C' },
      { id: 'c', text: '18°C' },
      { id: 'd', text: '20.2°C' }
    ],
    correctId: 'c',
    explanation: '18°C aparece 3 veces (es la que más se repite). 22°C aparece 1 vez. 25°C aparece 1 vez. La moda es 18°C.',
    difficulty: 'facil'
  },
  // Lectura Crítica
  {
    id: 'sim-3',
    context: '"Los jóvenes que pasan tiempo en redes sociales aprenden habilidades digitales que no se enseñan en la escuela. Sin embargo, esto puede generar una brecha entre las prácticas escolares y las prácticas digitales de los jóvenes."',
    question: '¿Cuál es la función de la palabra "Sin embargo" en el texto?',
    options: [
      { id: 'a', text: 'Introduce una causa de lo anterior' },
      { id: 'b', text: 'Introduce una restricción o contraste con lo anterior' },
      { id: 'c', text: 'Introduce un ejemplo de lo anterior' },
      { id: 'd', text: 'Introduce una conclusión de lo anterior' }
    ],
    correctId: 'b',
    explanation: '"Sin embargo" es un conector de contraste o restricción. Introduce una idea que limita o contradice lo dicho antes. Antes: las redes enseñan cosas buenas. Después: pero esto puede crear problemas.',
    difficulty: 'medio'
  },
  // Ciencias
  {
    id: 'sim-4',
    question: 'Un experimento muestra que las plantas colocadas en la oscuridad total pierden su color verde y mueren. ¿Cuál es la conclusión más adecuada?',
    options: [
      { id: 'a', text: 'Las plantas necesitan agua para producir clorofila' },
      { id: 'b', text: 'Las plantas necesitan luz para realizar fotosíntesis y sobrevivir' },
      { id: 'c', text: 'Las plantas mueren porque el suelo no tiene nutrientes' },
      { id: 'd', text: 'La oscuridad produce una sustancia tóxica para las plantas' }
    ],
    correctId: 'b',
    explanation: 'La clorofila (pigmento verde) se produce en los cloroplastos durante la fotosíntesis, que requiere luz. Sin luz → no hay fotosíntesis → no hay energía → la planta muere y pierde su color verde.',
    difficulty: 'medio'
  },
  // Sociales
  {
    id: 'sim-5',
    question: 'La Constitución de 1991 establece que Colombia es un "Estado Social de Derecho". ¿Qué significa principalmente esto?',
    options: [
      { id: 'a', text: 'Que el Estado puede hacer lo que quiera sin restricciones' },
      { id: 'b', text: 'Que el Estado debe respetar las leyes y garantizar el bienestar de los ciudadanos' },
      { id: 'c', text: 'Que solo los ciudadanos ricos tienen derechos' },
      { id: 'd', text: 'Que el Estado controla todos los negocios del país' }
    ],
    correctId: 'b',
    explanation: '"Estado de Derecho" significa que el Estado está sometido a las leyes (nadie está por encima de la ley). "Social" significa que el Estado tiene obligaciones de garantizar derechos sociales como salud, educación y vivienda.',
    difficulty: 'medio'
  }
];

// ============================================================
// GLOSARIO GENERAL
// ============================================================

export const generalGlossary: GlossaryTerm[] = [
  {
    term: 'Hipótesis',
    simple: 'Una suposición o idea que se quiere comprobar. Es como decir "creo que esto pasa porque..." y luego hacer un experimento para verificarlo.',
    technical: 'Proposición provisional que se formula para ser verificada o refutada mediante evidencia empírica.'
  },
  {
    term: 'Variable',
    simple: 'Algo que puede cambiar o variar. En un experimento, es lo que cambias o lo que mides.',
    technical: 'Característica o atributo que puede tomar diferentes valores en una investigación.'
  },
  {
    term: 'Argumento',
    simple: 'Una razón que das para apoyar una idea. No es pelear, es dar razones lógicas.',
    technical: 'Razonamiento que se emplea para demostrar o justificar una proposición.'
  },
  {
    term: 'Contexto',
    simple: 'Las circunstancias que rodean algo. Para entender una frase, necesitas saber el contexto: ¿quién lo dijo? ¿cuándo? ¿por qué?',
    technical: 'Conjunto de circunstancias que rodean un hecho o enunciado y que contribuyen a su significado.'
  },
  {
    term: 'Inferir',
    simple: 'Sacar una conclusión que no está dicha directamente, usando la lógica y la información disponible.',
    technical: 'Proceso de derivar conclusiones a partir de premisas o evidencias mediante razonamiento lógico.'
  },
  {
    term: 'Síntesis',
    simple: 'Resumir las ideas principales de algo en pocas palabras. No es copiar, es entender y reescribir con tus propias palabras.',
    technical: 'Elaboración de un resumen que integra las ideas principales de un texto o conjunto de información.'
  }
];

export default modules;
