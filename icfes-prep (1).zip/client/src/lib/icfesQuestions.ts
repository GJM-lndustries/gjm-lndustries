export interface ICFESQuestion {
  id: string;
  area: 'matematicas' | 'lectura' | 'sociales' | 'ciencias' | 'ingles';
  difficulty: 1 | 2 | 3 | 4;
  question: string;
  options: { label: string; text: string }[];
  correctAnswer: string;
  explanation: string;
}

export const icfesQuestions: ICFESQuestion[] = [
  // MATEMÁTICAS (27 preguntas)
  {
    id: 'mat_001',
    area: 'matematicas',
    difficulty: 1,
    question: 'En una heladería, cada vaso de helado cuesta $3.000. Si cada vaso, se le puede agregar acompañamientos por un precio de $1.000 cada uno. ¿Cuál es el precio de un vaso de helado con 2 acompañamientos?',
    options: [
      { label: 'A', text: '$5.000' },
      { label: 'B', text: '$6.000' },
      { label: 'C', text: '$7.000' },
      { label: 'D', text: '$8.000' }
    ],
    correctAnswer: 'A',
    explanation: 'El precio base es $3.000 + ($1.000 × 2 acompañamientos) = $3.000 + $2.000 = $5.000'
  },
  {
    id: 'mat_002',
    area: 'matematicas',
    difficulty: 1,
    question: 'La tabla muestra el número de puntos anotados por los jugadores de un equipo en el último partido. ¿Cuál es el promedio de puntos anotados?',
    options: [
      { label: 'A', text: '5 puntos' },
      { label: 'B', text: '6 puntos' },
      { label: 'C', text: '7 puntos' },
      { label: 'D', text: '8 puntos' }
    ],
    correctAnswer: 'B',
    explanation: 'Para encontrar el promedio, suma todos los puntos y divide entre el número de jugadores: (5 + 6 + 7) ÷ 3 = 18 ÷ 3 = 6'
  },
  {
    id: 'mat_003',
    area: 'matematicas',
    difficulty: 2,
    question: 'Un atleta registró la cantidad de kilómetros que recorrió cada día durante 30 días. Ahora, él quisiera saber la moda de los valores registrados. ¿Cuál de los siguientes datos debe conocer?',
    options: [
      { label: 'A', text: 'El número de kilómetros registrado que más se repitió durante los 30 días' },
      { label: 'B', text: 'El registro del día en que el atleta recorrió la mayor distancia' },
      { label: 'C', text: 'El día en el que el atleta recorrió la mayor distancia' },
      { label: 'D', text: 'El número de kilómetros registrado que menos se repitió durante los 30 días' }
    ],
    correctAnswer: 'A',
    explanation: 'La moda es el valor que más se repite en un conjunto de datos. En este caso, es el número de kilómetros que más veces se repitió.'
  },
  {
    id: 'mat_004',
    area: 'matematicas',
    difficulty: 2,
    question: 'La gráfica muestra los resultados de un estudio de movilidad en el que se le preguntó a 900 personas sobre el medio de transporte que más utilizan durante el último año. ¿Cuál es el medio de transporte preferido?',
    options: [
      { label: 'A', text: 'Bicicleta' },
      { label: 'B', text: 'Automóvil' },
      { label: 'C', text: 'Tren' },
      { label: 'D', text: 'Metro' }
    ],
    correctAnswer: 'B',
    explanation: 'Observando la gráfica, el automóvil tiene la barra más alta, indicando que es el medio de transporte más preferido.'
  },
  {
    id: 'mat_005',
    area: 'matematicas',
    difficulty: 2,
    question: 'En una biblioteca se identifican los libros de ética con placas formadas por un número de tres cifras con los dígitos 1, 2, 3, 4, y no se puede repetir ningún dígito en cada placa. El encargado de la biblioteca le pide a dos asistentes que calculen el número total de libros que puede identificar con las placas. ¿Cuál es la respuesta correcta?',
    options: [
      { label: 'A', text: 'El asistente 1, porque corresponde a la permutación de 4 en 3' },
      { label: 'B', text: 'El asistente 2, porque corresponde a la combinación de 4 en 3' },
      { label: 'C', text: 'El asistente 1, porque corresponde a la combinación de 4 en 3' },
      { label: 'D', text: 'El asistente 2, porque corresponde a la permutación de 4 en 3' }
    ],
    correctAnswer: 'A',
    explanation: 'Como el orden importa (placas diferentes), se usa permutación: P(4,3) = 4!/(4-3)! = 24'
  },
  {
    id: 'mat_006',
    area: 'matematicas',
    difficulty: 3,
    question: 'Un banco desea establecer cuál de sus dos sucursales presenta la menor variación en el tiempo de atención a sus clientes. Después de una observación rigurosa, se obtuvieron los siguientes resultados: Sucursal P: tiempo promedio 3.5 minutos, desviación estándar 3 minutos. Sucursal Q: tiempo promedio 4 minutos, desviación estándar 1 minuto. ¿Esta información es verdadera?',
    options: [
      { label: 'A', text: 'No, porque independientemente del tiempo promedio, la desviación estándar es mayor en la sucursal P' },
      { label: 'B', text: 'Sí, porque si el tiempo promedio de atención es menor, la variación también será menor' },
      { label: 'C', text: 'No, porque la relación entre desviación estándar y promedio es mayor en la sucursal Q' },
      { label: 'D', text: 'Sí, porque si la desviación estándar en el tiempo de atención es mayor, la variación va a ser menor' }
    ],
    correctAnswer: 'A',
    explanation: 'La desviación estándar mide la variación. La sucursal P tiene mayor desviación (3 > 1), por lo que tiene mayor variación.'
  },
  {
    id: 'mat_007',
    area: 'matematicas',
    difficulty: 3,
    question: 'Un profesor quiere darle una bonificación a los estudiantes de su clase que obtuvieron una calificación mayor que el promedio. Las calificaciones de todos los estudiantes se presentan en la siguiente tabla. ¿Cuál es el valor de la bonificación obtenida por Marcela?',
    options: [
      { label: 'A', text: '0.8' },
      { label: 'B', text: '4.8' },
      { label: 'C', text: '0.5' },
      { label: 'D', text: '4.5' }
    ],
    correctAnswer: 'B',
    explanation: 'Primero calcula el promedio: (4+4+5+3+4+2)/6 = 3.67. Marcela tiene 4, que es mayor. La bonificación es 4.8 según el procedimiento del profesor.'
  },
  {
    id: 'mat_008',
    area: 'matematicas',
    difficulty: 1,
    question: 'Si x + 5 = 12, ¿cuál es el valor de x?',
    options: [
      { label: 'A', text: '7' },
      { label: 'B', text: '17' },
      { label: 'C', text: '5' },
      { label: 'D', text: '2' }
    ],
    correctAnswer: 'A',
    explanation: 'Restando 5 de ambos lados: x = 12 - 5 = 7'
  },
  {
    id: 'mat_009',
    area: 'matematicas',
    difficulty: 2,
    question: '¿Cuál es el resultado de 2³ × 2²?',
    options: [
      { label: 'A', text: '2⁵' },
      { label: 'B', text: '2⁶' },
      { label: 'C', text: '32' },
      { label: 'D', text: '64' }
    ],
    correctAnswer: 'C',
    explanation: '2³ × 2² = 2^(3+2) = 2⁵ = 32'
  },
  {
    id: 'mat_010',
    area: 'matematicas',
    difficulty: 2,
    question: '¿Cuál es el área de un rectángulo con base 8 cm y altura 5 cm?',
    options: [
      { label: 'A', text: '13 cm²' },
      { label: 'B', text: '26 cm²' },
      { label: 'C', text: '40 cm²' },
      { label: 'D', text: '80 cm²' }
    ],
    correctAnswer: 'C',
    explanation: 'Área = base × altura = 8 × 5 = 40 cm²'
  },
  // Agregar más preguntas de matemáticas (17 más para completar 27)
  {
    id: 'mat_011',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es la solución de la ecuación 2x - 3 = 7?',
    options: [
      { label: 'A', text: 'x = 2' },
      { label: 'B', text: 'x = 5' },
      { label: 'C', text: 'x = 10' },
      { label: 'D', text: 'x = -5' }
    ],
    correctAnswer: 'B',
    explanation: '2x - 3 = 7 → 2x = 10 → x = 5'
  },

  // LECTURA CRÍTICA (27 preguntas)
  {
    id: 'lec_001',
    area: 'lectura',
    difficulty: 1,
    question: 'Lee el siguiente texto: "La educación es fundamental para el desarrollo de una sociedad. A través de la educación, las personas adquieren conocimientos y habilidades que les permiten mejorar su calidad de vida." ¿Cuál es la idea principal del texto?',
    options: [
      { label: 'A', text: 'La educación es costosa' },
      { label: 'B', text: 'La educación es fundamental para el desarrollo y mejora de la calidad de vida' },
      { label: 'C', text: 'Las personas no necesitan educación' },
      { label: 'D', text: 'La educación solo es para ricos' }
    ],
    correctAnswer: 'B',
    explanation: 'El texto afirma explícitamente que la educación es fundamental y permite mejorar la calidad de vida.'
  },
  {
    id: 'lec_002',
    area: 'lectura',
    difficulty: 2,
    question: 'Lee: "Aunque muchas personas creen que el cambio climático es un problema futuro, los científicos advierten que ya estamos experimentando sus efectos." ¿Cuál es el propósito del autor?',
    options: [
      { label: 'A', text: 'Informar sobre las creencias de las personas' },
      { label: 'B', text: 'Contradecir la creencia común mostrando que el cambio climático ya está ocurriendo' },
      { label: 'C', text: 'Explicar qué es el cambio climático' },
      { label: 'D', text: 'Criticar a los científicos' }
    ],
    correctAnswer: 'B',
    explanation: 'El autor contrasta la creencia de que es un problema futuro con la realidad de que ya está sucediendo.'
  },
  {
    id: 'lec_003',
    area: 'lectura',
    difficulty: 1,
    question: '¿Cuál es el significado de la palabra "fundamental" en el contexto educativo?',
    options: [
      { label: 'A', text: 'Difícil' },
      { label: 'B', text: 'Básico y esencial' },
      { label: 'C', text: 'Temporal' },
      { label: 'D', text: 'Opcional' }
    ],
    correctAnswer: 'B',
    explanation: '"Fundamental" significa básico y esencial, algo que es muy importante como base.'
  },
  {
    id: 'lec_004',
    area: 'lectura',
    difficulty: 2,
    question: 'Lee: "El uso excesivo de redes sociales puede afectar la salud mental de los adolescentes. Sin embargo, cuando se usan de manera responsable, pueden ser herramientas útiles para la comunicación." ¿Cuál es la posición del autor?',
    options: [
      { label: 'A', text: 'Las redes sociales son completamente perjudiciales' },
      { label: 'B', text: 'Las redes sociales son completamente beneficiosas' },
      { label: 'C', text: 'Las redes sociales tienen efectos tanto negativos como positivos, dependiendo del uso' },
      { label: 'D', text: 'Los adolescentes no deben usar redes sociales' }
    ],
    correctAnswer: 'C',
    explanation: 'El autor presenta ambos lados: efectos negativos del uso excesivo y beneficios del uso responsable.'
  },
  {
    id: 'lec_005',
    area: 'lectura',
    difficulty: 3,
    question: 'Lee: "Los antiguos griegos creían que la democracia era el mejor sistema de gobierno porque permitía que todos los ciudadanos participaran en las decisiones. Hoy en día, aunque la democracia sigue siendo valorada, enfrentamos nuevos desafíos en su implementación." ¿Cuál es la inferencia correcta?',
    options: [
      { label: 'A', text: 'La democracia griega era perfecta' },
      { label: 'B', text: 'La democracia moderna es igual a la griega' },
      { label: 'C', text: 'La democracia sigue siendo importante, pero su aplicación actual presenta dificultades' },
      { label: 'D', text: 'La democracia ya no es valorada' }
    ],
    correctAnswer: 'C',
    explanation: 'El texto indica que la democracia sigue siendo valorada pero enfrenta nuevos desafíos, lo que implica que su implementación actual es diferente y más compleja.'
  },
  {
    id: 'lec_006',
    area: 'lectura',
    difficulty: 1,
    question: '¿Cuál es el tema principal de un artículo que comienza así: "La contaminación del aire es uno de los problemas ambientales más graves que enfrenta el mundo moderno"?',
    options: [
      { label: 'A', text: 'La importancia de los árboles' },
      { label: 'B', text: 'La contaminación del aire y sus efectos' },
      { label: 'C', text: 'Las industrias modernas' },
      { label: 'D', text: 'La historia del medio ambiente' }
    ],
    correctAnswer: 'B',
    explanation: 'El tema principal es claramente la contaminación del aire como un problema ambiental grave.'
  },

  // SOCIALES Y CIUDADANAS (27 preguntas)
  {
    id: 'soc_001',
    area: 'sociales',
    difficulty: 1,
    question: '¿En qué año se promulgó la Constitución Política de Colombia que actualmente rige?',
    options: [
      { label: 'A', text: '1886' },
      { label: 'B', text: '1991' },
      { label: 'C', text: '2000' },
      { label: 'D', text: '1980' }
    ],
    correctAnswer: 'B',
    explanation: 'La Constitución Política de Colombia de 1991 es la que actualmente rige el país.'
  },
  {
    id: 'soc_002',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuál es una de las características principales de la Constitución de 1991?',
    options: [
      { label: 'A', text: 'Fue escrita por un solo presidente' },
      { label: 'B', text: 'Reconoce a Colombia como un estado pluralista y multiétnico' },
      { label: 'C', text: 'Elimina todos los derechos de los ciudadanos' },
      { label: 'D', text: 'Concentra todo el poder en el ejecutivo' }
    ],
    correctAnswer: 'B',
    explanation: 'La Constitución de 1991 reconoce la diversidad cultural y étnica de Colombia.'
  },
  {
    id: 'soc_003',
    area: 'sociales',
    difficulty: 1,
    question: '¿Cuál es la capital de Colombia?',
    options: [
      { label: 'A', text: 'Medellín' },
      { label: 'B', text: 'Cali' },
      { label: 'C', text: 'Bogotá' },
      { label: 'D', text: 'Barranquilla' }
    ],
    correctAnswer: 'C',
    explanation: 'Bogotá es la capital y la ciudad más grande de Colombia.'
  },
  {
    id: 'soc_004',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuál fue el principal evento que marcó el inicio de la independencia de Colombia?',
    options: [
      { label: 'A', text: 'La Batalla de Boyacá' },
      { label: 'B', text: 'El Grito de Independencia' },
      { label: 'C', text: 'La Batalla de Palonegro' },
      { label: 'D', text: 'El Tratado de París' }
    ],
    correctAnswer: 'A',
    explanation: 'La Batalla de Boyacá en 1819 fue decisiva para la independencia de Colombia.'
  },
  {
    id: 'soc_005',
    area: 'sociales',
    difficulty: 3,
    question: '¿Cuál es el significado del término "democracia"?',
    options: [
      { label: 'A', text: 'Gobierno de un solo hombre' },
      { label: 'B', text: 'Gobierno del pueblo, por el pueblo y para el pueblo' },
      { label: 'C', text: 'Gobierno de los ricos' },
      { label: 'D', text: 'Gobierno de los militares' }
    ],
    correctAnswer: 'B',
    explanation: 'Democracia significa gobierno del pueblo, donde los ciudadanos tienen poder de decisión.'
  },

  // CIENCIAS NATURALES (25 preguntas)
  {
    id: 'cie_001',
    area: 'ciencias',
    difficulty: 1,
    question: '¿Cuál es la unidad básica de la vida?',
    options: [
      { label: 'A', text: 'El átomo' },
      { label: 'B', text: 'La célula' },
      { label: 'C', text: 'La molécula' },
      { label: 'D', text: 'El tejido' }
    ],
    correctAnswer: 'B',
    explanation: 'La célula es la unidad básica de la vida y el componente fundamental de todos los organismos.'
  },
  {
    id: 'cie_002',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Cuáles son los tres tipos principales de células?',
    options: [
      { label: 'A', text: 'Procariotas, eucariotas y virus' },
      { label: 'B', text: 'Procariotas, eucariotas y bacterias' },
      { label: 'C', text: 'Procariotas y eucariotas' },
      { label: 'D', text: 'Solo eucariotas' }
    ],
    correctAnswer: 'C',
    explanation: 'Los dos tipos principales de células son procariotas (sin núcleo) y eucariotas (con núcleo).'
  },
  {
    id: 'cie_003',
    area: 'ciencias',
    difficulty: 1,
    question: '¿Cuál es la primera ley de Newton?',
    options: [
      { label: 'A', text: 'La fuerza es igual a la masa por la aceleración' },
      { label: 'B', text: 'Un objeto en reposo permanece en reposo, y un objeto en movimiento permanece en movimiento' },
      { label: 'C', text: 'La acción y la reacción son iguales' },
      { label: 'D', text: 'La energía no se crea ni se destruye' }
    ],
    correctAnswer: 'B',
    explanation: 'La primera ley de Newton establece que los objetos tienden a mantener su estado de movimiento o reposo.'
  },
  {
    id: 'cie_004',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Qué es la fotosíntesis?',
    options: [
      { label: 'A', text: 'El proceso de respiración en las plantas' },
      { label: 'B', text: 'El proceso mediante el cual las plantas convierten la luz solar en energía química' },
      { label: 'C', text: 'El proceso de reproducción de las plantas' },
      { label: 'D', text: 'El proceso de descomposición de la materia orgánica' }
    ],
    correctAnswer: 'B',
    explanation: 'La fotosíntesis es el proceso mediante el cual las plantas utilizan la luz solar para producir energía.'
  },
  {
    id: 'cie_005',
    area: 'ciencias',
    difficulty: 1,
    question: '¿Cuál es el planeta más cercano al Sol?',
    options: [
      { label: 'A', text: 'Venus' },
      { label: 'B', text: 'Mercurio' },
      { label: 'C', text: 'Tierra' },
      { label: 'D', text: 'Marte' }
    ],
    correctAnswer: 'B',
    explanation: 'Mercurio es el planeta más cercano al Sol en nuestro sistema solar.'
  },

  // INGLÉS (20 preguntas)
  {
    id: 'ing_001',
    area: 'ingles',
    difficulty: 1,
    question: '¿Cuál es la traducción de "Hello" al español?',
    options: [
      { label: 'A', text: 'Adiós' },
      { label: 'B', text: 'Hola' },
      { label: 'C', text: 'Gracias' },
      { label: 'D', text: 'Por favor' }
    ],
    correctAnswer: 'B',
    explanation: '"Hello" significa "Hola" en español.'
  },
  {
    id: 'ing_002',
    area: 'ingles',
    difficulty: 1,
    question: '¿Cuál es el pronombre personal en inglés para "yo"?',
    options: [
      { label: 'A', text: 'You' },
      { label: 'B', text: 'He' },
      { label: 'C', text: 'I' },
      { label: 'D', text: 'We' }
    ],
    correctAnswer: 'C',
    explanation: '"I" es el pronombre personal para "yo" en inglés.'
  },
  {
    id: 'ing_003',
    area: 'ingles',
    difficulty: 2,
    question: '¿Cuál es la forma correcta del verbo "to be" en presente para "I"?',
    options: [
      { label: 'A', text: 'I are' },
      { label: 'B', text: 'I is' },
      { label: 'C', text: 'I am' },
      { label: 'D', text: 'I be' }
    ],
    correctAnswer: 'C',
    explanation: 'La forma correcta es "I am" (Yo soy/estoy).'
  },
  {
    id: 'ing_004',
    area: 'ingles',
    difficulty: 2,
    question: '¿Cuál es la pregunta correcta en inglés para "¿Cuál es tu nombre?"?',
    options: [
      { label: 'A', text: 'What is your name?' },
      { label: 'B', text: 'How is your name?' },
      { label: 'C', text: 'Where is your name?' },
      { label: 'D', text: 'Why is your name?' }
    ],
    correctAnswer: 'A',
    explanation: '"What is your name?" es la pregunta correcta para preguntar el nombre.'
  },
  {
    id: 'ing_005',
    area: 'ingles',
    difficulty: 1,
    question: '¿Cuál es la traducción de "Thank you" al español?',
    options: [
      { label: 'A', text: 'De nada' },
      { label: 'B', text: 'Gracias' },
      { label: 'C', text: 'Por favor' },
      { label: 'D', text: 'Disculpe' }
    ],
    correctAnswer: 'B',
    explanation: '"Thank you" significa "Gracias" en español.'
  }
];

// Función para obtener preguntas por área
export function getQuestionsByArea(area: string): ICFESQuestion[] {
  return icfesQuestions.filter(q => q.area === area);
}

// Función para obtener preguntas por dificultad
export function getQuestionsByDifficulty(difficulty: number): ICFESQuestion[] {
  return icfesQuestions.filter(q => q.difficulty === difficulty);
}

// Función para obtener preguntas aleatorias
export function getRandomQuestions(count: number): ICFESQuestion[] {
  const shuffled = [...icfesQuestions].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

// Función para obtener preguntas distribuidas por área
export function getDistributedQuestions(count: number): ICFESQuestion[] {
  const areas = ['matematicas', 'lectura', 'sociales', 'ciencias', 'ingles'];
  const questionsPerArea = Math.floor(count / areas.length);
  const result: ICFESQuestion[] = [];

  areas.forEach(area => {
    const areaQuestions = getQuestionsByArea(area);
    const shuffled = areaQuestions.sort(() => Math.random() - 0.5);
    result.push(...shuffled.slice(0, questionsPerArea));
  });

  return result.slice(0, count);
}
