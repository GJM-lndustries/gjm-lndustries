export interface ICFESQuestion {
  id: string;
  area: 'matematicas' | 'lectura' | 'sociales' | 'ciencias' | 'ingles';
  difficulty: 1 | 2 | 3 | 4;
  question: string;
  options: { label: string; text: string }[];
  correctAnswer: string;
  explanation: string;
}

export const icfesQuestionsExpanded: ICFESQuestion[] = [
  // MATEMÁTICAS (30 preguntas)
  {
    id: 'mat_001',
    area: 'matematicas',
    difficulty: 1,
    question: '¿Cuál es el resultado de 45 + 37?',
    options: [
      { label: 'A', text: '72' },
      { label: 'B', text: '82' },
      { label: 'C', text: '92' },
      { label: 'D', text: '102' }
    ],
    correctAnswer: 'B',
    explanation: '45 + 37 = 82. Es una suma básica de dos números.'
  },
  {
    id: 'mat_002',
    area: 'matematicas',
    difficulty: 1,
    question: '¿Cuál es el resultado de 120 ÷ 5?',
    options: [
      { label: 'A', text: '20' },
      { label: 'B', text: '24' },
      { label: 'C', text: '30' },
      { label: 'D', text: '40' }
    ],
    correctAnswer: 'B',
    explanation: '120 ÷ 5 = 24. Es una división básica.'
  },
  {
    id: 'mat_003',
    area: 'matematicas',
    difficulty: 1,
    question: 'Si un producto cuesta $15.000 y tiene un descuento del 20%, ¿cuál es el precio final?',
    options: [
      { label: 'A', text: '$10.000' },
      { label: 'B', text: '$12.000' },
      { label: 'C', text: '$13.000' },
      { label: 'D', text: '$14.000' }
    ],
    correctAnswer: 'B',
    explanation: 'El 20% de $15.000 es $3.000. Entonces: $15.000 - $3.000 = $12.000'
  },
  {
    id: 'mat_004',
    area: 'matematicas',
    difficulty: 2,
    question: '¿Cuál es el promedio de los números 10, 20, 30, 40?',
    options: [
      { label: 'A', text: '20' },
      { label: 'B', text: '25' },
      { label: 'C', text: '30' },
      { label: 'D', text: '35' }
    ],
    correctAnswer: 'B',
    explanation: 'Promedio = (10 + 20 + 30 + 40) ÷ 4 = 100 ÷ 4 = 25'
  },
  {
    id: 'mat_005',
    area: 'matematicas',
    difficulty: 2,
    question: 'En una encuesta, 60% de 500 personas prefieren el café. ¿Cuántas personas prefieren el café?',
    options: [
      { label: 'A', text: '200' },
      { label: 'B', text: '250' },
      { label: 'C', text: '300' },
      { label: 'D', text: '350' }
    ],
    correctAnswer: 'C',
    explanation: '60% de 500 = 0.60 × 500 = 300 personas'
  },
  {
    id: 'mat_006',
    area: 'matematicas',
    difficulty: 2,
    question: '¿Cuál es la moda del conjunto: 5, 7, 5, 9, 5, 3?',
    options: [
      { label: 'A', text: '3' },
      { label: 'B', text: '5' },
      { label: 'C', text: '7' },
      { label: 'D', text: '9' }
    ],
    correctAnswer: 'B',
    explanation: 'La moda es el número que más se repite. El 5 aparece 3 veces, más que los otros.'
  },
  {
    id: 'mat_007',
    area: 'matematicas',
    difficulty: 2,
    question: 'Si x + 10 = 25, ¿cuál es el valor de x?',
    options: [
      { label: 'A', text: '10' },
      { label: 'B', text: '15' },
      { label: 'C', text: '20' },
      { label: 'D', text: '35' }
    ],
    correctAnswer: 'B',
    explanation: 'x + 10 = 25. Restamos 10 de ambos lados: x = 25 - 10 = 15'
  },
  {
    id: 'mat_008',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es la probabilidad de sacar un número par al lanzar un dado?',
    options: [
      { label: 'A', text: '1/6' },
      { label: 'B', text: '1/3' },
      { label: 'C', text: '1/2' },
      { label: 'D', text: '2/3' }
    ],
    correctAnswer: 'C',
    explanation: 'Los números pares en un dado son: 2, 4, 6 (3 de 6). Probabilidad = 3/6 = 1/2'
  },
  {
    id: 'mat_009',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuántas combinaciones de 2 elementos se pueden hacer con el conjunto {A, B, C}?',
    options: [
      { label: 'A', text: '2' },
      { label: 'B', text: '3' },
      { label: 'C', text: '6' },
      { label: 'D', text: '9' }
    ],
    correctAnswer: 'B',
    explanation: 'Las combinaciones son: AB, AC, BC. Total = 3 combinaciones'
  },
  {
    id: 'mat_010',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es el área de un rectángulo con base 8 cm y altura 5 cm?',
    options: [
      { label: 'A', text: '13 cm²' },
      { label: 'B', text: '26 cm²' },
      { label: 'C', text: '40 cm²' },
      { label: 'D', text: '64 cm²' }
    ],
    correctAnswer: 'C',
    explanation: 'Área = base × altura = 8 × 5 = 40 cm²'
  },
  {
    id: 'mat_011',
    area: 'matematicas',
    difficulty: 3,
    question: 'Si 2x - 5 = 11, ¿cuál es el valor de x?',
    options: [
      { label: 'A', text: '3' },
      { label: 'B', text: '6' },
      { label: 'C', text: '8' },
      { label: 'D', text: '16' }
    ],
    correctAnswer: 'C',
    explanation: '2x - 5 = 11. Sumamos 5: 2x = 16. Dividimos por 2: x = 8'
  },
  {
    id: 'mat_012',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es el resultado de (3 + 2)² - 10?',
    options: [
      { label: 'A', text: '5' },
      { label: 'B', text: '15' },
      { label: 'C', text: '25' },
      { label: 'D', text: '35' }
    ],
    correctAnswer: 'B',
    explanation: '(3 + 2)² - 10 = 5² - 10 = 25 - 10 = 15'
  },
  {
    id: 'mat_013',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es la mediana del conjunto: 3, 7, 2, 9, 5?',
    options: [
      { label: 'A', text: '2' },
      { label: 'B', text: '5' },
      { label: 'C', text: '6' },
      { label: 'D', text: '7' }
    ],
    correctAnswer: 'B',
    explanation: 'Ordenamos: 2, 3, 5, 7, 9. La mediana es el valor del medio: 5'
  },
  {
    id: 'mat_014',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es el perímetro de un triángulo equilátero con lado 6 cm?',
    options: [
      { label: 'A', text: '12 cm' },
      { label: 'B', text: '18 cm' },
      { label: 'C', text: '24 cm' },
      { label: 'D', text: '36 cm' }
    ],
    correctAnswer: 'B',
    explanation: 'Perímetro = 3 × lado = 3 × 6 = 18 cm'
  },
  {
    id: 'mat_015',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es la solución de 3(x + 2) = 21?',
    options: [
      { label: 'A', text: '5' },
      { label: 'B', text: '7' },
      { label: 'C', text: '9' },
      { label: 'D', text: '11' }
    ],
    correctAnswer: 'A',
    explanation: '3(x + 2) = 21. Dividimos por 3: x + 2 = 7. Restamos 2: x = 5'
  },
  {
    id: 'mat_016',
    area: 'matematicas',
    difficulty: 1,
    question: '¿Cuál es el resultado de 8 × 7?',
    options: [
      { label: 'A', text: '48' },
      { label: 'B', text: '54' },
      { label: 'C', text: '56' },
      { label: 'D', text: '64' }
    ],
    correctAnswer: 'C',
    explanation: '8 × 7 = 56'
  },
  {
    id: 'mat_017',
    area: 'matematicas',
    difficulty: 2,
    question: '¿Cuál es el 25% de 200?',
    options: [
      { label: 'A', text: '25' },
      { label: 'B', text: '50' },
      { label: 'C', text: '75' },
      { label: 'D', text: '100' }
    ],
    correctAnswer: 'B',
    explanation: '25% de 200 = 0.25 × 200 = 50'
  },
  {
    id: 'mat_018',
    area: 'matematicas',
    difficulty: 2,
    question: 'En una clase hay 30 estudiantes. Si 2/3 aprobaron el examen, ¿cuántos aprobaron?',
    options: [
      { label: 'A', text: '10' },
      { label: 'B', text: '15' },
      { label: 'C', text: '20' },
      { label: 'D', text: '25' }
    ],
    correctAnswer: 'C',
    explanation: '2/3 de 30 = (2 × 30) ÷ 3 = 60 ÷ 3 = 20'
  },
  {
    id: 'mat_019',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es el volumen de un cubo con lado 3 cm?',
    options: [
      { label: 'A', text: '9 cm³' },
      { label: 'B', text: '18 cm³' },
      { label: 'C', text: '27 cm³' },
      { label: 'D', text: '36 cm³' }
    ],
    correctAnswer: 'C',
    explanation: 'Volumen = lado³ = 3³ = 27 cm³'
  },
  {
    id: 'mat_020',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es el resultado de √64?',
    options: [
      { label: 'A', text: '6' },
      { label: 'B', text: '8' },
      { label: 'C', text: '10' },
      { label: 'D', text: '12' }
    ],
    correctAnswer: 'B',
    explanation: '√64 = 8, porque 8 × 8 = 64'
  },
  {
    id: 'mat_021',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es el resultado de 2³?',
    options: [
      { label: 'A', text: '6' },
      { label: 'B', text: '8' },
      { label: 'C', text: '9' },
      { label: 'D', text: '12' }
    ],
    correctAnswer: 'B',
    explanation: '2³ = 2 × 2 × 2 = 8'
  },
  {
    id: 'mat_022',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es la desviación estándar del conjunto: 2, 4, 6, 8?',
    options: [
      { label: 'A', text: '√5' },
      { label: 'B', text: '√10' },
      { label: 'C', text: '√15' },
      { label: 'D', text: '√20' }
    ],
    correctAnswer: 'A',
    explanation: 'Media = 5. Desviación estándar = √((9+1+1+9)/4) = √5'
  },
  {
    id: 'mat_023',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es la pendiente de la línea que pasa por (0,0) y (2,4)?',
    options: [
      { label: 'A', text: '1' },
      { label: 'B', text: '2' },
      { label: 'C', text: '3' },
      { label: 'D', text: '4' }
    ],
    correctAnswer: 'B',
    explanation: 'Pendiente = (y₂ - y₁)/(x₂ - x₁) = (4 - 0)/(2 - 0) = 4/2 = 2'
  },
  {
    id: 'mat_024',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es la solución de x² = 25?',
    options: [
      { label: 'A', text: 'x = 5' },
      { label: 'B', text: 'x = -5' },
      { label: 'C', text: 'x = 5 o x = -5' },
      { label: 'D', text: 'x = 25' }
    ],
    correctAnswer: 'C',
    explanation: 'x² = 25 tiene dos soluciones: x = 5 (porque 5² = 25) y x = -5 (porque (-5)² = 25)'
  },
  {
    id: 'mat_025',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es el máximo común divisor de 24 y 36?',
    options: [
      { label: 'A', text: '6' },
      { label: 'B', text: '12' },
      { label: 'C', text: '18' },
      { label: 'D', text: '24' }
    ],
    correctAnswer: 'B',
    explanation: 'Divisores de 24: 1, 2, 3, 4, 6, 8, 12, 24. Divisores de 36: 1, 2, 3, 4, 6, 9, 12, 18, 36. MCD = 12'
  },
  {
    id: 'mat_026',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es el mínimo común múltiplo de 4 y 6?',
    options: [
      { label: 'A', text: '12' },
      { label: 'B', text: '24' },
      { label: 'C', text: '36' },
      { label: 'D', text: '48' }
    ],
    correctAnswer: 'A',
    explanation: 'Múltiplos de 4: 4, 8, 12, 16... Múltiplos de 6: 6, 12, 18... MCM = 12'
  },
  {
    id: 'mat_027',
    area: 'matematicas',
    difficulty: 4,
    question: '¿Cuál es la solución de 2x + 3 = x + 5?',
    options: [
      { label: 'A', text: '1' },
      { label: 'B', text: '2' },
      { label: 'C', text: '3' },
      { label: 'D', text: '4' }
    ],
    correctAnswer: 'B',
    explanation: '2x + 3 = x + 5. Restamos x: x + 3 = 5. Restamos 3: x = 2'
  },
  {
    id: 'mat_028',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es el resultado de 1/2 + 1/4?',
    options: [
      { label: 'A', text: '1/6' },
      { label: 'B', text: '2/6' },
      { label: 'C', text: '3/4' },
      { label: 'D', text: '5/4' }
    ],
    correctAnswer: 'C',
    explanation: '1/2 + 1/4 = 2/4 + 1/4 = 3/4'
  },
  {
    id: 'mat_029',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es el resultado de 3/4 × 2/3?',
    options: [
      { label: 'A', text: '1/2' },
      { label: 'B', text: '5/12' },
      { label: 'C', text: '6/12' },
      { label: 'D', text: '1/4' }
    ],
    correctAnswer: 'A',
    explanation: '3/4 × 2/3 = 6/12 = 1/2'
  },
  {
    id: 'mat_030',
    area: 'matematicas',
    difficulty: 3,
    question: '¿Cuál es el resultado de 5/6 ÷ 2/3?',
    options: [
      { label: 'A', text: '5/9' },
      { label: 'B', text: '10/18' },
      { label: 'C', text: '5/4' },
      { label: 'D', text: '15/12' }
    ],
    correctAnswer: 'C',
    explanation: '5/6 ÷ 2/3 = 5/6 × 3/2 = 15/12 = 5/4'
  },

  // LECTURA CRÍTICA (25 preguntas)
  {
    id: 'lec_001',
    area: 'lectura',
    difficulty: 1,
    question: 'Según el texto, ¿cuál es el tema principal?',
    options: [
      { label: 'A', text: 'La importancia de la lectura' },
      { label: 'B', text: 'Los beneficios de estudiar' },
      { label: 'C', text: 'Cómo mejorar la concentración' },
      { label: 'D', text: 'El valor del tiempo' }
    ],
    correctAnswer: 'A',
    explanation: 'El texto enfatiza cómo la lectura es fundamental para el aprendizaje.'
  },
  {
    id: 'lec_002',
    area: 'lectura',
    difficulty: 1,
    question: '¿Cuál es la idea principal del párrafo?',
    options: [
      { label: 'A', text: 'Los libros son caros' },
      { label: 'B', text: 'La lectura desarrolla la imaginación' },
      { label: 'C', text: 'Todos deben leer' },
      { label: 'D', text: 'Los escritores son importantes' }
    ],
    correctAnswer: 'B',
    explanation: 'El párrafo destaca cómo la lectura estimula la imaginación y creatividad.'
  },
  {
    id: 'lec_003',
    area: 'lectura',
    difficulty: 2,
    question: '¿Cuál es la intención del autor al escribir este texto?',
    options: [
      { label: 'A', text: 'Informar sobre libros' },
      { label: 'B', text: 'Persuadir al lector sobre los beneficios de leer' },
      { label: 'C', text: 'Entretener con una historia' },
      { label: 'D', text: 'Criticar a los no lectores' }
    ],
    correctAnswer: 'B',
    explanation: 'El autor busca convencer al lector de que la lectura es beneficiosa.'
  },
  {
    id: 'lec_004',
    area: 'lectura',
    difficulty: 2,
    question: '¿Qué significa la palabra "erudito" en el contexto?',
    options: [
      { label: 'A', text: 'Persona que estudia mucho' },
      { label: 'B', text: 'Persona con amplio conocimiento' },
      { label: 'C', text: 'Persona que enseña' },
      { label: 'D', text: 'Persona que escribe libros' }
    ],
    correctAnswer: 'B',
    explanation: 'Erudito se refiere a una persona con vasto conocimiento y cultura.'
  },
  {
    id: 'lec_005',
    area: 'lectura',
    difficulty: 2,
    question: '¿Cuál es la relación entre los dos párrafos?',
    options: [
      { label: 'A', text: 'El segundo contradice al primero' },
      { label: 'B', text: 'El segundo amplía la idea del primero' },
      { label: 'C', text: 'No hay relación' },
      { label: 'D', text: 'El segundo es una conclusión' }
    ],
    correctAnswer: 'B',
    explanation: 'El segundo párrafo proporciona ejemplos y detalles que amplían lo dicho en el primero.'
  },
  {
    id: 'lec_006',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es la conclusión que se puede inferir del texto?',
    options: [
      { label: 'A', text: 'La lectura es una pérdida de tiempo' },
      { label: 'B', text: 'La lectura es fundamental para el desarrollo personal' },
      { label: 'C', text: 'Solo los inteligentes pueden leer' },
      { label: 'D', text: 'La lectura es un entretenimiento' }
    ],
    correctAnswer: 'B',
    explanation: 'El texto sugiere que la lectura es esencial para crecer como persona.'
  },
  {
    id: 'lec_007',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es el tono del autor?',
    options: [
      { label: 'A', text: 'Irónico' },
      { label: 'B', text: 'Persuasivo y positivo' },
      { label: 'C', text: 'Negativo' },
      { label: 'D', text: 'Neutral' }
    ],
    correctAnswer: 'B',
    explanation: 'El autor usa un tono que busca convencer al lector de forma positiva.'
  },
  {
    id: 'lec_008',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es el propósito del ejemplo mencionado?',
    options: [
      { label: 'A', text: 'Ilustrar un concepto' },
      { label: 'B', text: 'Entretener al lector' },
      { label: 'C', text: 'Criticar una idea' },
      { label: 'D', text: 'Cambiar de tema' }
    ],
    correctAnswer: 'A',
    explanation: 'El ejemplo sirve para clarificar y demostrar la idea principal del texto.'
  },
  {
    id: 'lec_009',
    area: 'lectura',
    difficulty: 4,
    question: '¿Cuál es la diferencia entre lo que el autor dice explícitamente y lo que implica?',
    options: [
      { label: 'A', text: 'No hay diferencia' },
      { label: 'B', text: 'Lo explícito es más importante' },
      { label: 'C', text: 'Lo implícito requiere inferencia del lector' },
      { label: 'D', text: 'Lo implícito es menos verdadero' }
    ],
    correctAnswer: 'C',
    explanation: 'Lo implícito es lo que se entiende sin ser dicho directamente; requiere que el lector haga inferencias.'
  },
  {
    id: 'lec_010',
    area: 'lectura',
    difficulty: 4,
    question: '¿Cuál es la crítica implícita en el texto?',
    options: [
      { label: 'A', text: 'Los libros son aburridos' },
      { label: 'B', text: 'Muchas personas no valoran la lectura' },
      { label: 'C', text: 'Los autores no escriben bien' },
      { label: 'D', text: 'Las bibliotecas son inaccesibles' }
    ],
    correctAnswer: 'B',
    explanation: 'El texto implica que hay personas que no reconocen la importancia de la lectura.'
  },
  {
    id: 'lec_011',
    area: 'lectura',
    difficulty: 2,
    question: '¿Cuál es el significado de "perspectiva" en el texto?',
    options: [
      { label: 'A', text: 'Punto de vista' },
      { label: 'B', text: 'Futuro' },
      { label: 'C', text: 'Esperanza' },
      { label: 'D', text: 'Visión' }
    ],
    correctAnswer: 'A',
    explanation: 'Perspectiva significa el punto de vista o forma de ver las cosas.'
  },
  {
    id: 'lec_012',
    area: 'lectura',
    difficulty: 2,
    question: '¿Cuál es la estructura del texto?',
    options: [
      { label: 'A', text: 'Introducción, desarrollo y conclusión' },
      { label: 'B', text: 'Solo preguntas' },
      { label: 'C', text: 'Solo ejemplos' },
      { label: 'D', text: 'Caótica' }
    ],
    correctAnswer: 'A',
    explanation: 'El texto sigue una estructura clásica: presenta la idea, la desarrolla y la concluye.'
  },
  {
    id: 'lec_013',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es la relación de causa y efecto en el texto?',
    options: [
      { label: 'A', text: 'La lectura causa ignorancia' },
      { label: 'B', text: 'La lectura causa desarrollo intelectual' },
      { label: 'C', text: 'No hay relación' },
      { label: 'D', text: 'La ignorancia causa lectura' }
    ],
    correctAnswer: 'B',
    explanation: 'El texto establece que la lectura (causa) produce desarrollo intelectual (efecto).'
  },
  {
    id: 'lec_014',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es el público objetivo del texto?',
    options: [
      { label: 'A', text: 'Solo estudiantes' },
      { label: 'B', text: 'Solo adultos' },
      { label: 'C', text: 'Personas de todas las edades' },
      { label: 'D', text: 'Solo escritores' }
    ],
    correctAnswer: 'C',
    explanation: 'El mensaje sobre la importancia de la lectura es relevante para cualquier persona.'
  },
  {
    id: 'lec_015',
    area: 'lectura',
    difficulty: 4,
    question: '¿Cuál es la suposición principal del autor?',
    options: [
      { label: 'A', text: 'Que todos pueden leer' },
      { label: 'B', text: 'Que la lectura es valiosa' },
      { label: 'C', text: 'Que los libros son baratos' },
      { label: 'D', text: 'Que todos aman leer' }
    ],
    correctAnswer: 'B',
    explanation: 'El autor asume que la lectura tiene valor y beneficios para las personas.'
  },
  {
    id: 'lec_016',
    area: 'lectura',
    difficulty: 1,
    question: '¿Cuál es la respuesta a la pregunta del texto?',
    options: [
      { label: 'A', text: 'Sí' },
      { label: 'B', text: 'No' },
      { label: 'C', text: 'Depende' },
      { label: 'D', text: 'No se menciona' }
    ],
    correctAnswer: 'D',
    explanation: 'La respuesta específica no se proporciona en el texto.'
  },
  {
    id: 'lec_017',
    area: 'lectura',
    difficulty: 2,
    question: '¿Cuál es el sentimiento predominante en el texto?',
    options: [
      { label: 'A', text: 'Tristeza' },
      { label: 'B', text: 'Alegría' },
      { label: 'C', text: 'Entusiasmo' },
      { label: 'D', text: 'Miedo' }
    ],
    correctAnswer: 'C',
    explanation: 'El texto expresa entusiasmo por los beneficios de la lectura.'
  },
  {
    id: 'lec_018',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es la evidencia que apoya la afirmación principal?',
    options: [
      { label: 'A', text: 'Estadísticas' },
      { label: 'B', text: 'Ejemplos y razonamientos' },
      { label: 'C', text: 'Opiniones personales' },
      { label: 'D', text: 'Citas de otros autores' }
    ],
    correctAnswer: 'B',
    explanation: 'El texto usa ejemplos y razonamientos lógicos para apoyar sus afirmaciones.'
  },
  {
    id: 'lec_019',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es la contradicción en el texto?',
    options: [
      { label: 'A', text: 'No hay contradicción' },
      { label: 'B', text: 'Entre lo que dice y lo que hace' },
      { label: 'C', text: 'Entre dos ideas' },
      { label: 'D', text: 'Entre el título y el contenido' }
    ],
    correctAnswer: 'A',
    explanation: 'El texto es coherente y no presenta contradicciones.'
  },
  {
    id: 'lec_020',
    area: 'lectura',
    difficulty: 4,
    question: '¿Cuál es la implicación ética del texto?',
    options: [
      { label: 'A', text: 'Que leer es un deber moral' },
      { label: 'B', text: 'Que leer es un derecho' },
      { label: 'C', text: 'Que leer es un lujo' },
      { label: 'D', text: 'No hay implicación ética' }
    ],
    correctAnswer: 'B',
    explanation: 'El texto sugiere que el acceso a la lectura es un derecho importante para todos.'
  },
  {
    id: 'lec_021',
    area: 'lectura',
    difficulty: 2,
    question: '¿Cuál es el tipo de texto?',
    options: [
      { label: 'A', text: 'Narrativo' },
      { label: 'B', text: 'Descriptivo' },
      { label: 'C', text: 'Argumentativo' },
      { label: 'D', text: 'Poético' }
    ],
    correctAnswer: 'C',
    explanation: 'El texto presenta argumentos para convencer al lector.'
  },
  {
    id: 'lec_022',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es la generalización hecha en el texto?',
    options: [
      { label: 'A', text: 'Todos los libros son buenos' },
      { label: 'B', text: 'La lectura beneficia a todos' },
      { label: 'C', text: 'Nadie lee' },
      { label: 'D', text: 'Los libros son caros' }
    ],
    correctAnswer: 'B',
    explanation: 'El texto generaliza que la lectura es beneficiosa para todas las personas.'
  },
  {
    id: 'lec_023',
    area: 'lectura',
    difficulty: 4,
    question: '¿Cuál es la falacia lógica, si la hay?',
    options: [
      { label: 'A', text: 'Ad hominem' },
      { label: 'B', text: 'Generalización apresurada' },
      { label: 'C', text: 'No hay falacia' },
      { label: 'D', text: 'Falsa dicotomía' }
    ],
    correctAnswer: 'C',
    explanation: 'El texto mantiene una lógica coherente sin falacias evidentes.'
  },
  {
    id: 'lec_024',
    area: 'lectura',
    difficulty: 4,
    question: '¿Cuál es la premisa no declarada en el argumento?',
    options: [
      { label: 'A', text: 'Que la lectura es importante' },
      { label: 'B', text: 'Que todos pueden leer' },
      { label: 'C', text: 'Que los libros existen' },
      { label: 'D', text: 'Que la educación es valiosa' }
    ],
    correctAnswer: 'D',
    explanation: 'El texto asume que la educación (de la cual la lectura es parte) es valiosa.'
  },
  {
    id: 'lec_025',
    area: 'lectura',
    difficulty: 3,
    question: '¿Cuál es la recomendación implícita del autor?',
    options: [
      { label: 'A', text: 'Leer más' },
      { label: 'B', text: 'Dejar de leer' },
      { label: 'C', text: 'Comprar libros' },
      { label: 'D', text: 'Ir a la biblioteca' }
    ],
    correctAnswer: 'A',
    explanation: 'El autor implícitamente recomienda que las personas lean más para beneficiarse.'
  },

  // CIENCIAS NATURALES (20 preguntas)
  {
    id: 'cie_001',
    area: 'ciencias',
    difficulty: 1,
    question: '¿Cuál es la unidad básica de la vida?',
    options: [
      { label: 'A', text: 'El átomo' },
      { label: 'B', text: 'La célula' },
      { label: 'C', text: 'El tejido' },
      { label: 'D', text: 'El órgano' }
    ],
    correctAnswer: 'B',
    explanation: 'La célula es la unidad más pequeña de vida que puede funcionar independientemente.'
  },
  {
    id: 'cie_002',
    area: 'ciencias',
    difficulty: 1,
    question: '¿Cuál es la velocidad de la luz?',
    options: [
      { label: 'A', text: '100.000 km/s' },
      { label: 'B', text: '300.000 km/s' },
      { label: 'C', text: '500.000 km/s' },
      { label: 'D', text: '1.000.000 km/s' }
    ],
    correctAnswer: 'B',
    explanation: 'La velocidad de la luz es aproximadamente 300.000 km/s o 3 × 10⁸ m/s.'
  },
  {
    id: 'cie_003',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Cuál es la primera ley de Newton?',
    options: [
      { label: 'A', text: 'La ley de la gravedad' },
      { label: 'B', text: 'La ley de la inercia' },
      { label: 'C', text: 'La ley de la acción y reacción' },
      { label: 'D', text: 'La ley del movimiento' }
    ],
    correctAnswer: 'B',
    explanation: 'La primera ley de Newton (ley de la inercia) establece que un objeto en reposo permanece en reposo y uno en movimiento permanece en movimiento a menos que actúe una fuerza sobre él.'
  },
  {
    id: 'cie_004',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Cuál es la fórmula de la segunda ley de Newton?',
    options: [
      { label: 'A', text: 'F = m/a' },
      { label: 'B', text: 'F = m × a' },
      { label: 'C', text: 'F = a/m' },
      { label: 'D', text: 'F = m + a' }
    ],
    correctAnswer: 'B',
    explanation: 'La segunda ley de Newton es F = m × a (Fuerza = masa × aceleración).'
  },
  {
    id: 'cie_005',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Cuál es la tercera ley de Newton?',
    options: [
      { label: 'A', text: 'Acción y reacción son iguales' },
      { label: 'B', text: 'Acción y reacción son opuestas pero iguales en magnitud' },
      { label: 'C', text: 'La acción es mayor que la reacción' },
      { label: 'D', text: 'No hay relación entre acción y reacción' }
    ],
    correctAnswer: 'B',
    explanation: 'La tercera ley de Newton establece que a toda acción corresponde una reacción igual pero en dirección opuesta.'
  },
  {
    id: 'cie_006',
    area: 'ciencias',
    difficulty: 3,
    question: '¿Cuál es el proceso de fotosíntesis?',
    options: [
      { label: 'A', text: 'Convertir luz en energía química' },
      { label: 'B', text: 'Convertir energía química en luz' },
      { label: 'C', text: 'Convertir oxígeno en dióxido de carbono' },
      { label: 'D', text: 'Convertir agua en glucosa' }
    ],
    correctAnswer: 'A',
    explanation: 'La fotosíntesis es el proceso por el cual las plantas convierten la luz solar en energía química (glucosa).'
  },
  {
    id: 'cie_007',
    area: 'ciencias',
    difficulty: 3,
    question: '¿Cuál es la ecuación de la fotosíntesis?',
    options: [
      { label: 'A', text: '6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂' },
      { label: 'B', text: 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O' },
      { label: 'C', text: '6O₂ + C₆H₁₂O₆ → 6CO₂ + 6H₂O' },
      { label: 'D', text: '6CO₂ + 6O₂ → C₆H₁₂O₆ + 6H₂O' }
    ],
    correctAnswer: 'A',
    explanation: 'La ecuación de la fotosíntesis es: 6CO₂ + 6H₂O + luz → C₆H₁₂O₆ + 6O₂'
  },
  {
    id: 'cie_008',
    area: 'ciencias',
    difficulty: 3,
    question: '¿Cuál es la respiración celular?',
    options: [
      { label: 'A', text: 'El proceso de respiración pulmonar' },
      { label: 'B', text: 'El proceso de convertir glucosa en ATP' },
      { label: 'C', text: 'El proceso de intercambio de gases' },
      { label: 'D', text: 'El proceso de fotosíntesis' }
    ],
    correctAnswer: 'B',
    explanation: 'La respiración celular es el proceso metabólico que convierte la glucosa en ATP (energía utilizable por la célula).'
  },
  {
    id: 'cie_009',
    area: 'ciencias',
    difficulty: 4,
    question: '¿Cuál es la ecuación de la respiración celular?',
    options: [
      { label: 'A', text: 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ATP' },
      { label: 'B', text: '6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂' },
      { label: 'C', text: 'C₆H₁₂O₆ → 6CO₂ + 6H₂O' },
      { label: 'D', text: '6O₂ + ATP → C₆H₁₂O₆ + 6CO₂' }
    ],
    correctAnswer: 'A',
    explanation: 'La ecuación de la respiración celular es: C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energía (ATP)'
  },
  {
    id: 'cie_010',
    area: 'ciencias',
    difficulty: 4,
    question: '¿Cuál es la ley de la conservación de la energía?',
    options: [
      { label: 'A', text: 'La energía se crea de la nada' },
      { label: 'B', text: 'La energía se destruye' },
      { label: 'C', text: 'La energía no se crea ni se destruye, solo se transforma' },
      { label: 'D', text: 'La energía aumenta con el tiempo' }
    ],
    correctAnswer: 'C',
    explanation: 'La ley de la conservación de la energía establece que la energía no se crea ni se destruye, solo se transforma de una forma a otra.'
  },
  {
    id: 'cie_011',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Cuál es el ciclo del agua?',
    options: [
      { label: 'A', text: 'Evaporación, condensación, precipitación' },
      { label: 'B', text: 'Congelación, fusión, evaporación' },
      { label: 'C', text: 'Precipitación, evaporación, congelación' },
      { label: 'D', text: 'Fusión, evaporación, condensación' }
    ],
    correctAnswer: 'A',
    explanation: 'El ciclo del agua incluye: evaporación (agua se convierte en vapor), condensación (vapor se convierte en agua líquida) y precipitación (agua cae como lluvia o nieve).'
  },
  {
    id: 'cie_012',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Cuál es el ciclo del carbono?',
    options: [
      { label: 'A', text: 'Fotosíntesis y respiración' },
      { label: 'B', text: 'Evaporación y condensación' },
      { label: 'C', text: 'Fusión y fisión' },
      { label: 'D', text: 'Oxidación y reducción' }
    ],
    correctAnswer: 'A',
    explanation: 'El ciclo del carbono incluye la fotosíntesis (plantas absorben CO₂) y la respiración (organismos liberan CO₂).'
  },
  {
    id: 'cie_013',
    area: 'ciencias',
    difficulty: 3,
    question: '¿Cuál es el ciclo del nitrógeno?',
    options: [
      { label: 'A', text: 'Fijación, nitrificación, desnitrificación' },
      { label: 'B', text: 'Evaporación, condensación, precipitación' },
      { label: 'C', text: 'Fotosíntesis y respiración' },
      { label: 'D', text: 'Fusión y fisión' }
    ],
    correctAnswer: 'A',
    explanation: 'El ciclo del nitrógeno incluye: fijación (N₂ se convierte en NH₃), nitrificación (NH₃ se convierte en NO₃⁻) y desnitrificación (NO₃⁻ se convierte en N₂).'
  },
  {
    id: 'cie_014',
    area: 'ciencias',
    difficulty: 3,
    question: '¿Cuál es la ley de Coulomb?',
    options: [
      { label: 'A', text: 'F = k × q₁ × q₂ / r²' },
      { label: 'B', text: 'F = m × a' },
      { label: 'C', text: 'F = G × m₁ × m₂ / r²' },
      { label: 'D', text: 'F = q × v × B' }
    ],
    correctAnswer: 'A',
    explanation: 'La ley de Coulomb establece que la fuerza entre dos cargas es F = k × q₁ × q₂ / r².'
  },
  {
    id: 'cie_015',
    area: 'ciencias',
    difficulty: 4,
    question: '¿Cuál es la ley de la gravitación universal?',
    options: [
      { label: 'A', text: 'F = k × q₁ × q₂ / r²' },
      { label: 'B', text: 'F = m × a' },
      { label: 'C', text: 'F = G × m₁ × m₂ / r²' },
      { label: 'D', text: 'F = q × v × B' }
    ],
    correctAnswer: 'C',
    explanation: 'La ley de la gravitación universal establece que F = G × m₁ × m₂ / r², donde G es la constante gravitacional.'
  },
  {
    id: 'cie_016',
    area: 'ciencias',
    difficulty: 2,
    question: '¿Cuál es el ADN?',
    options: [
      { label: 'A', text: 'Ácido desoxirribonucleico' },
      { label: 'B', text: 'Ácido ribonucleico' },
      { label: 'C', text: 'Ácido desoxirribonucleoso' },
      { label: 'D', text: 'Ácido ribonucleoso' }
    ],
    correctAnswer: 'A',
    explanation: 'ADN es la abreviatura de Ácido desoxirribonucleico, que es la molécula que contiene la información genética.'
  },
  {
    id: 'cie_017',
    area: 'ciencias',
    difficulty: 3,
    question: '¿Cuál es la estructura del ADN?',
    options: [
      { label: 'A', text: 'Hélice simple' },
      { label: 'B', text: 'Doble hélice' },
      { label: 'C', text: 'Estructura circular' },
      { label: 'D', text: 'Estructura lineal' }
    ],
    correctAnswer: 'B',
    explanation: 'El ADN tiene una estructura de doble hélice, descubierta por Watson y Crick.'
  },
  {
    id: 'cie_018',
    area: 'ciencias',
    difficulty: 3,
    question: '¿Cuáles son las bases nitrogenadas del ADN?',
    options: [
      { label: 'A', text: 'Adenina, Timina, Guanina, Citosina' },
      { label: 'B', text: 'Adenina, Uracilo, Guanina, Citosina' },
      { label: 'C', text: 'Adenina, Timina, Guanina, Uracilo' },
      { label: 'D', text: 'Adenina, Timina, Guanina, Adenina' }
    ],
    correctAnswer: 'A',
    explanation: 'Las bases nitrogenadas del ADN son: Adenina (A), Timina (T), Guanina (G) y Citosina (C).'
  },
  {
    id: 'cie_019',
    area: 'ciencias',
    difficulty: 4,
    question: '¿Cuál es la regla de apareamiento de bases en el ADN?',
    options: [
      { label: 'A', text: 'A con T, G con C' },
      { label: 'B', text: 'A con G, T con C' },
      { label: 'C', text: 'A con C, T con G' },
      { label: 'D', text: 'A con A, T con T' }
    ],
    correctAnswer: 'A',
    explanation: 'La regla de apareamiento de bases es: Adenina (A) se aparea con Timina (T), y Guanina (G) se aparea con Citosina (C).'
  },
  {
    id: 'cie_020',
    area: 'ciencias',
    difficulty: 4,
    question: '¿Cuál es el proceso de replicación del ADN?',
    options: [
      { label: 'A', text: 'Transcripción' },
      { label: 'B', text: 'Traducción' },
      { label: 'C', text: 'Semiconservativa' },
      { label: 'D', text: 'Mitosis' }
    ],
    correctAnswer: 'C',
    explanation: 'La replicación del ADN es semiconservativa, lo que significa que cada nueva molécula de ADN contiene una cadena original y una cadena nueva.'
  },

  // SOCIALES Y CIUDADANAS (20 preguntas)
  {
    id: 'soc_001',
    area: 'sociales',
    difficulty: 1,
    question: '¿En qué año se proclamó la Constitución Política de Colombia?',
    options: [
      { label: 'A', text: '1886' },
      { label: 'B', text: '1991' },
      { label: 'C', text: '1810' },
      { label: 'D', text: '1950' }
    ],
    correctAnswer: 'B',
    explanation: 'La Constitución Política de Colombia fue proclamada el 4 de julio de 1991.'
  },
  {
    id: 'soc_002',
    area: 'sociales',
    difficulty: 1,
    question: '¿Cuál es la capital de Colombia?',
    options: [
      { label: 'A', text: 'Medellín' },
      { label: 'B', text: 'Cali' },
      { label: 'C', text: 'Bogotá' },
      { label: 'D', text: 'Barranquilla' }
    ],
    correctAnswer: 'C',
    explanation: 'Bogotá es la capital de Colombia y la ciudad más grande del país.'
  },
  {
    id: 'soc_003',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuál es el sistema político de Colombia?',
    options: [
      { label: 'A', text: 'Monarquía' },
      { label: 'B', text: 'República' },
      { label: 'C', text: 'Dictadura' },
      { label: 'D', text: 'Oligarquía' }
    ],
    correctAnswer: 'B',
    explanation: 'Colombia es una República presidencialista con separación de poderes.'
  },
  {
    id: 'soc_004',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuáles son los poderes del Estado en Colombia?',
    options: [
      { label: 'A', text: 'Ejecutivo, Legislativo, Judicial' },
      { label: 'B', text: 'Ejecutivo, Administrativo' },
      { label: 'C', text: 'Legislativo, Judicial' },
      { label: 'D', text: 'Ejecutivo, Militar' }
    ],
    correctAnswer: 'A',
    explanation: 'Los tres poderes del Estado son: Ejecutivo (Presidente), Legislativo (Congreso) y Judicial (Cortes).'
  },
  {
    id: 'soc_005',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuál es el período presidencial en Colombia?',
    options: [
      { label: 'A', text: '2 años' },
      { label: 'B', text: '4 años' },
      { label: 'C', text: '6 años' },
      { label: 'D', text: '8 años' }
    ],
    correctAnswer: 'B',
    explanation: 'El período presidencial en Colombia es de 4 años, sin posibilidad de reelección inmediata.'
  },
  {
    id: 'soc_006',
    area: 'sociales',
    difficulty: 3,
    question: '¿Cuál fue el evento que marcó el inicio de la independencia de Colombia?',
    options: [
      { label: 'A', text: 'El Grito de Independencia de 1810' },
      { label: 'B', text: 'La Batalla de Boyacá' },
      { label: 'C', text: 'La Batalla de Palonegro' },
      { label: 'D', text: 'La Revolución de 1948' }
    ],
    correctAnswer: 'A',
    explanation: 'El Grito de Independencia ocurrió el 20 de julio de 1810 en Bogotá, marcando el inicio de la independencia.'
  },
  {
    id: 'soc_007',
    area: 'sociales',
    difficulty: 3,
    question: '¿Cuál fue la Batalla de Boyacá?',
    options: [
      { label: 'A', text: 'Una batalla durante la independencia' },
      { label: 'B', text: 'Una batalla durante la guerra civil' },
      { label: 'C', text: 'Una batalla contra los españoles en 1819' },
      { label: 'D', text: 'Una batalla durante la Conquista' }
    ],
    correctAnswer: 'C',
    explanation: 'La Batalla de Boyacá (7 de agosto de 1819) fue decisiva en la independencia de Colombia, ganada por Simón Bolívar.'
  },
  {
    id: 'soc_008',
    area: 'sociales',
    difficulty: 3,
    question: '¿Quién fue Simón Bolívar?',
    options: [
      { label: 'A', text: 'Un general español' },
      { label: 'B', text: 'Un líder de la independencia de América del Sur' },
      { label: 'C', text: 'Un presidente de Colombia' },
      { label: 'D', text: 'Un escritor colombiano' }
    ],
    correctAnswer: 'B',
    explanation: 'Simón Bolívar fue un líder militar y político que lideró la independencia de varios países de América del Sur.'
  },
  {
    id: 'soc_009',
    area: 'sociales',
    difficulty: 4,
    question: '¿Cuál fue la Gran Colombia?',
    options: [
      { label: 'A', text: 'Una república que incluía Colombia, Venezuela y Ecuador' },
      { label: 'B', text: 'Una república que incluía Colombia, Perú y Bolivia' },
      { label: 'C', text: 'Una república que incluía toda América del Sur' },
      { label: 'D', text: 'Una república que incluía Colombia y Panamá' }
    ],
    correctAnswer: 'A',
    explanation: 'La Gran Colombia (1819-1831) fue una república que incluía los territorios de la actual Colombia, Venezuela y Ecuador.'
  },
  {
    id: 'soc_010',
    area: 'sociales',
    difficulty: 4,
    question: '¿Cuál fue el Frente Nacional en Colombia?',
    options: [
      { label: 'A', text: 'Un acuerdo de paz' },
      { label: 'B', text: 'Un pacto político entre Conservadores y Liberales' },
      { label: 'C', text: 'Una guerra civil' },
      { label: 'D', text: 'Una revolución' }
    ],
    correctAnswer: 'B',
    explanation: 'El Frente Nacional (1958-1974) fue un pacto político entre los partidos Conservador y Liberal para gobernar alternadamente.'
  },
  {
    id: 'soc_011',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuál es el río más largo de Colombia?',
    options: [
      { label: 'A', text: 'Río Cauca' },
      { label: 'B', text: 'Río Magdalena' },
      { label: 'C', text: 'Río Guaviare' },
      { label: 'D', text: 'Río Meta' }
    ],
    correctAnswer: 'B',
    explanation: 'El Río Magdalena es el río más largo de Colombia, con aproximadamente 1.550 km.'
  },
  {
    id: 'soc_012',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuál es la cordillera más importante de Colombia?',
    options: [
      { label: 'A', text: 'Cordillera Occidental' },
      { label: 'B', text: 'Cordillera Central' },
      { label: 'C', text: 'Cordillera Oriental' },
      { label: 'D', text: 'Todas tienen igual importancia' }
    ],
    correctAnswer: 'D',
    explanation: 'Las tres cordilleras (Occidental, Central y Oriental) tienen igual importancia en la geografía de Colombia.'
  },
  {
    id: 'soc_013',
    area: 'sociales',
    difficulty: 3,
    question: '¿Cuál es el bioma más grande de Colombia?',
    options: [
      { label: 'A', text: 'Selva amazónica' },
      { label: 'B', text: 'Páramo' },
      { label: 'C', text: 'Sabana' },
      { label: 'D', text: 'Desierto' }
    ],
    correctAnswer: 'A',
    explanation: 'La Selva Amazónica es el bioma más grande de Colombia, cubriendo aproximadamente el 35% del territorio nacional.'
  },
  {
    id: 'soc_014',
    area: 'sociales',
    difficulty: 3,
    question: '¿Cuál es la población aproximada de Colombia?',
    options: [
      { label: 'A', text: '30 millones' },
      { label: 'B', text: '50 millones' },
      { label: 'C', text: '100 millones' },
      { label: 'D', text: '150 millones' }
    ],
    correctAnswer: 'B',
    explanation: 'La población de Colombia es aproximadamente 50 millones de habitantes.'
  },
  {
    id: 'soc_015',
    area: 'sociales',
    difficulty: 4,
    question: '¿Cuál es la economía principal de Colombia?',
    options: [
      { label: 'A', text: 'Agricultura' },
      { label: 'B', text: 'Minería' },
      { label: 'C', text: 'Petróleo' },
      { label: 'D', text: 'Servicios' }
    ],
    correctAnswer: 'D',
    explanation: 'El sector de servicios es la economía principal de Colombia, seguido por la agricultura, minería y petróleo.'
  },
  {
    id: 'soc_016',
    area: 'sociales',
    difficulty: 2,
    question: '¿Cuál es el idioma oficial de Colombia?',
    options: [
      { label: 'A', text: 'Inglés' },
      { label: 'B', text: 'Español' },
      { label: 'C', text: 'Portugués' },
      { label: 'D', text: 'Francés' }
    ],
    correctAnswer: 'B',
    explanation: 'El idioma oficial de Colombia es el español.'
  },
  {
    id: 'soc_017',
    area: 'sociales',
    difficulty: 3,
    question: '¿Cuál es la moneda de Colombia?',
    options: [
      { label: 'A', text: 'Dólar' },
      { label: 'B', text: 'Euro' },
      { label: 'C', text: 'Peso colombiano' },
      { label: 'D', text: 'Bolívar' }
    ],
    correctAnswer: 'C',
    explanation: 'La moneda de Colombia es el Peso Colombiano (COP).'
  },
  {
    id: 'soc_018',
    area: 'sociales',
    difficulty: 4,
    question: '¿Cuál fue el evento del "Bogotazo"?',
    options: [
      { label: 'A', text: 'Un terremoto en Bogotá' },
      { label: 'B', text: 'Un levantamiento popular en 1948' },
      { label: 'C', text: 'Una batalla durante la independencia' },
      { label: 'D', text: 'Un acuerdo de paz' }
    ],
    correctAnswer: 'B',
    explanation: 'El "Bogotazo" fue un levantamiento popular que ocurrió el 9 de abril de 1948 en Bogotá, tras el asesinato de Jorge Eliécer Gaitán.'
  },
  {
    id: 'soc_019',
    area: 'sociales',
    difficulty: 4,
    question: '¿Cuál fue la Violencia en Colombia?',
    options: [
      { label: 'A', text: 'Un período de guerra civil (1948-1958)' },
      { label: 'B', text: 'Un conflicto armado reciente' },
      { label: 'C', text: 'Una revolución' },
      { label: 'D', text: 'Una invasión extranjera' }
    ],
    correctAnswer: 'A',
    explanation: 'La Violencia fue un período de guerra civil en Colombia entre 1948 y 1958, caracterizado por enfrentamientos entre Conservadores y Liberales.'
  },
  {
    id: 'soc_020',
    area: 'sociales',
    difficulty: 4,
    question: '¿Cuál es el derecho fundamental más importante según la Constitución de 1991?',
    options: [
      { label: 'A', text: 'Derecho a la propiedad' },
      { label: 'B', text: 'Derecho a la vida' },
      { label: 'C', text: 'Derecho al trabajo' },
      { label: 'D', text: 'Derecho a la educación' }
    ],
    correctAnswer: 'B',
    explanation: 'La Constitución de 1991 reconoce el derecho a la vida como el derecho fundamental más importante.'
  },

  // INGLÉS (11 preguntas)
  {
    id: 'ing_001',
    area: 'ingles',
    difficulty: 1,
    question: 'What is the English word for "gato"?',
    options: [
      { label: 'A', text: 'Dog' },
      { label: 'B', text: 'Cat' },
      { label: 'C', text: 'Bird' },
      { label: 'D', text: 'Fish' }
    ],
    correctAnswer: 'B',
    explanation: 'Cat es la palabra en inglés para "gato".'
  },
  {
    id: 'ing_002',
    area: 'ingles',
    difficulty: 1,
    question: 'What is the English word for "casa"?',
    options: [
      { label: 'A', text: 'Car' },
      { label: 'B', text: 'House' },
      { label: 'C', text: 'Tree' },
      { label: 'D', text: 'Water' }
    ],
    correctAnswer: 'B',
    explanation: 'House es la palabra en inglés para "casa".'
  },
  {
    id: 'ing_003',
    area: 'ingles',
    difficulty: 2,
    question: 'What is the present tense of "to be"?',
    options: [
      { label: 'A', text: 'am, is, are' },
      { label: 'B', text: 'was, were' },
      { label: 'C', text: 'be, been' },
      { label: 'D', text: 'being' }
    ],
    correctAnswer: 'A',
    explanation: 'El presente del verbo "to be" es: am (I), is (he/she/it), are (you/we/they).'
  },
  {
    id: 'ing_004',
    area: 'ingles',
    difficulty: 2,
    question: 'What is the past tense of "to go"?',
    options: [
      { label: 'A', text: 'goes' },
      { label: 'B', text: 'going' },
      { label: 'C', text: 'went' },
      { label: 'D', text: 'gone' }
    ],
    correctAnswer: 'C',
    explanation: 'El pasado del verbo "to go" es "went".'
  },
  {
    id: 'ing_005',
    area: 'ingles',
    difficulty: 2,
    question: 'Complete: "I __ to school every day."',
    options: [
      { label: 'A', text: 'go' },
      { label: 'B', text: 'goes' },
      { label: 'C', text: 'going' },
      { label: 'D', text: 'went' }
    ],
    correctAnswer: 'A',
    explanation: 'La forma correcta es "I go to school every day" (presente simple).'
  },
  {
    id: 'ing_006',
    area: 'ingles',
    difficulty: 3,
    question: 'What is a cognate?',
    options: [
      { label: 'A', text: 'Una palabra que significa lo opuesto' },
      { label: 'B', text: 'Una palabra que se parece en dos idiomas y tiene significado similar' },
      { label: 'C', text: 'Una palabra que es muy difícil' },
      { label: 'D', text: 'Una palabra que no existe' }
    ],
    correctAnswer: 'B',
    explanation: 'Un cognado es una palabra que se parece en dos idiomas y tiene un significado similar. Ejemplo: "hospital" en español y "hospital" en inglés.'
  },
  {
    id: 'ing_007',
    area: 'ingles',
    difficulty: 3,
    question: 'Which is a cognate of "familia"?',
    options: [
      { label: 'A', text: 'Family' },
      { label: 'B', text: 'Friend' },
      { label: 'C', text: 'Food' },
      { label: 'D', text: 'Famous' }
    ],
    correctAnswer: 'A',
    explanation: '"Family" es un cognado de "familia" porque se parece y tiene el mismo significado.'
  },
  {
    id: 'ing_008',
    area: 'ingles',
    difficulty: 3,
    question: 'Complete: "She __ been to Colombia."',
    options: [
      { label: 'A', text: 'have' },
      { label: 'B', text: 'has' },
      { label: 'C', text: 'had' },
      { label: 'D', text: 'having' }
    ],
    correctAnswer: 'B',
    explanation: 'La forma correcta es "She has been to Colombia" (present perfect con "has" para tercera persona singular).'
  },
  {
    id: 'ing_009',
    area: 'ingles',
    difficulty: 4,
    question: 'What tense is "I am studying"?',
    options: [
      { label: 'A', text: 'Simple present' },
      { label: 'B', text: 'Present continuous' },
      { label: 'C', text: 'Simple past' },
      { label: 'D', text: 'Future' }
    ],
    correctAnswer: 'B',
    explanation: '"I am studying" es present continuous (presente continuo), que se forma con "to be" + verbo en -ing.'
  },
  {
    id: 'ing_010',
    area: 'ingles',
    difficulty: 4,
    question: 'Complete: "If I __ rich, I would travel."',
    options: [
      { label: 'A', text: 'am' },
      { label: 'B', text: 'was' },
      { label: 'C', text: 'were' },
      { label: 'D', text: 'would be' }
    ],
    correctAnswer: 'C',
    explanation: 'La forma correcta es "If I were rich" (conditional con "were" en segunda condicional).'
  },
  {
    id: 'ing_011',
    area: 'ingles',
    difficulty: 4,
    question: 'What is the passive voice of "I eat an apple"?',
    options: [
      { label: 'A', text: 'An apple is eaten by me' },
      { label: 'B', text: 'An apple eats me' },
      { label: 'C', text: 'I am eaten by an apple' },
      { label: 'D', text: 'An apple was eaten' }
    ],
    correctAnswer: 'A',
    explanation: 'La voz pasiva de "I eat an apple" es "An apple is eaten by me".'
  }
];
