import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useProgress } from '@/contexts/ProgressContext';
import { 
  Home, BookOpen, FlaskConical, Globe, Map, 
  Calculator, Trophy, BarChart3, Menu, X, Star, Library, Lightbulb, Zap, TrendingUp
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Inicio', icon: Home },
  { path: '/matematicas', label: 'Matemáticas', icon: Calculator },
  { path: '/lectura', label: 'Lectura Crítica', icon: BookOpen },
  { path: '/ciencias', label: 'Ciencias', icon: FlaskConical },
  { path: '/sociales', label: 'Sociales', icon: Map },
  { path: '/ingles', label: 'Inglés', icon: Globe },
  { path: '/simulacro', label: 'Simulacro', icon: BarChart3 },
  { path: '/logros', label: 'Logros', icon: Trophy },
  { path: '/glosario', label: 'Glosario', icon: Library },
  { path: '/tips', label: 'Estrategias', icon: Lightbulb },
  { path: '/leaderboard', label: 'Ranking', icon: Zap },
  { path: '/analytics', label: 'Análisis', icon: TrendingUp },
];

const bottomNavItems = [
  { path: '/', label: 'Inicio', icon: Home },
  { path: '/matematicas', label: 'Mates', icon: Calculator },
  { path: '/lectura', label: 'Lectura', icon: BookOpen },
  { path: '/simulacro', label: 'Simular', icon: BarChart3 },
  { path: '/logros', label: 'Logros', icon: Trophy },
];

function ScoreMeter({ score }: { score: number }) {
  const percentage = ((score - 200) / 300) * 100;
  const getColor = () => {
    if (score >= 360) return 'text-green-400';
    if (score >= 300) return 'text-yellow-400';
    if (score >= 250) return 'text-orange-400';
    return 'text-red-400';
  };
  const getLabel = () => {
    if (score >= 360) return '¡Excelente!';
    if (score >= 300) return 'Muy bien';
    if (score >= 250) return 'Progresando';
    return 'Empezando';
  };

  return (
    <div className="mx-4 mb-4 p-3 rounded-xl bg-sidebar-accent/50 border border-sidebar-border">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-sidebar-foreground/60 font-medium">Puntaje estimado</span>
        <span className={`text-xs font-bold ${getColor()}`}>{getLabel()}</span>
      </div>
      <div className="flex items-center gap-2">
        <div className="flex-1 h-2 bg-sidebar-border rounded-full overflow-hidden">
          <div 
            className="h-full rounded-full bg-gradient-to-r from-orange-400 via-yellow-400 to-green-400 transition-all duration-700"
            style={{ width: `${Math.min(100, Math.max(2, percentage))}%` }}
          />
        </div>
        <span className={`text-lg font-bold ${getColor()} font-['Lexend']`}>{score}</span>
      </div>
      <div className="flex justify-between text-xs text-sidebar-foreground/40 mt-1">
        <span>200</span>
        <span>360</span>
        <span>500</span>
      </div>
    </div>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { progress } = useProgress();

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-64 min-h-screen bg-sidebar fixed left-0 top-0 z-40">
        {/* Logo */}
        <div className="p-5 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sidebar-primary flex items-center justify-center text-xl">
              🎓
            </div>
            <div>
              <h1 className="text-sidebar-foreground font-bold text-lg font-['Lexend'] leading-tight">ProICFES</h1>
              <p className="text-sidebar-foreground/50 text-xs">Prepárate y Triunfa</p>
            </div>
          </div>
        </div>

        {/* XP Badge */}
        <div className="px-4 py-3 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span className="text-sidebar-foreground/70 text-sm">{progress.totalXp} XP ganados</span>
            {progress.streak > 0 && (
              <span className="ml-auto text-xs bg-orange-500/20 text-orange-300 px-2 py-0.5 rounded-full">
                🔥 {progress.streak} días
              </span>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map(({ path, label, icon: Icon }) => (
            <Link key={path} href={path}>
              <div className={`nav-item ${location === path ? 'active' : ''}`}>
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm">{label}</span>
              </div>
            </Link>
          ))}
        </nav>

        {/* Score Meter */}
        <ScoreMeter score={progress.estimatedScore} />
      </aside>

      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-sidebar border-b border-sidebar-border">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">🎓</span>
            <span className="text-sidebar-foreground font-bold text-lg font-['Lexend']">ProICFES</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 bg-sidebar-accent/50 px-3 py-1.5 rounded-full">
              <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
              <span className="text-sidebar-foreground text-sm font-semibold">{progress.estimatedScore}</span>
            </div>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-sidebar-foreground p-1"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black/60" onClick={() => setMobileMenuOpen(false)}>
          <div className="absolute top-16 left-0 right-0 bg-sidebar border-b border-sidebar-border p-4" onClick={e => e.stopPropagation()}>
            <nav className="space-y-1">
              {navItems.map(({ path, label, icon: Icon }) => (
                <Link key={path} href={path}>
                  <div 
                    className={`nav-item ${location === path ? 'active' : ''}`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{label}</span>
                  </div>
                </Link>
              ))}
            </nav>
            <div className="mt-4">
              <ScoreMeter score={progress.estimatedScore} />
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 min-h-screen pb-20 lg:pb-0 pt-16 lg:pt-0">
        <div className="max-w-5xl mx-auto px-4 py-6">
          {children}
        </div>
      </main>

      {/* Bottom Navigation - Mobile */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-sidebar border-t border-sidebar-border">
        <div className="flex">
          {bottomNavItems.map(({ path, label, icon: Icon }) => (
            <Link key={path} href={path}>
              <div className={`flex-1 flex flex-col items-center gap-1 py-2.5 transition-colors ${
                location === path 
                  ? 'text-sidebar-primary' 
                  : 'text-sidebar-foreground/50'
              }`}>
                <Icon className="w-5 h-5" />
                <span className="text-xs font-medium">{label}</span>
              </div>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
