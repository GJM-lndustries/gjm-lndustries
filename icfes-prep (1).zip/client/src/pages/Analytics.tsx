import { useProgress } from '@/contexts/ProgressContext';
import { modules } from '@/lib/appData';
import { motion } from 'framer-motion';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, AlertCircle, Zap, Target } from 'lucide-react';

export default function Analytics() {
  const { progress, getModuleProgress } = useProgress();

  // Datos de progreso por módulo
  const moduleProgress = modules.map(module => ({
    name: module.title,
    progress: getModuleProgress(module.id, module.lessons.map(l => l.id)),
    lessons: module.lessons.length
  }));

  // Datos de simulacros
  const simulacroData = progress.simulacroScores.map((score, idx) => ({
    simulacro: `Simulacro ${idx + 1}`,
    puntaje: Math.round(score),
    meta: progress.targetScore
  }));

  // Tendencia de puntaje
  const scoreData = [
    { fase: 'Inicio', puntaje: progress.currentScore },
    { fase: 'Actual', puntaje: progress.estimatedScore },
    { fase: 'Meta', puntaje: progress.targetScore }
  ];

  // Distribución de XP por área
  const completedByArea = modules.map(module => ({
    name: module.title,
    lecciones: module.lessons.filter(l => 
      progress.completedLessons.some(cl => cl.lessonId === l.id && cl.completed)
    ).length,
    total: module.lessons.length
  }));

  // Recomendaciones personalizadas
  const getRecommendations = () => {
    const recommendations = [];
    
    // Verificar áreas débiles
    moduleProgress.forEach(mod => {
      if (mod.progress < 50) {
        recommendations.push({
          type: 'warning',
          text: `${mod.name}: Solo has completado el ${mod.progress}% de las lecciones. Enfócate en esta área.`,
          icon: AlertCircle
        });
      }
    });

    // Motivación
    if (progress.estimatedScore >= progress.targetScore) {
      recommendations.push({
        type: 'success',
        text: '¡Felicidades! Ya alcanzaste tu meta. Continúa practicando para mantener tu nivel.',
        icon: Zap
      });
    } else {
      const difference = progress.targetScore - progress.estimatedScore;
      recommendations.push({
        type: 'info',
        text: `Te faltan ${difference} puntos para alcanzar tu meta de ${progress.targetScore}. ¡Tú puedes!`,
        icon: Target
      });
    }

    // Racha
    if (progress.streak === 0) {
      recommendations.push({
        type: 'warning',
        text: 'No tienes racha activa. Estudia hoy para comenzar una nueva racha.',
        icon: Zap
      });
    } else if (progress.streak >= 7) {
      recommendations.push({
        type: 'success',
        text: `¡Excelente! Llevas ${progress.streak} días de racha. Sigue así.`,
        icon: TrendingUp
      });
    }

    return recommendations;
  };

  const recommendations = getRecommendations();

  const COLORS = ['#4ade80', '#fbbf24', '#f97316', '#ef4444', '#8b5cf6'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold font-['Lexend'] text-foreground">Análisis de Desempeño</h1>
        <p className="text-muted-foreground mt-1">Visualiza tu progreso y recibe recomendaciones personalizadas</p>
      </div>

      {/* Recomendaciones */}
      <div className="space-y-3">
        <h2 className="font-bold font-['Lexend'] text-foreground">Recomendaciones personalizadas</h2>
        {recommendations.map((rec, idx) => {
          const Icon = rec.icon;
          const bgColor = rec.type === 'success' ? 'bg-green-50 border-green-200' : 
                         rec.type === 'warning' ? 'bg-yellow-50 border-yellow-200' : 
                         'bg-blue-50 border-blue-200';
          const textColor = rec.type === 'success' ? 'text-green-700' : 
                           rec.type === 'warning' ? 'text-yellow-700' : 
                           'text-blue-700';
          
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={`rounded-xl p-4 border-2 flex items-start gap-3 ${bgColor}`}
            >
              <Icon className={`w-5 h-5 flex-shrink-0 mt-0.5 ${textColor}`} />
              <p className={`text-sm font-medium ${textColor}`}>{rec.text}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Gráfica de progreso por módulo */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-card rounded-2xl border border-border p-6"
      >
        <h2 className="font-bold font-['Lexend'] text-foreground mb-4">Progreso por módulo</h2>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={moduleProgress}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip 
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
              formatter={(value) => `${value}%`}
            />
            <Bar dataKey="progress" fill="#4ade80" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Gráfica de tendencia de puntaje */}
      {simulacroData.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card rounded-2xl border border-border p-6"
        >
          <h2 className="font-bold font-['Lexend'] text-foreground mb-4">Tendencia de puntaje en simulacros</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={simulacroData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="simulacro" stroke="#6b7280" />
              <YAxis stroke="#6b7280" domain={[0, 500]} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
              />
              <Legend />
              <Line type="monotone" dataKey="puntaje" stroke="#4ade80" strokeWidth={2} dot={{ fill: '#4ade80' }} />
              <Line type="monotone" dataKey="meta" stroke="#fbbf24" strokeWidth={2} strokeDasharray="5 5" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      )}

      {/* Gráfica de distribución de lecciones completadas */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-card rounded-2xl border border-border p-6"
      >
        <h2 className="font-bold font-['Lexend'] text-foreground mb-4">Lecciones completadas por área</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={completedByArea}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, lecciones, total }) => `${name}: ${lecciones}/${total}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="lecciones"
              >
                {completedByArea.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          
          <div className="space-y-3">
            {completedByArea.map((area, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{area.name}</span>
                  <span className="text-sm font-bold text-foreground">{area.lecciones}/{area.total}</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="h-2 rounded-full transition-all"
                    style={{
                      width: `${(area.lecciones / area.total) * 100}%`,
                      backgroundColor: COLORS[idx % COLORS.length]
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Estadísticas generales */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-card rounded-xl border border-border p-4 text-center"
        >
          <p className="text-2xl font-bold font-['Lexend'] text-primary">{progress.totalXp}</p>
          <p className="text-xs text-muted-foreground mt-1">XP totales</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.05 }}
          className="bg-card rounded-xl border border-border p-4 text-center"
        >
          <p className="text-2xl font-bold font-['Lexend'] text-primary">{progress.completedLessons.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Lecciones</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-card rounded-xl border border-border p-4 text-center"
        >
          <p className="text-2xl font-bold font-['Lexend'] text-primary">{progress.streak}</p>
          <p className="text-xs text-muted-foreground mt-1">Días racha</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.15 }}
          className="bg-card rounded-xl border border-border p-4 text-center"
        >
          <p className="text-2xl font-bold font-['Lexend'] text-primary">{progress.badges.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Insignias</p>
        </motion.div>
      </div>

      {/* Información sobre la meta */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-2xl border border-primary/20 p-6"
      >
        <h3 className="font-bold font-['Lexend'] text-foreground mb-3">Tu meta personalizada</h3>
        <div className="space-y-2 text-sm">
          <p className="text-foreground">
            <span className="font-semibold">Carrera:</span> {progress.career || 'No especificada'}
          </p>
          <p className="text-foreground">
            <span className="font-semibold">Puntaje mínimo requerido:</span> {progress.minimumScore}/500
          </p>
          <p className="text-foreground">
            <span className="font-semibold">Tu objetivo:</span> {progress.targetScore}/500
          </p>
          <p className="text-foreground">
            <span className="font-semibold">Progreso actual:</span> {progress.estimatedScore}/500 ({Math.round((progress.estimatedScore / 500) * 100)}%)
          </p>
          <div className="mt-4 w-full bg-white/20 rounded-full h-3 overflow-hidden">
            <div
              className="h-3 bg-gradient-to-r from-primary to-primary/80 rounded-full transition-all"
              style={{ width: `${Math.min(100, (progress.estimatedScore / 500) * 100)}%` }}
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
}
