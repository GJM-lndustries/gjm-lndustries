import { useProgress } from '@/contexts/ProgressContext';
import { motion } from 'framer-motion';
import { Trophy, Zap, Target } from 'lucide-react';

interface LeaderboardEntry {
  id: string;
  name: string;
  score: number;
  xp: number;
  streak: number;
  rank: number;
}

// Simulamos datos de leaderboard - en una app real vendrían de un servidor
const generateMockLeaderboard = (): LeaderboardEntry[] => {
  const names = [
    'Juan Pérez', 'María García', 'Carlos López', 'Ana Martínez', 'Pedro Rodríguez',
    'Laura Sánchez', 'Diego Fernández', 'Sofia González', 'Miguel Ramírez', 'Elena Torres'
  ];
  
  return names.map((name, idx) => ({
    id: `user_${idx}`,
    name,
    score: Math.max(200, 500 - Math.random() * 200),
    xp: Math.floor(Math.random() * 5000) + 1000,
    streak: Math.floor(Math.random() * 30) + 1,
    rank: idx + 1
  })).sort((a, b) => b.score - a.score);
};

function MedalIcon({ rank }: { rank: number }) {
  if (rank === 1) return <span className="text-4xl">🥇</span>;
  if (rank === 2) return <span className="text-4xl">🥈</span>;
  if (rank === 3) return <span className="text-4xl">🥉</span>;
  return <span className="text-2xl font-bold text-muted-foreground">#{rank}</span>;
}

function BlackHoleInsignia() {
  return (
    <div className="relative w-12 h-12 flex items-center justify-center">
      {/* Outer glow */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-600 to-black opacity-50 blur-md" />
      
      {/* Black hole center */}
      <div className="relative w-10 h-10 rounded-full bg-gradient-to-br from-gray-800 via-black to-black shadow-2xl flex items-center justify-center border border-purple-500/30">
        {/* Inner glow */}
        <div className="absolute inset-1 rounded-full bg-gradient-to-br from-purple-900/50 to-transparent" />
        
        {/* Center point */}
        <div className="w-2 h-2 rounded-full bg-purple-400 blur-sm" />
        
        {/* Accretion disk effect */}
        <div className="absolute inset-2 rounded-full border border-purple-400/20 animate-spin" style={{ animationDuration: '3s' }} />
      </div>
      
      {/* Tooltip */}
      <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        Top 3 - Agujero Negro
      </div>
    </div>
  );
}

export default function Leaderboard() {
  const { progress } = useProgress();
  const leaderboard = generateMockLeaderboard();
  
  // Encontrar la posición del usuario actual (simulado)
  const userRank = Math.floor(Math.random() * 50) + 1;
  const userEntry: LeaderboardEntry = {
    id: 'current_user',
    name: 'Tú',
    score: progress.estimatedScore,
    xp: progress.totalXp,
    streak: progress.streak,
    rank: userRank
  };

  const topThree = leaderboard.slice(0, 3);
  const restOfLeaderboard = leaderboard.slice(3);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold font-['Lexend'] text-foreground">Leaderboard</h1>
        <p className="text-muted-foreground mt-1">Los mejores estudiantes de ProICFES</p>
      </div>

      {/* Top 3 with Black Hole Insignias */}
      <div className="space-y-3">
        <h2 className="font-bold font-['Lexend'] text-foreground text-lg">🌌 Top 3 - Agujero Negro</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {topThree.map((entry, idx) => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={`rounded-2xl p-6 border-2 relative overflow-hidden ${
                idx === 0 
                  ? 'bg-gradient-to-br from-yellow-50 to-amber-50 border-yellow-300 shadow-lg' 
                  : idx === 1 
                  ? 'bg-gradient-to-br from-gray-100 to-slate-100 border-gray-300'
                  : 'bg-gradient-to-br from-orange-50 to-amber-50 border-orange-300'
              }`}
            >
              {/* Black hole insignia */}
              <div className="absolute top-3 right-3 group">
                <BlackHoleInsignia />
              </div>

              <div className="flex items-center gap-4 mb-4">
                <div className="text-5xl">
                  <MedalIcon rank={entry.rank} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold font-['Lexend'] text-lg text-foreground">{entry.name}</h3>
                  <p className="text-sm text-muted-foreground">Puesto #{entry.rank}</p>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Target className="w-4 h-4" /> Puntaje
                  </span>
                  <span className="font-bold text-foreground">{Math.round(entry.score)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Zap className="w-4 h-4" /> XP
                  </span>
                  <span className="font-bold text-foreground">{entry.xp.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">🔥 Racha</span>
                  <span className="font-bold text-foreground">{entry.streak} días</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Current user position */}
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wide font-semibold">Tu posición</p>
            <p className="text-lg font-bold font-['Lexend'] text-foreground mt-1">#{userRank} en el ranking</p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-primary font-['Lexend']">{Math.round(userEntry.score)}</p>
            <p className="text-xs text-muted-foreground">puntos estimados</p>
          </div>
        </div>
      </div>

      {/* Rest of leaderboard */}
      <div>
        <h2 className="font-bold font-['Lexend'] text-foreground mb-3">Ranking completo</h2>
        <div className="space-y-2">
          {restOfLeaderboard.map((entry, idx) => (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: (idx + 3) * 0.05 }}
              className="flex items-center gap-4 bg-card rounded-xl p-4 border border-border hover:shadow-md transition-shadow"
            >
              <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-muted-foreground">#{entry.rank}</span>
              </div>
              
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-foreground truncate">{entry.name}</p>
                <p className="text-xs text-muted-foreground">{entry.xp.toLocaleString()} XP • {entry.streak}d racha</p>
              </div>
              
              <div className="text-right flex-shrink-0">
                <p className="font-bold text-foreground">{Math.round(entry.score)}</p>
                <p className="text-xs text-muted-foreground">puntos</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Info */}
      <div className="bg-muted/50 rounded-xl p-4 text-center">
        <p className="text-sm text-muted-foreground">
          💡 El leaderboard se actualiza cada 24 horas. Los top 3 reciben la insignia de <span className="font-semibold">Agujero Negro</span>.
        </p>
      </div>
    </div>
  );
}
