import { Link } from 'wouter';
import { useProgress } from '@/contexts/ProgressContext';
import { modules } from '@/lib/appData';
import { ChevronRight, Star, Zap, Target, BookOpen, Trophy, Flame } from 'lucide-react';
import { motion } from 'framer-motion';

function ScoreGauge({ score, targetScore }: { score: number; targetScore: number }) {
  const percentage = ((score - 100) / 400) * 100;
  const targetPercentage = ((targetScore - 100) / 400) * 100;
  const getColor = () => {
    if (score >= targetScore) return '#4ade80';
    if (score >= targetScore - 50) return '#fbbf24';
    if (score >= targetScore - 100) return '#f97316';
    return '#ef4444';
  };
  const getLabel = () => {
    if (score >= targetScore) return '¡Meta alcanzada!';
    if (score >= targetScore - 50) return 'Casi ahí';
    if (score >= targetScore - 100) return 'Buen progreso';
    return 'Empezando';
  };

  return (
    <div className="bg-gradient-to-br from-[#1e3a5f] to-[#0f2040] rounded-2xl p-6 text-white">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-white/60 text-sm font-medium">Tu puntaje estimado ICFES</p>
          <div className="flex items-end gap-2 mt-1">
            <span className="text-5xl font-bold font-['Lexend']" style={{ color: getColor() }}>{score}</span>
            <span className="text-white/40 text-lg mb-1">/500</span>
          </div>
          <span className="text-sm font-semibold mt-1 block" style={{ color: getColor() }}>{getLabel()}</span>
        </div>
        <div className="text-right">
          <div className="text-white/60 text-xs mb-1">Meta: 360+</div>
          <div className="text-2xl">🎯</div>
        </div>
      </div>
      
      {/* Progress bar */}
      <div className="relative h-4 bg-white/10 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(100, Math.max(2, percentage))}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="h-full rounded-full"
          style={{ background: `linear-gradient(to right, #ef4444, #f97316, #fbbf24, ${getColor()})` }}
        />
        {/* Target marker */}
        <div 
          className="absolute top-0 bottom-0 w-0.5 bg-white/60"
          style={{ left: `${Math.min(100, Math.max(0, targetPercentage))}%` }}
        />
      </div>
      <div className="flex justify-between text-xs text-white/40 mt-1">
        <span>100 pts</span>
        <span className="text-white/60">↑ Meta {targetScore}</span>
        <span>500 pts</span>
      </div>
    </div>
  );
}

function ModuleCard({ module }: { module: typeof modules[0] }) {
  const { getModuleProgress } = useProgress();
  const lessonIds = module.lessons.map(l => l.id);
  const progressPct = getModuleProgress(module.id, lessonIds);
  
  return (
    <Link href={`/${module.id}`}>
      <motion.a
        whileHover={{ y: -3 }}
        whileTap={{ scale: 0.98 }}
        className="block bg-card rounded-2xl border border-border overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
      >
        <div className="relative h-32 overflow-hidden">
          <img 
            src={module.image} 
            alt={module.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-3 left-3 right-3">
            <div className="flex items-center justify-between">
              <span className="text-2xl">{module.icon}</span>
              {progressPct > 0 && (
                <span className="text-xs bg-green-500 text-white px-2 py-0.5 rounded-full font-semibold">
                  {progressPct}% completado
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="p-4">
          <h3 className="font-bold text-foreground font-['Lexend'] text-base">{module.title}</h3>
          <p className="text-muted-foreground text-sm mt-0.5">{module.subtitle}</p>
          <div className="flex items-center justify-between mt-3">
            <span className="text-xs text-muted-foreground">{module.lessons.length} lecciones</span>
            <div className="flex items-center gap-1 text-xs text-primary font-semibold">
              <span>Empezar</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
          {progressPct > 0 && (
            <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-500 rounded-full transition-all"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          )}
        </div>
      </motion.a>
    </Link>
  );
}

export default function Home() {
  const { progress } = useProgress();
  const totalLessons = modules.reduce((sum, m) => sum + m.lessons.length, 0);
  const completedCount = progress.completedLessons.filter(l => l.completed).length;

  const tips = [
    "💡 El ICFES tiene 106 preguntas en 4 horas 30 minutos. ¡Practica la velocidad!",
    "📖 En Lectura Crítica, lee las preguntas ANTES de leer el texto.",
    "📐 En Matemáticas, reemplaza números sencillos para verificar expresiones algebraicas.",
    "🔬 En Ciencias, el ICFES evalúa razonamiento, no memorización.",
    "🗺️ En Sociales, conecta los eventos históricos con la situación actual de Colombia.",
    "🌎 En Inglés, usa los cognados (palabras parecidas al español) a tu favor."
  ];
  
  const randomTip = tips[Math.floor(Date.now() / 86400000) % tips.length];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-['Lexend'] text-foreground">
          {progress.totalXp === 0 ? '¡Bienvenido a ProICFES!' : '¡Bienvenido de vuelta!'}
        </h1>
        <p className="text-muted-foreground mt-1">
          {progress.totalXp === 0 
            ? 'Empieza desde cero y llega a más de 360 puntos en el ICFES'
            : `Llevas ${completedCount} de ${totalLessons} lecciones completadas. ¡Sigue así!`
          }
        </p>
      </div>

      {/* Score Gauge */}
      <ScoreGauge score={progress.estimatedScore} targetScore={progress.targetScore} />

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-card rounded-xl border border-border p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
            <span className="text-lg font-bold font-['Lexend'] text-foreground">{progress.totalXp}</span>
          </div>
          <p className="text-xs text-muted-foreground">XP ganados</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Flame className="w-4 h-4 text-orange-500" />
            <span className="text-lg font-bold font-['Lexend'] text-foreground">{progress.streak}</span>
          </div>
          <p className="text-xs text-muted-foreground">Días seguidos</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <BookOpen className="w-4 h-4 text-primary" />
            <span className="text-lg font-bold font-['Lexend'] text-foreground">{completedCount}</span>
          </div>
          <p className="text-xs text-muted-foreground">Lecciones</p>
        </div>
      </div>

      {/* Daily Tip */}
      <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
        <p className="text-sm font-semibold text-primary mb-1">Consejo del día</p>
        <p className="text-sm text-foreground">{randomTip}</p>
      </div>

      {/* Hero Image */}
      {progress.totalXp === 0 && (
        <div className="relative rounded-2xl overflow-hidden">
          <img 
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663562250835/kzEb9Pvj5jP4ub7j2gQyi7/hero-icfes-L9RjUdBtpdEPBwkoKLReoU.webp"
            alt="Estudiante colombiano preparándose para el ICFES"
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#1e3a5f]/80 to-transparent flex items-center">
            <div className="p-5">
              <h2 className="text-white font-bold text-xl font-['Lexend'] leading-tight">
                De 0 a 360+<br/>en el ICFES
              </h2>
              <p className="text-white/80 text-sm mt-1">Paso a paso, en tu idioma</p>
              <Link href="/matematicas">
                <a className="mt-3 inline-flex items-center gap-1.5 bg-[#4ade80] text-[#0f2040] px-4 py-2 rounded-xl text-sm font-bold hover:bg-[#22c55e] transition-colors">
                  <Zap className="w-4 h-4" />
                  Empezar ahora
                </a>
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg font-bold font-['Lexend'] text-foreground mb-3">Acciones rápidas</h2>
        <div className="grid grid-cols-2 gap-3">
          <Link href="/simulacro">
            <a className="flex items-center gap-3 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-xl p-4 hover:opacity-90 transition-opacity">
              <Target className="w-8 h-8 flex-shrink-0" />
              <div>
                <p className="font-bold text-sm font-['Lexend']">Simulacro</p>
                <p className="text-xs opacity-80">Practica como en el examen real</p>
              </div>
            </a>
          </Link>
          <Link href="/logros">
            <a className="flex items-center gap-3 bg-gradient-to-br from-yellow-500 to-orange-500 text-white rounded-xl p-4 hover:opacity-90 transition-opacity">
              <Trophy className="w-8 h-8 flex-shrink-0" />
              <div>
                <p className="font-bold text-sm font-['Lexend']">Mis Logros</p>
                <p className="text-xs opacity-80">{progress.badges.length} insignias ganadas</p>
              </div>
            </a>
          </Link>
        </div>
      </div>

      {/* Modules */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold font-['Lexend'] text-foreground">Áreas del ICFES</h2>
          <span className="text-xs text-muted-foreground">{modules.length} áreas</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {modules.map(module => (
            <ModuleCard key={module.id} module={module} />
          ))}
        </div>
      </div>

      {/* Extra Resources */}
      <div>
        <h2 className="text-lg font-bold font-['Lexend'] text-foreground mb-3">Recursos extra</h2>
        <div className="grid grid-cols-2 gap-3">
          <Link href="/glosario">
            <div className="flex items-center gap-3 bg-card border border-border rounded-xl p-4 hover:shadow-md hover:border-primary/30 transition-all cursor-pointer">
              <span className="text-2xl">📖</span>
              <div>
                <p className="font-bold text-sm font-['Lexend'] text-foreground">Glosario</p>
                <p className="text-xs text-muted-foreground">Palabras técnicas explicadas</p>
              </div>
            </div>
          </Link>
          <Link href="/tips">
            <div className="flex items-center gap-3 bg-card border border-border rounded-xl p-4 hover:shadow-md hover:border-primary/30 transition-all cursor-pointer">
              <span className="text-2xl">💡</span>
              <div>
                <p className="font-bold text-sm font-['Lexend'] text-foreground">Estrategias</p>
                <p className="text-xs text-muted-foreground">Trucos para el examen</p>
              </div>
            </div>
          </Link>
        </div>
      </div>

      {/* Info Section */}
      <div className="bg-muted/50 rounded-2xl p-5 space-y-3">
        <h3 className="font-bold font-['Lexend'] text-foreground">¿Cómo funciona el ICFES?</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="bg-card rounded-xl p-3 border border-border">
            <p className="font-semibold text-foreground">📝 106 preguntas</p>
            <p className="text-muted-foreground text-xs mt-0.5">En 4 horas 30 minutos</p>
          </div>
          <div className="bg-card rounded-xl p-3 border border-border">
            <p className="font-semibold text-foreground">📊 Escala 0-500</p>
            <p className="text-muted-foreground text-xs mt-0.5">Meta recomendada: 360+</p>
          </div>
          <div className="bg-card rounded-xl p-3 border border-border">
            <p className="font-semibold text-foreground">✅ 4 opciones</p>
            <p className="text-muted-foreground text-xs mt-0.5">Siempre A, B, C o D</p>
          </div>
          <div className="bg-card rounded-xl p-3 border border-border">
            <p className="font-semibold text-foreground">🎯 Sin penalización</p>
            <p className="text-muted-foreground text-xs mt-0.5">No restan por respuesta incorrecta</p>
          </div>
        </div>
      </div>
    </div>
  );
}
