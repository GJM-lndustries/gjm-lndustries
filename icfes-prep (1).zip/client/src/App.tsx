import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";

import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { ProgressProvider } from "./contexts/ProgressContext";
import { usePWA } from "./hooks/usePWA";
import { Switch, Route } from "wouter";
import AppLayout from "./components/AppLayout";
import Home from "./pages/Home";
import ModulePage from "./pages/ModulePage";
import Simulacro from "./pages/Simulacro";
import Logros from "./pages/Logros";
import Glosario from "./pages/Glosario";
import Tips from "./pages/Tips";
import Leaderboard from "./pages/Leaderboard";
import Onboarding from "./pages/Onboarding";
import Analytics from "./pages/Analytics";
import { modules } from "./lib/appData";
import { useProgress } from "./contexts/ProgressContext";



function AppContent() {
  usePWA();
  const { progress } = useProgress();
  
  if (!progress.hasCompletedOnboarding) {
    return <Route path="*" component={Onboarding} />;
  }

  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/simulacro" component={Simulacro} />
        <Route path="/logros" component={Logros} />
        <Route path="/glosario" component={Glosario} />
        <Route path="/tips" component={Tips} />
        <Route path="/leaderboard" component={Leaderboard} />
        <Route path="/analytics" component={Analytics} />
        {modules.map(module => (
          <Route 
            key={module.id} 
            path={`/${module.id}`} 
            component={() => <ModulePage module={module} />} 
          />
        ))}
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <ProgressProvider>
          <TooltipProvider>
            <Toaster />
            <AppContent />
          </TooltipProvider>
        </ProgressProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
