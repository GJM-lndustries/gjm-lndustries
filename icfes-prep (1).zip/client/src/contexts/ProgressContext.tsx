import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

interface LessonProgress {
  lessonId: string;
  completed: boolean;
  score: number; // 0-100
  xpEarned: number;
  completedAt?: string;
}

interface UserProgress {
  totalXp: number;
  streak: number;
  lastStudyDate: string;
  completedLessons: LessonProgress[];
  simulacroScores: number[];
  estimatedScore: number;
  badges: string[];
  // Onboarding
  hasCompletedOnboarding: boolean;
  currentScore: number; // Puntaje actual del ICFES
  minimumScore: number; // Puntaje mínimo requerido
  targetScore: number; // Puntaje objetivo
  career: string; // Carrera del usuario
  // Favoritos
  favoriteLessons: string[];
  favoriteQuestions: string[];
}

interface ProgressContextType {
  progress: UserProgress;
  completeLesson: (lessonId: string, score: number, xp: number) => void;
  addSimulacroScore: (score: number) => void;
  getLessonProgress: (lessonId: string) => LessonProgress | undefined;
  isLessonCompleted: (lessonId: string) => boolean;
  getModuleProgress: (moduleId: string, lessonIds: string[]) => number;
  resetProgress: () => void;
  completeOnboarding: (currentScore: number, minimumScore: number, targetScore: number, career: string) => void;
  toggleFavoriteLesson: (lessonId: string) => void;
  toggleFavoriteQuestion: (questionId: string) => void;
  isFavoriteLesson: (lessonId: string) => boolean;
  isFavoriteQuestion: (questionId: string) => boolean;
}

const defaultProgress: UserProgress = {
  totalXp: 0,
  streak: 0,
  lastStudyDate: '',
  completedLessons: [],
  simulacroScores: [],
  estimatedScore: 100,
  badges: [],
  hasCompletedOnboarding: false,
  currentScore: 0,
  minimumScore: 0,
  targetScore: 360,
  career: '',
  favoriteLessons: [],
  favoriteQuestions: []
};

const ProgressContext = createContext<ProgressContextType | null>(null);

export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<UserProgress>(() => {
    try {
      const saved = localStorage.getItem('proicfes_progress');
      return saved ? JSON.parse(saved) : defaultProgress;
    } catch {
      return defaultProgress;
    }
  });

  useEffect(() => {
    localStorage.setItem('proicfes_progress', JSON.stringify(progress));
  }, [progress]);

  const calculateEstimatedScore = useCallback((completedCount: number, avgScore: number, simScores: number[]) => {
    // Base score: 200 (sin estudiar nada)
    // Máximo: 500
    // Cada lección completada suma puntos
    // Las simulaciones tienen mayor peso
    let score = 200;
    score += completedCount * 8; // Cada lección suma ~8 puntos
    if (avgScore > 0) score += (avgScore - 50) * 0.5; // Bonus por buen desempeño
    if (simScores.length > 0) {
      const avgSim = simScores.reduce((a, b) => a + b, 0) / simScores.length;
      score += avgSim * 1.2; // Simulacros tienen más peso
    }
    return Math.min(500, Math.max(200, Math.round(score)));
  }, []);

  const completeLesson = useCallback((lessonId: string, score: number, xp: number) => {
    setProgress(prev => {
      const existing = prev.completedLessons.find(l => l.lessonId === lessonId);
      let updatedLessons;
      
      if (existing) {
        updatedLessons = prev.completedLessons.map(l =>
          l.lessonId === lessonId
            ? { ...l, score: Math.max(l.score, score), xpEarned: Math.max(l.xpEarned, xp), completedAt: new Date().toISOString() }
            : l
        );
      } else {
        updatedLessons = [...prev.completedLessons, {
          lessonId,
          completed: true,
          score,
          xpEarned: xp,
          completedAt: new Date().toISOString()
        }];
      }

      const today = new Date().toDateString();
      const lastDate = prev.lastStudyDate;
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      
      let newStreak = prev.streak;
      if (lastDate !== today) {
        newStreak = lastDate === yesterday ? prev.streak + 1 : 1;
      }

      const totalXp = updatedLessons.reduce((sum, l) => sum + l.xpEarned, 0);
      const avgScore = updatedLessons.reduce((sum, l) => sum + l.score, 0) / updatedLessons.length;
      const estimatedScore = calculateEstimatedScore(updatedLessons.length, avgScore, prev.simulacroScores);

      // Check badges
      const badges = [...prev.badges];
      if (updatedLessons.length === 1 && !badges.includes('primer_paso')) badges.push('primer_paso');
      if (updatedLessons.length >= 5 && !badges.includes('cinco_lecciones')) badges.push('cinco_lecciones');
      if (newStreak >= 3 && !badges.includes('racha_3')) badges.push('racha_3');
      if (score === 100 && !badges.includes('perfecto')) badges.push('perfecto');

      return {
        ...prev,
        totalXp,
        streak: newStreak,
        lastStudyDate: today,
        completedLessons: updatedLessons,
        estimatedScore,
        badges
      };
    });
  }, [calculateEstimatedScore]);

  const addSimulacroScore = useCallback((score: number) => {
    setProgress(prev => {
      const newScores = [...prev.simulacroScores, score];
      const avgScore = prev.completedLessons.length > 0
        ? prev.completedLessons.reduce((sum, l) => sum + l.score, 0) / prev.completedLessons.length
        : 50;
      const estimatedScore = calculateEstimatedScore(prev.completedLessons.length, avgScore, newScores);
      return { ...prev, simulacroScores: newScores, estimatedScore };
    });
  }, [calculateEstimatedScore]);

  const getLessonProgress = useCallback((lessonId: string) => {
    return progress.completedLessons.find(l => l.lessonId === lessonId);
  }, [progress.completedLessons]);

  const isLessonCompleted = useCallback((lessonId: string) => {
    return progress.completedLessons.some(l => l.lessonId === lessonId && l.completed);
  }, [progress.completedLessons]);

  const getModuleProgress = useCallback((moduleId: string, lessonIds: string[]) => {
    if (lessonIds.length === 0) return 0;
    const completed = lessonIds.filter(id => progress.completedLessons.some(l => l.lessonId === id && l.completed));
    return Math.round((completed.length / lessonIds.length) * 100);
  }, [progress.completedLessons]);

  const resetProgress = useCallback(() => {
    setProgress(defaultProgress);
    localStorage.removeItem('proicfes_progress');
  }, []);

  const completeOnboarding = useCallback((currentScore: number, minimumScore: number, targetScore: number, career: string) => {
    setProgress(prev => {
      const updated = {
        ...prev,
        hasCompletedOnboarding: true,
        currentScore,
        minimumScore,
        targetScore,
        career,
        estimatedScore: currentScore || 100
      };
      localStorage.setItem('proicfes_progress', JSON.stringify(updated));
      return updated;
    });
  }, []);

  const toggleFavoriteLesson = useCallback((lessonId: string) => {
    setProgress(prev => {
      const updated = {
        ...prev,
        favoriteLessons: prev.favoriteLessons.includes(lessonId)
          ? prev.favoriteLessons.filter(id => id !== lessonId)
          : [...prev.favoriteLessons, lessonId]
      };
      localStorage.setItem('proicfes_progress', JSON.stringify(updated));
      return updated;
    });
  }, []);

  const toggleFavoriteQuestion = useCallback((questionId: string) => {
    setProgress(prev => {
      const updated = {
        ...prev,
        favoriteQuestions: prev.favoriteQuestions.includes(questionId)
          ? prev.favoriteQuestions.filter(id => id !== questionId)
          : [...prev.favoriteQuestions, questionId]
      };
      localStorage.setItem('proicfes_progress', JSON.stringify(updated));
      return updated;
    });
  }, []);

  const isFavoriteLesson = useCallback((lessonId: string) => {
    return progress.favoriteLessons.includes(lessonId);
  }, [progress.favoriteLessons]);

  const isFavoriteQuestion = useCallback((questionId: string) => {
    return progress.favoriteQuestions.includes(questionId);
  }, [progress.favoriteQuestions]);

  return (
    <ProgressContext.Provider value={{
      progress,
      completeLesson,
      addSimulacroScore,
      getLessonProgress,
      isLessonCompleted,
      getModuleProgress,
      resetProgress,
      completeOnboarding,
      toggleFavoriteLesson,
      toggleFavoriteQuestion,
      isFavoriteLesson,
      isFavoriteQuestion
    }}>
      {children}
    </ProgressContext.Provider>
  );
}

export function useProgress() {
  const ctx = useContext(ProgressContext);
  if (!ctx) throw new Error('useProgress must be used within ProgressProvider');
  return ctx;
}
