# ProICFES - Prepárate y Triunfa 🎓

Una app web completa e interactiva para preparar el **ICFES desde cero hasta 360+ puntos**, con un enfoque en lenguaje accesible para todos los colombianos.

## ✨ Características principales

### 📚 5 Módulos completos
- **Matemáticas**: Operaciones, estadística, gráficas, álgebra, probabilidad
- **Lectura Crítica**: Comprensión literal, inferencial y análisis del propósito del autor
- **Ciencias Naturales**: Célula, leyes de Newton, ecosistemas y más
- **Sociales y Ciudadanas**: Constitución del 91, historia de Colombia, geografía
- **Inglés**: Vocabulario, cognados, tiempos verbales

### 🎯 Sistema de niveles
Cada módulo tiene 4 niveles de dificultad:
- 🟢 **Básico**: Para quienes no saben nada del tema
- 🟡 **Intermedio**: Para quienes ya conocen lo básico
- 🔴 **Avanzado**: Para llegar a 300+ puntos
- ⭐ **Experto**: Para superar los 360 puntos

### 🎮 Gamificación
- **Medidor de puntaje animado**: Visualiza tu progreso de 200 a 500 puntos
- **Sistema de XP**: Gana puntos de experiencia por cada lección
- **Racha de días**: Mantén tu racha estudiando consecutivamente
- **8 Insignias desbloqueables**: Logros por hitos alcanzados
- **Leaderboard**: Compite con otros estudiantes (top 3 con insignia de agujero negro 🌌)

### 📖 Glosario interactivo
Cada palabra técnica tiene dos explicaciones:
- En **palabras simples**: Que entienda cualquier colombiano
- En **lenguaje técnico**: Para aprender la terminología correcta

### 💡 Estrategias y consejos
Página dedicada con trucos de los que sacan 360+:
- Estrategia general del examen
- Tips específicos por área
- Consejos para el día del examen

### 🎯 Simulacro completo
Practica como en el examen real con:
- Preguntas de todas las áreas
- Retroalimentación inmediata
- Revisión de respuestas incorrectas
- Análisis de desempeño

### 📱 Funciona en cualquier dispositivo
- **Desktop**: Sidebar de navegación
- **Tablet**: Interfaz adaptable
- **Móvil**: Bottom navigation + PWA (instálable como app)

## 🚀 Cómo usar

### En el navegador
1. Clona el repositorio
2. Instala dependencias: `pnpm install`
3. Inicia el servidor: `pnpm dev`
4. Abre `http://localhost:5173` en tu navegador

### Como app móvil (PWA)
1. Abre la app en tu navegador móvil
2. Toca el menú (⋯) y selecciona "Instalar app" o "Agregar a pantalla de inicio"
3. ¡Listo! Ahora tienes ProICFES como app nativa

## 🛠️ Stack tecnológico

- **React 19**: Interfaz interactiva
- **TypeScript**: Código seguro y escalable
- **Tailwind CSS 4**: Diseño responsivo
- **Framer Motion**: Animaciones fluidas
- **Wouter**: Enrutamiento ligero
- **shadcn/ui**: Componentes accesibles
- **PWA**: Funciona offline y se instala como app

## 📂 Estructura del proyecto

```
client/
├── src/
│   ├── pages/           # Páginas principales
│   ├── components/      # Componentes reutilizables
│   ├── contexts/        # Contextos de React (progreso)
│   ├── hooks/           # Hooks personalizados
│   ├── lib/             # Datos y utilidades
│   ├── App.tsx          # Enrutador principal
│   └── index.css        # Estilos globales
├── public/
│   ├── manifest.json    # Configuración PWA
│   └── sw.js            # Service Worker
└── index.html           # HTML principal
```

## 💾 Almacenamiento de datos

El progreso se guarda automáticamente en **localStorage** del navegador:
- Lecciones completadas
- Puntajes de quizzes
- XP ganados
- Racha de días
- Insignias desbloqueadas
- Simulacros realizados

## 🎨 Diseño

**Filosofía de diseño**: "Saber es Poder"
- **Colores**: Azul profundo (confianza) + Verde lima (crecimiento) + Amarillo cálido (energía)
- **Tipografía**: Lexend (legibilidad máxima) + DM Sans (amigable)
- **Interacciones**: Fluidas y motivantes
- **Accesibilidad**: Diseñado para todos

## 🌟 Características destacadas

### Lenguaje accesible
Toda la app está pensada para colombianos sin formación académica formal. Las explicaciones usan ejemplos de la vida cotidiana.

### Progresión clara
El sistema de niveles garantiza que puedas empezar desde cero y avanzar gradualmente.

### Motivación constante
Entre XP, insignias, racha y leaderboard, siempre hay algo que te motiva a seguir estudiando.

### Offline-ready
Gracias a PWA, puedes estudiar incluso sin conexión a internet.

## 📊 Puntajes estimados

La app estima tu puntaje ICFES basado en:
- Promedio de quizzes completados
- Nivel de dificultad alcanzado
- Número de lecciones completadas
- Desempeño en simulacros

## 🔄 Próximas mejoras

- [ ] Backend para sincronizar progreso entre dispositivos
- [ ] Notificaciones diarias para mantener la racha
- [ ] Modo repaso rápido con flashcards
- [ ] Análisis detallado de fortalezas y debilidades
- [ ] Integración con redes sociales para compartir logros

## 📝 Licencia

Este proyecto es de código abierto. Úsalo, modifícalo y comparte libremente.

## 👨‍💻 Autor

Creado con ❤️ para ayudar a los colombianos a prepararse para el ICFES.

---

**¡Prepárate y Triunfa! 🚀**

¿Dudas? Abre un issue en GitHub o contacta al autor.
