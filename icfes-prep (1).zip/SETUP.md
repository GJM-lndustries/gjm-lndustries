# 🚀 Guía de Instalación y Despliegue - ProICFES

## 📋 Requisitos previos

- **Node.js** 18+ (descarga desde [nodejs.org](https://nodejs.org))
- **pnpm** (gestor de paquetes rápido)
- **Git** (para clonar el repositorio)

## 🛠️ Instalación local

### 1. Clonar el repositorio

```bash
git clone https://github.com/GJM-lndustries/ProICFES.git
cd ProICFES
```

### 2. Instalar dependencias

```bash
pnpm install
```

### 3. Iniciar el servidor de desarrollo

```bash
pnpm dev
```

La app estará disponible en `http://localhost:5173`

## 📱 Usar como PWA (App móvil)

### En navegador de escritorio:
1. Abre `http://localhost:5173`
2. Abre las DevTools (F12)
3. Ve a la pestaña "Application" → "Manifest"
4. Verifica que el manifest esté cargado correctamente

### En móvil:
1. Abre la app en tu navegador móvil
2. Toca el menú (⋯) y selecciona "Instalar app" o "Agregar a pantalla de inicio"
3. ¡Listo! Ahora tienes ProICFES como app nativa

## 🌐 Despliegue en producción

### Opción 1: Vercel (Recomendado)

```bash
# Instala Vercel CLI
npm i -g vercel

# Despliega
vercel
```

### Opción 2: Netlify

```bash
# Instala Netlify CLI
npm i -g netlify-cli

# Despliega
netlify deploy --prod --dir=dist
```

### Opción 3: GitHub Pages

1. Actualiza `vite.config.ts` con tu base URL:
```typescript
export default defineConfig({
  base: '/ProICFES/',
  // ...
})
```

2. Ejecuta:
```bash
pnpm build
```

3. Sube la carpeta `dist` a la rama `gh-pages`

### Opción 4: Tu propio servidor

```bash
# Compila la app
pnpm build

# Sube la carpeta `dist` a tu servidor
# Configura tu servidor web para servir `index.html` en todas las rutas
```

## 🔧 Configuración

### Variables de entorno

Crea un archivo `.env.local` (opcional):

```env
VITE_APP_TITLE=ProICFES
VITE_APP_DESCRIPTION=Prepárate y Triunfa en el ICFES
```

### Personalización del diseño

Edita `client/src/index.css` para cambiar:
- Colores principales
- Tipografía
- Espaciado
- Temas

## 📦 Estructura del proyecto

```
ProICFES/
├── client/
│   ├── src/
│   │   ├── pages/          # Páginas de la app
│   │   ├── components/     # Componentes reutilizables
│   │   ├── contexts/       # Contextos de React
│   │   ├── hooks/          # Hooks personalizados
│   │   ├── lib/            # Utilidades y datos
│   │   └── index.css       # Estilos globales
│   ├── public/
│   │   ├── manifest.json   # Configuración PWA
│   │   └── sw.js           # Service Worker
│   └── index.html
├── server/                 # (Placeholder para compatibilidad)
├── package.json
└── README.md
```

## 🧪 Desarrollo

### Comandos disponibles

```bash
# Inicia el servidor de desarrollo
pnpm dev

# Compila para producción
pnpm build

# Vista previa de la compilación
pnpm preview

# Verifica tipos TypeScript
pnpm check

# Formatea el código
pnpm format
```

## 🐛 Solución de problemas

### La app no carga
- Verifica que Node.js esté instalado: `node --version`
- Limpia la caché: `rm -rf node_modules pnpm-lock.yaml && pnpm install`
- Reinicia el servidor: `pnpm dev`

### PWA no se instala
- Asegúrate de que el manifest.json esté en `client/public/`
- Verifica que el service worker esté registrado (abre DevTools → Console)
- Usa HTTPS en producción (PWA requiere HTTPS)

### Problemas de compilación
- Verifica que TypeScript no tenga errores: `pnpm check`
- Limpia la caché de Vite: `rm -rf .vite`
- Reinstala dependencias: `pnpm install`

## 📚 Recursos útiles

- [React 19 Docs](https://react.dev)
- [Tailwind CSS 4 Docs](https://tailwindcss.com)
- [shadcn/ui Components](https://ui.shadcn.com)
- [Framer Motion Docs](https://www.framer.com/motion)
- [PWA Docs](https://web.dev/progressive-web-apps)

## 📝 Licencia

Este proyecto es de código abierto. Úsalo, modifícalo y comparte libremente.

## 🤝 Contribuciones

¿Quieres mejorar ProICFES? ¡Adelante!

1. Fork el repositorio
2. Crea una rama para tu feature: `git checkout -b feature/mi-feature`
3. Commit tus cambios: `git commit -am 'Agrego mi feature'`
4. Push a la rama: `git push origin feature/mi-feature`
5. Abre un Pull Request

---

**¿Preguntas?** Abre un issue en GitHub o contacta al autor.

**¡Prepárate y Triunfa! 🚀**
